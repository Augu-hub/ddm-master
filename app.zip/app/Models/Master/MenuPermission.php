<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Model;

class MenuPermission extends Model
{
    //
}
