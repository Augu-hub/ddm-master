<?php

namespace App\Domain\Param\Actions\Projects;

class UpdateProject
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
