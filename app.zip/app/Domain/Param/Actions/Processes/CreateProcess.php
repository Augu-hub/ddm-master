<?php

namespace App\Domain\Param\Actions\Processes;

class CreateProcess
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
