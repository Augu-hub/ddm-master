<?php

namespace App\Domain\Param\Actions\Processes;

class UpdateProcess
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
