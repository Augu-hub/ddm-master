<?php

namespace App\Domain\Param\Actions\Processes;

class DeleteProcess
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
