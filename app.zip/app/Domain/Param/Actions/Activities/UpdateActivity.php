<?php

namespace App\Domain\Param\Actions\Activities;

class UpdateActivity
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
