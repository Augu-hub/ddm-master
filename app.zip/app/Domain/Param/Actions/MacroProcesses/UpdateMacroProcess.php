<?php

namespace App\Domain\Param\Actions\MacroProcesses;

class UpdateMacroProcess
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
