<?php

namespace App\Domain\Param\Actions\Functions;

class UpdateFunction
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
