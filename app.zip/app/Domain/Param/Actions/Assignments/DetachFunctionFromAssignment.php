<?php

namespace App\Domain\Param\Actions\Assignments;

class DetachFunctionFromAssignment
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
