<?php

namespace App\Domain\Param\Services;

class ProjectService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
