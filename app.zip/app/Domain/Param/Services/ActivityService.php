<?php

namespace App\Domain\Param\Services;

class ActivityService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
