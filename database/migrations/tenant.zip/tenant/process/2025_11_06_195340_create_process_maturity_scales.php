<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    protected $connection = 'tenant';

    public function up(): void
    {
        Schema::connection('tenant')->create('process_maturity_scales', function (Blueprint $t) {
            $t->id();
            $t->string('code', 20)->unique();      // ex: 0..5 ou L1..L5
            $t->string('label', 100);              // ex: Initial, Répétable...
            $t->unsignedTinyInteger('rank');       // 1..5 (ordre logique)
            $t->unsignedTinyInteger('sort')->default(0); // ordre d’affichage (legacy/compat)
            $t->unsignedTinyInteger('weight')->default(0); // ordre d’affichage (legacy/compat)
            $t->unsignedTinyInteger('min_score')->default(0);
            $t->unsignedTinyInteger('max_score')->default(100);
            $t->string('color', 9)->nullable(); // ex: #ef4444
            $t->timestamps();

            // Accès fréquents
            $t->index('rank');
            $t->index('sort');
            $t->index('weight');
        });
    }

    public function down(): void
    {
        Schema::connection('tenant')->dropIfExists('process_maturity_scales');
    }
};
