<template>
    <header class="topnav">
        <nav class="navbar navbar-expand-lg">
            <nav class="page-container">
                <b-collapse class="navbar-collapse" id="navbar">
                    <HorizontalMenu />
                </b-collapse>
            </nav>
        </nav>
    </header>
</template>

<script setup lang="ts">
import HorizontalMenu from '@/layouts/partials/components/HorizontalMenu.vue';
</script>
