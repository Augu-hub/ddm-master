<template>
    <VerticalLayout>
        <PageTitle title="Tabler Icons" subtitle="Icons" />
        <div class="d-flex justify-content-center icon-box mb-3 flex-wrap gap-3">
            <b-card no-body v-b-tooltip.hover.top="'ti ti-a-b-2'">
                <b-card-body>
                    <i class="ti ti-a-b-2 fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-a-b-off'">
                <b-card-body>
                    <i class="ti ti-a-b-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-a-b'">
                <b-card-body>
                    <i class="ti ti-a-b fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-abacus-off'">
                <b-card-body>
                    <i class="ti ti-abacus-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-abacus'">
                <b-card-body>
                    <i class="ti ti-abacus fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-abc'">
                <b-card-body>
                    <i class="ti ti-abc fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-access-point-off'">
                <b-card-body>
                    <i class="ti ti-access-point-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-accessible-off'">
                <b-card-body>
                    <i class="ti ti-accessible-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-accessible'">
                <b-card-body>
                    <i class="ti ti-accessible fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-activity-heartbeat'">
                <b-card-body>
                    <i class="ti ti-activity-heartbeat fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-activity'">
                <b-card-body>
                    <i class="ti ti-activity fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ad-2'">
                <b-card-body>
                    <i class="ti ti-ad-2 fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ad-circle-off'">
                <b-card-body>
                    <i class="ti ti-ad-circle-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ad-circle'">
                <b-card-body>
                    <i class="ti ti-ad-circle fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ad-off'">
                <b-card-body>
                    <i class="ti ti-ad-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ad'">
                <b-card-body>
                    <i class="ti ti-ad fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-address-book-off'">
                <b-card-body>
                    <i class="ti ti-address-book-off fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-address-book'">
                <b-card-body>
                    <i class="ti ti-address-book fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-adjustments'">
                <b-card-body>
                    <i class="ti ti-adjustments fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-aerial-lift'">
                <b-card-body>
                    <i class="ti ti-aerial-lift fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-affiliate'">
                <b-card-body>
                    <i class="ti ti-affiliate fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-air-balloon'">
                <b-card-body>
                    <i class="ti ti-air-balloon fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-air-conditioning'">
                <b-card-body>
                    <i class="ti ti-air-conditioning fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-air-traffic-control'">
                <b-card-body>
                    <i class="ti ti-air-traffic-control fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-alarm'">
                <b-card-body>
                    <i class="ti ti-alarm fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-album'">
                <b-card-body>
                    <i class="ti ti-album fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-alert-circle'">
                <b-card-body>
                    <i class="ti ti-alert-circle fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-alien'">
                <b-card-body>
                    <i class="ti ti-alien fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-align-box-bottom-center'">
                <b-card-body>
                    <i class="ti ti-align-box-bottom-center fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-align-left'">
                <b-card-body>
                    <i class="ti ti-align-left fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-alpha'">
                <b-card-body>
                    <i class="ti ti-alpha fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-alphabet-cyrillic'">
                <b-card-body>
                    <i class="ti ti-alphabet-cyrillic fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-alt'">
                <b-card-body>
                    <i class="ti ti-alt fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ambulance'">
                <b-card-body>
                    <i class="ti ti-ambulance fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ampersand'">
                <b-card-body>
                    <i class="ti ti-ampersand fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-analyze'">
                <b-card-body>
                    <i class="ti ti-analyze fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-anchor'">
                <b-card-body>
                    <i class="ti ti-anchor fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-angle'">
                <b-card-body>
                    <i class="ti ti-angle fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-ankh'">
                <b-card-body>
                    <i class="ti ti-ankh fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-antenna-bars-5'">
                <b-card-body>
                    <i class="ti ti-antenna-bars-5 fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-antenna'">
                <b-card-body>
                    <i class="ti ti-antenna fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-aperture'">
                <b-card-body>
                    <i class="ti ti-aperture fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-api-app'">
                <b-card-body>
                    <i class="ti ti-api-app fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-api'">
                <b-card-body>
                    <i class="ti ti-api fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-app-window'">
                <b-card-body>
                    <i class="ti ti-app-window fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-apple'">
                <b-card-body>
                    <i class="ti ti-apple fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-apps'">
                <b-card-body>
                    <i class="ti ti-apps fs-2"></i>
                </b-card-body>
            </b-card>

            <b-card no-body v-b-tooltip.hover.top="'ti ti-archery-arrow'">
                <b-card-body>
                    <i class="ti ti-archery-arrow fs-2"></i>
                </b-card-body>
            </b-card>
        </div>
        <div class="text-center">
            <a href="https://tabler.io/icons" target="_blank" class="btn btn-danger">View All Icons</a>
        </div>
    </VerticalLayout>
</template>
<script setup lang="ts">
import PageTitle from '@/components/PageTitle.vue';
import VerticalLayout from '@/layouts/VerticalLayout.vue';
</script>
