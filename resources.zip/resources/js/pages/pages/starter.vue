<template>
    <VerticalLayout>
        <PageTitle title="Starter" subtitle="Pages" />
    </VerticalLayout>
</template>

<script setup lang="ts">
import PageTitle from '@/components/PageTitle.vue';
import VerticalLayout from '@/layouts/VerticalLayout.vue';
</script>
