<template>
    <VerticalLayout>
        <PageTitle title="Solar Icons" subtitle="Icons" />
        <div class="d-flex justify-content-center icon-box flex-wrap gap-3">
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'4k'">
                    <Icon icon="solar:4k-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Accessibility'">
                    <Icon icon="solar:accessibility-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Accumulator'">
                    <Icon icon="solar:accumulator-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Add Circle'">
                    <Icon icon="solar:add-circle-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Archive'">
                    <Icon icon="solar:archive-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Armchair'">
                    <Icon icon="solar:armchair-2-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Asteroid'">
                    <Icon icon="solar:asteroid-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Atom'">
                    <Icon icon="solar:atom-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Backpack'">
                    <Icon icon="solar:backpack-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Backspace'">
                    <Icon icon="solar:backspace-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bacteria'">
                    <Icon icon="solar:bacteria-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bag 2'">
                    <Icon icon="solar:bag-2-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Balloon'">
                    <Icon icon="solar:balloon-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Balls'">
                    <Icon icon="solar:balls-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Banknote'">
                    <Icon icon="solar:banknote-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bar Chair'">
                    <Icon icon="solar:bar-chair-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Basketball'">
                    <Icon icon="solar:basketball-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bath'">
                    <Icon icon="solar:bath-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bed'">
                    <Icon icon="solar:bed-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bell Bing'">
                    <Icon icon="solar:bell-bing-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bill'">
                    <Icon icon="solar:bill-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bill Check'">
                    <Icon icon="solar:bill-check-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bolt'">
                    <Icon icon="solar:bolt-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bomb'">
                    <Icon icon="solar:bomb-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Book 2'">
                    <Icon icon="solar:book-2-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bookmark'">
                    <Icon icon="solar:bookmark-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Boombox'">
                    <Icon icon="solar:boombox-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bottle'">
                    <Icon icon="solar:bottle-outline" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bowling'">
                    <Icon icon="solar:bowling-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Box'">
                    <Icon icon="solar:box-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Broom'">
                    <Icon icon="solar:broom-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bug'">
                    <Icon icon="solar:bug-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Bus'">
                    <Icon icon="solar:bus-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Calculator'">
                    <Icon icon="solar:calculator-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Camera'">
                    <Icon icon="solar:camera-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Card'">
                    <Icon icon="solar:card-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cardholder'">
                    <Icon icon="solar:cardholder-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cart 2'">
                    <Icon icon="solar:cart-2-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Case'">
                    <Icon icon="solar:case-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cassette'">
                    <Icon icon="solar:cassette-2-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cat'">
                    <Icon icon="solar:cat-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Chair 2'">
                    <Icon icon="solar:chair-2-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Chart 2'">
                    <Icon icon="solar:chart-2-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Chat Dots'">
                    <Icon icon="solar:chat-dots-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Checklist'">
                    <Icon icon="solar:checklist-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'City'">
                    <Icon icon="solar:city-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cloud'">
                    <Icon icon="solar:cloud-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Code File'">
                    <Icon icon="solar:code-file-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Command'">
                    <Icon icon="solar:command-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Compass'">
                    <Icon icon="solar:compass-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Condicioner'">
                    <Icon icon="solar:condicioner-2-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Confetti'">
                    <Icon icon="solar:confetti-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Copyright'">
                    <Icon icon="solar:copyright-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Corkscrew'">
                    <Icon icon="solar:corkscrew-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cosmetic'">
                    <Icon icon="solar:cosmetic-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Course Up'">
                    <Icon icon="solar:course-up-linear" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'CPU'">
                    <Icon icon="solar:cpu-bold" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Crop'">
                    <Icon icon="solar:crop-bold-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Crown'">
                    <Icon icon="solar:crown-line-broken" class="fs-2" />
                </b-card-body>
            </b-card>
            <b-card no-body>
                <b-card-body class="d-flex flex-column align-items-center justify-content-center" v-b-tooltip.hover.top="'Cup First'">
                    <Icon icon="solar:cup-first-line-duotone" class="fs-2" />
                </b-card-body>
            </b-card>
        </div>

        <div class="my-3 text-center">
            <a href="https://icon-sets.iconify.design/solar/" target="_blank" class="btn btn-danger">View All Icons</a>
        </div>
    </VerticalLayout>
</template>
<script setup lang="ts">
import PageTitle from '@/components/PageTitle.vue';
import VerticalLayout from '@/layouts/VerticalLayout.vue';
import { Icon } from '@iconify/vue';
</script>
