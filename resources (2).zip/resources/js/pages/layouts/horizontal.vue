<template>
    <HorizontalLayout>
        <PageTitle title="Horizontal" subtitle="Layouts" />
    </HorizontalLayout>
</template>

<script setup lang="ts">
import PageTitle from '@/components/PageTitle.vue';
import HorizontalLayout from '@/layouts/HorizontalLayout.vue';
</script>
