<template>
  <VerticalLayoutAudit>
    <div class="oz-shell">
      <!-- Header -->
      <header class="oz-header">
        <div class="oz-header__inner">
          <a :href="backUrl" class="oz-back"><i class="ti ti-arrow-left"></i></a>
          <div class="oz-header__meta">
            <div class="oz-header__badges">
              <span class="oz-code">{{ record.code || 'VI-AUTO' }}</span>
              <span class="oz-status" :class="'ozs--' + record.validation_status">
                <i :class="vstIcon(record.validation_status)"></i>{{ vstLbl(record.validation_status) }}
              </span>
              <span class="oz-pill"><i class="ti ti-shield-half"></i>{{ auditorRole }}</span>
              <span class="oz-pill"><i class="ti ti-user-check"></i>{{ auditeurNom }}</span>
            </div>
            <h1 class="oz-header__title" style="--hc:#dc2626">
              <span class="oz-num">VI</span>Hiérarchisation des Risques
            </h1>
            <div class="oz-header__info">
              <span v-if="missionContext?.mission_libelle"><i class="ti ti-building"></i>{{ missionContext.mission_libelle }}</span>
            </div>
          </div>
          <div class="oz-header__actions">
            <template v-if="!isLocked">
              <button class="oz-btn oz-btn--ghost" :disabled="processing" @click="annuler"><i class="ti ti-x"></i></button>
              <button class="oz-btn oz-btn--save" :disabled="processing" @click="submit()">
                <span v-if="processing" class="oz-spin"></span><i v-else class="ti ti-device-floppy"></i>
                {{ record.id ? 'Mettre à jour' : 'Enregistrer' }}
              </button>
              <button v-if="record.id && record.validation_status === 'draft'" class="oz-btn oz-btn--submit" @click="soumettre">
                <i class="ti ti-send"></i> Soumettre
              </button>
            </template>
            <template v-if="canManage && record.validation_status === 'in_review'">
              <button class="oz-btn oz-btn--ok" @click="valider('validate')"><i class="ti ti-circle-check"></i> Valider</button>
              <button class="oz-btn oz-btn--ko" @click="promptReject"><i class="ti ti-circle-x"></i> Rejeter</button>
            </template>
          </div>
        </div>
        <div v-if="record.validation_status === 'validated'" class="oz-banner oz-banner--ok">
          <i class="ti ti-lock"></i> Fiche <strong>validée</strong> — lecture seule
        </div>
        <div v-else-if="record.validation_status === 'in_review'" class="oz-banner oz-banner--review">
          <i class="ti ti-clock"></i> Soumise pour validation
        </div>
        <div v-else-if="record.validation_status === 'draft' && record.validation_note" class="oz-banner oz-banner--ko">
          <i class="ti ti-circle-x"></i> Rejetée — <em>{{ record.validation_note }}</em>
        </div>
      </header>

      <div class="oz-body">
        <!-- CARD EN-TÊTE -->
        <div class="oz-card">
          <h3 class="oz-card__title"><i class="ti ti-info-circle"></i> En-tête</h3>
          <div class="oz-g2">
            <div class="oz-f oz-full">
              <label class="oz-lbl">Intitulé *</label>
              <input type="text" class="oz-inp" v-model="record.intitule" :disabled="isLocked" placeholder="Ex: Hiérarchisation risques Achats"/>
            </div>
            <div class="oz-f oz-full">
              <label class="oz-lbl">Périmètre</label>
              <input type="text" class="oz-inp" v-model="record.perimetre" :disabled="isLocked" placeholder="Ex: Direction des Achats — exercice 2024"/>
            </div>
            <div class="oz-f">
              <label class="oz-lbl">Date d'analyse</label>
              <input type="date" class="oz-inp" v-model="record.date_analyse" :disabled="isLocked"/>
            </div>
          </div>
        </div>

        <!-- CARD TABLEAU DES RISQUES -->
        <div class="oz-card">
          <div class="oz-card__hd">
            <h3 class="oz-card__title"><i class="ti ti-list-check"></i> Inventaire et Évaluation des Risques</h3>
            <div style="display:flex;gap:.4rem;margin-left:auto">
              <span style="font-size:.65rem;font-weight:600;padding:2px 7px;border-radius:10px;background:#fee2e2;color:#dc2626">🔴 {{ stats.fort }}</span>
              <span style="font-size:.65rem;font-weight:600;padding:2px 7px;border-radius:10px;background:#fff7ed;color:#d97706">🟠 {{ stats.mod }}</span>
              <span style="font-size:.65rem;font-weight:600;padding:2px 7px;border-radius:10px;background:#f0fdf4;color:#15803d">🟢 {{ stats.fbl }}</span>
            </div>
            <button v-if="!isLocked" class="oz-add" @click="addRisque"><i class="ti ti-plus"></i> Risque</button>
          </div>

          <div class="oz-table-wrap">
            <table class="oz-tbl">
              <thead>
                <tr>
                  <th class="tc" style="width:28px">N°</th>
                  <th style="min-width:200px">Risque identifié</th>
                  <th style="min-width:150px">Causes</th>
                  <th style="min-width:150px">Conséquences</th>
                  <th class="tc" style="width:75px">Prob (1-3)</th>
                  <th class="tc" style="width:70px">Impact (1-3)</th>
                  <th class="tc" style="width:65px">P×I</th>
                  <th class="tc" style="width:80px">Niveau</th>
                  <th v-if="!isLocked" style="width:28px"></th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="!risquesLocaux.length">
                  <td colspan="9" class="oz-ec">Aucun risque — cliquez sur "Risque" pour en ajouter</td>
                </tr>
                <tr v-for="(r, ri) in risquesLocaux" :key="ri" :style="getCriticite(r) >= 7 ? 'background:#fff5f5' : (getCriticite(r) >= 4 ? 'background:#fffbeb' : '')">
                  <td class="tc oz-n">{{ ri + 1 }}</td>
                  <tr>
                    <div class="oz-risk-header">
                      <span v-if="r.from_mission" class="oz-risk-badge" :style="{background: r.risk_type_color || '#6c757d', color: '#fff'}">
                        <i class="ti ti-database"></i> {{ r.code || 'Risque mission' }}
                      </span>
                      <textarea class="oz-ta-sm" v-model="r.libelle" rows="2" :disabled="isLocked" placeholder="Description du risque"></textarea>
                    </div>
                  </td>
                  <td><textarea class="oz-ta-sm" v-model="r.causes" rows="2" :disabled="isLocked" placeholder="Causes..."></textarea></td>
                  <td><textarea class="oz-ta-sm" v-model="r.consequences" rows="2" :disabled="isLocked" placeholder="Conséquences..."></textarea></td>
                  <td class="tc">
                    <select class="oz-sel-sm" v-model.number="r.probabilite" @change="calcCrit(r)" :disabled="isLocked">
                      <option :value="1">1 (Faible)</option>
                      <option :value="2">2 (Moyenne)</option>
                      <option :value="3">3 (Forte)</option>
                    </select>
                  </td>
                  <td class="tc">
                    <select class="oz-sel-sm" v-model.number="r.impact" @change="calcCrit(r)" :disabled="isLocked">
                      <option :value="1">1 (Faible)</option>
                      <option :value="2">2 (Moyen)</option>
                      <option :value="3">3 (Fort)</option>
                    </select>
                  </td>
                  <td class="tc" :style="getCriticite(r) >= 7 ? 'font-weight:800;color:#dc2626' : (getCriticite(r) >= 4 ? 'font-weight:800;color:#d97706' : 'font-weight:700;color:#15803d')">
                    {{ getCriticite(r) }}
                  </td>
                  <td class="tc">
                    <span :style="getCriticite(r) >= 7 ? 'background:#fee2e2;color:#dc2626' : (getCriticite(r) >= 4 ? 'background:#fff7ed;color:#d97706' : 'background:#f0fdf4;color:#15803d')" 
                          style="display:inline-block;padding:2px 7px;border-radius:10px;font-size:.62rem;font-weight:700">
                      {{ getCriticite(r) >= 7 ? 'Fort' : (getCriticite(r) >= 4 ? 'Modéré' : 'Faible') }}
                    </span>
                  </td>
                  <td v-if="!isLocked" class="tc">
                    <button class="oz-del" @click="risquesLocaux.splice(ri, 1)"><i class="ti ti-trash"></i></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- ════════════════════════════════════════════════════════ -->
        <!-- SECTION RÉSULTATS — AFFICHE LES STATISTIQUES DES RISQUES -->
        <!-- ════════════════════════════════════════════════════════ -->
        <div class="oz-card oz-card--results" v-if="risquesLocaux.length">
          <h3 class="oz-card__title"><i class="ti ti-chart-bar"></i> Résultats de l'analyse</h3>
          
          <!-- Cartes récapitulatives -->
          <div class="oz-results-grid">
            <div class="oz-result-card oz-result-card--total">
              <div class="oz-result-number">{{ risquesLocaux.length }}</div>
              <div class="oz-result-label">Risques identifiés</div>
            </div>
            <div class="oz-result-card oz-result-card--critical">
              <div class="oz-result-number">{{ stats.fort }}</div>
              <div class="oz-result-label">Risques critiques (P×I≥7)</div>
            </div>
            <div class="oz-result-card oz-result-card--moderate">
              <div class="oz-result-number">{{ stats.mod }}</div>
              <div class="oz-result-label">Risques modérés (4-6)</div>
            </div>
            <div class="oz-result-card oz-result-card--low">
              <div class="oz-result-number">{{ stats.fbl }}</div>
              <div class="oz-result-label">Risques faibles (1-3)</div>
            </div>
          </div>

          <!-- Graphique de répartition (barres simples) -->
          <div class="oz-chart-container">
            <div class="oz-chart-bar">
              <div class="oz-chart-label">Critiques</div>
              <div class="oz-chart-track">
                <div class="oz-chart-fill oz-chart-fill--critical" :style="{width: (risquesLocaux.length ? (stats.fort / risquesLocaux.length * 100) : 0) + '%'}"></div>
              </div>
              <div class="oz-chart-percent">{{ risquesLocaux.length ? Math.round(stats.fort / risquesLocaux.length * 100) : 0 }}%</div>
            </div>
            <div class="oz-chart-bar">
              <div class="oz-chart-label">Modérés</div>
              <div class="oz-chart-track">
                <div class="oz-chart-fill oz-chart-fill--moderate" :style="{width: (risquesLocaux.length ? (stats.mod / risquesLocaux.length * 100) : 0) + '%'}"></div>
              </div>
              <div class="oz-chart-percent">{{ risquesLocaux.length ? Math.round(stats.mod / risquesLocaux.length * 100) : 0 }}%</div>
            </div>
            <div class="oz-chart-bar">
              <div class="oz-chart-label">Faibles</div>
              <div class="oz-chart-track">
                <div class="oz-chart-fill oz-chart-fill--low" :style="{width: (risquesLocaux.length ? (stats.fbl / risquesLocaux.length * 100) : 0) + '%'}"></div>
              </div>
              <div class="oz-chart-percent">{{ risquesLocaux.length ? Math.round(stats.fbl / risquesLocaux.length * 100) : 0 }}%</div>
            </div>
          </div>

          <!-- Liste des risques critiques -->
          <div v-if="risquesCritiques.length" class="oz-critical-list">
            <div class="oz-critical-title"><i class="ti ti-alert-triangle"></i> Risques à traiter en priorité (Critiques)</div>
            <div v-for="(r, idx) in risquesCritiques" :key="idx" class="oz-critical-item">
              <span class="oz-critical-num">{{ idx + 1 }}</span>
              <span class="oz-critical-text">{{ r.libelle || 'Risque sans libellé' }}</span>
              <span class="oz-critical-score">Score: {{ getCriticite(r) }}</span>
            </div>
          </div>
        </div>

        <!-- ZONE IA -->
        <div v-if="record.ia_result" class="oz-card oz-card--ia">
          <h3 class="oz-card__title"><i class="ti ti-sparkles"></i> Analyse IA — Score : <strong>{{ record.ia_result.score }}/10</strong></h3>
          <p class="oz-ia-synth">{{ record.ia_result.synthese }}</p>
          <div v-if="record.ia_result.recommandations?.length" class="oz-ia-recs">
            <div class="oz-ia-recs-title">Recommandations :</div>
            <div v-for="rec in record.ia_result.recommandations" :key="rec" class="oz-ia-rec">
              <i class="ti ti-arrow-right"></i>{{ rec }}
            </div>
          </div>
          <div v-if="record.ia_result.risques_majeurs?.length" class="oz-ia-risques">
            <div class="oz-ia-risques-title">Risques majeurs identifiés :</div>
            <div v-for="risk in record.ia_result.risques_majeurs" :key="risk" class="oz-ia-rec">
              <i class="ti ti-alert-triangle"></i>{{ risk }}
            </div>
          </div>
        </div>

        <button v-if="record.id && !isLocked" class="oz-btn-ia" :disabled="iaLoading" @click="genererIa">
          <span v-if="iaLoading" class="oz-spin"></span><i v-else class="ti ti-sparkles"></i>
          {{ iaLoading ? 'Analyse en cours...' : '✨ Générer analyse IA' }}
        </button>

        <Transition name="toast">
          <div v-if="toast.show" class="oz-toast" :class="'ozt--' + toast.type">{{ toast.msg }}</div>
        </Transition>
      </div>
    </div>
  </VerticalLayoutAudit>
</template>

<script setup lang="ts">
import { reactive, ref, computed, onBeforeUnmount, watch } from 'vue'
import { router } from '@inertiajs/vue3'
import VerticalLayoutAudit from '@/Layouts/VerticalLayoutAudit.vue'

const props = withDefaults(defineProps<{
  record?: any
  risques?: any[]
  processus?: any[]
  risquesMission?: any[]
  frequencies?: any[]
  impacts?: any[]
  matrix?: any[]
  riskTypes?: any[]
  auditorRole?: string
  auditeurNom?: string
  backUrl?: string
  urlStore?: string
  urlUpdate?: string | null
  urlSoumettre?: string | null
  urlValider?: string | null
  urlIa?: string | null
  missionContext?: {
    mission_id?: number
    assignment_id?: number
    mission_libelle?: string
    code_mission?: string
    test_ref?: string
    obj_num?: string
    proc_idx?: number
  }
}>(), {
  record: null,
  risques: () => [],
  processus: () => [],
  risquesMission: () => [],
  frequencies: () => [],
  impacts: () => [],
  matrix: () => [],
  riskTypes: () => [],
  auditorRole: 'AJ',
  auditeurNom: '',
  backUrl: '/',
  urlStore: '',
  urlUpdate: null,
  urlSoumettre: null,
  urlValider: null,
  urlIa: null,
  missionContext: () => ({})
})

// Données réactives
const record = reactive<any>({
  id: null,
  code: '',
  validation_status: 'draft',
  validation_note: null,
  intitule: '',
  perimetre: '',
  date_analyse: '',
  ia_result: null,
  ...(props.record ?? {})
})

// Risques locaux (copie pour édition)
const risquesLocaux = ref<any[]>([])
const processing = ref(false)
const iaLoading = ref(false)

// Toast
const toast = reactive({ show: false, type: 'success', msg: '' })
let _tt: any

// Computed
const canManage = computed(() => ['DM', 'CM'].includes(props.auditorRole ?? ''))
const isLocked = computed(() => record.validation_status === 'validated' || (record.validation_status === 'in_review' && !canManage.value))

const stats = computed(() => ({
  fort: risquesLocaux.value.filter(r => getCriticite(r) >= 7).length,
  mod: risquesLocaux.value.filter(r => getCriticite(r) >= 4 && getCriticite(r) <= 6).length,
  fbl: risquesLocaux.value.filter(r => getCriticite(r) >= 1 && getCriticite(r) <= 3).length
}))

const risquesCritiques = computed(() => 
  risquesLocaux.value.filter(r => getCriticite(r) >= 7).sort((a, b) => getCriticite(b) - getCriticite(a))
)

// Helper pour calculer la criticité
function getCriticite(r: any): number {
  const prob = r.probabilite ?? r.probability ?? 1
  const imp = r.impact ?? 1
  return prob * imp
}

function calcCrit(r: any) {
  r.criticite = getCriticite(r)
}

function addRisque() {
  risquesLocaux.value.push({
    libelle: '',
    causes: '',
    consequences: '',
    probabilite: 1,
    impact: 1,
    criticite: 1,
    traitement: '',
    responsable: '',
    echeance: '',
    from_mission: false
  })
}

// UI Helpers
function vstLbl(s: string): string {
  const map: Record<string, string> = { draft: 'Brouillon', in_review: 'En attente', validated: 'Validé ✓', rejected: 'Rejeté' }
  return map[s] ?? s
}

function vstIcon(s: string): string {
  const map: Record<string, string> = { draft: 'ti ti-edit', in_review: 'ti ti-clock', validated: 'ti ti-lock', rejected: 'ti ti-circle-x' }
  return map[s] ?? 'ti ti-file'
}

function csrf(): string {
  return (document.querySelector('meta[name=csrf-token]') as any)?.content ?? ''
}

function showToast(t: string, m: string, d = 4000) {
  if (_tt) clearTimeout(_tt)
  toast.show = true
  toast.type = t
  toast.msg = m
  _tt = setTimeout(() => (toast.show = false), d)
}

function annuler() {
  if (props.backUrl) router.visit(props.backUrl)
}

// CRUD Operations
async function submit(silent = false) {
  processing.value = !silent
  try {
    const url = record.id ? (props.urlUpdate ?? '') : (props.urlStore ?? '')
    const method = record.id ? 'PUT' : 'POST'
    if (!url) {
      if (!silent) showToast('error', 'URL manquante')
      return
    }

    const payload = {
      mission_id: props.missionContext?.mission_id,
      assignment_id: props.missionContext?.assignment_id,
      test_ref: props.missionContext?.test_ref,
      obj_num: props.missionContext?.obj_num,
      proc_idx: props.missionContext?.proc_idx,
      intitule: record.intitule,
      perimetre: record.perimetre,
      date_analyse: record.date_analyse,
      risques: risquesLocaux.value
    }

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: JSON.stringify(payload)
    })
    const d = await res.json()
    if (d.success || res.ok) {
      if (!silent) showToast('success', record.id ? 'Mis à jour.' : 'Créé.')
      if (d.record) {
        record.id = d.record.id
        if (d.record.code) record.code = d.record.code
        if (d.record.statut) record.validation_status = d.record.statut
      }
      if (d.urlUpdate) props.urlUpdate = d.urlUpdate
      if (d.urlSoumettre) props.urlSoumettre = d.urlSoumettre
      if (d.urlValider) props.urlValider = d.urlValider
      if (d.urlIa) props.urlIa = d.urlIa
    } else {
      if (!silent) showToast('error', d.message ?? d.error ?? 'Erreur')
    }
  } catch {
    if (!silent) showToast('error', 'Erreur réseau')
  } finally {
    processing.value = false
  }
}

async function soumettre() {
  processing.value = true
  try {
    const res = await fetch(props.urlSoumettre ?? '', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: '{}'
    })
    const d = await res.json()
    if (d.success) {
      record.validation_status = 'in_review'
      showToast('success', 'Soumise pour validation.')
    } else {
      showToast('error', d.error ?? 'Erreur')
    }
  } catch {
    showToast('error', 'Erreur réseau')
  }
  processing.value = false
}

async function valider(action: string, note?: string) {
  processing.value = true
  try {
    const res = await fetch(props.urlValider ?? '', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: JSON.stringify({ action, note })
    })
    const d = await res.json()
    if (d.success) {
      record.validation_status = d.status
      showToast('success', action === 'validate' ? 'Validée ✓' : 'Rejetée.')
    } else {
      showToast('error', d.error ?? 'Erreur')
    }
  } catch {
    showToast('error', 'Erreur réseau')
  }
  processing.value = false
}

function promptReject() {
  const n = prompt('Motif du rejet :')
  if (n?.trim()) valider('reject', n.trim())
}

async function genererIa() {
  if (!props.urlIa || !record.id) return
  iaLoading.value = true
  try {
    const res = await fetch(props.urlIa, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: '{}'
    })
    const d = await res.json()
    if (d.success) {
      record.ia_result = d.ia_result
      showToast('success', '✨ Analyse IA générée.')
    } else {
      showToast('error', d.error ?? 'Erreur IA')
    }
  } catch {
    showToast('error', 'Erreur réseau')
  }
  iaLoading.value = false
}

// ⭐⭐⭐ INITIALISATION DES RISQUES ⭐⭐⭐
// Priorité : d'abord les risques existants dans record, sinon ceux de props.risques
console.log('[OutilVI] Props reçues:', {
  hasRecord: !!props.record,
  recordRisques: props.record?.risques?.length,
  propsRisques: props.risques?.length,
  propsRisquesMission: props.risquesMission?.length
})

if (props.record?.risques && Array.isArray(props.record.risques) && props.record.risques.length > 0) {
  console.log('[OutilVI] Chargement depuis record.risques:', props.record.risques.length)
  risquesLocaux.value = props.record.risques
} else if (props.risques && Array.isArray(props.risques) && props.risques.length > 0) {
  console.log('[OutilVI] Chargement depuis props.risques:', props.risques.length)
  risquesLocaux.value = props.risques
} else if (props.risquesMission && Array.isArray(props.risquesMission) && props.risquesMission.length > 0) {
  console.log('[OutilVI] Chargement depuis props.risquesMission:', props.risquesMission.length)
  risquesLocaux.value = props.risquesMission.map((r: any) => ({
    risk_id: r.id,
    libelle: r.label || r.libelle || '',
    code: r.code,
    description: r.description,
    causes: '',
    consequences: '',
    probabilite: r.frequency_level ?? r.probabilite ?? 1,
    impact: r.impact_level ?? r.impact ?? 1,
    criticite: (r.frequency_level ?? r.probabilite ?? 1) * (r.impact_level ?? r.impact ?? 1),
    traitement: '',
    responsable: r.owner ?? '',
    echeance: '',
    from_mission: 1,
    risk_type_label: r.risk_type_label ?? '—',
    risk_type_color: r.risk_type_color ?? '#6c757d',
    control_procedure: r.control_procedure ?? ''
  }))
} else {
  console.log('[OutilVI] Aucun risque chargé, initialisation tableau vide')
  risquesLocaux.value = []
}

// Log final pour déboguer
console.log('[OutilVI] risquesLocaux final:', risquesLocaux.value.length)
console.log('[OutilVI] Stats finales:', stats.value)

onBeforeUnmount(() => {
  if (_tt) clearTimeout(_tt)
})
</script>

<style scoped>
.oz-shell { display:flex; flex-direction:column; min-height:100vh; background:#f1f5f9; font-family:'DM Sans',system-ui,sans-serif; }
.oz-header{ background:#fff; border-bottom:1px solid #e2e8f0; box-shadow:0 1px 3px rgba(15,23,42,.06); flex-shrink:0; }
.oz-header__inner{ display:flex; align-items:center; gap:.6rem; padding:.5rem .9rem; }
.oz-back{ display:inline-flex; align-items:center; justify-content:center; width:30px; height:30px; border-radius:6px; border:1px solid #e2e8f0; color:#475569; text-decoration:none; flex-shrink:0; }
.oz-back:hover{ background:#f8fafc; }
.oz-header__meta{ flex:1; min-width:0; }
.oz-header__badges{ display:flex; align-items:center; gap:.3rem; flex-wrap:wrap; margin-bottom:.2rem; }
.oz-code{ background:#0f172a; color:#e2e8f0; padding:1px 7px; border-radius:4px; font-size:.63rem; font-family:monospace; font-weight:700; }
.oz-status{ display:inline-flex; align-items:center; gap:.2rem; padding:1px 7px; border-radius:12px; font-size:.63rem; font-weight:600; }
.ozs--draft{ background:#f1f5f9; color:#64748b; }
.ozs--in_review{ background:#dbeafe; color:#1d4ed8; }
.ozs--validated{ background:#dcfce7; color:#15803d; }
.ozs--rejected{ background:#fee2e2; color:#dc2626; }
.oz-pill{ display:inline-flex; align-items:center; gap:.2rem; background:#f8fafc; color:#64748b; padding:2px 7px; border-radius:20px; font-size:.63rem; }
.oz-header__title{ font-size:.82rem; font-weight:700; color:#0f172a; margin:0; display:flex; align-items:center; gap:.4rem; }
.oz-num{ display:inline-flex; align-items:center; justify-content:center; min-width:22px; height:22px; background:var(--hc,#1e40af); color:#fff; border-radius:5px; font-size:.65rem; font-weight:700; flex-shrink:0; padding:0 3px; }
.oz-header__info{ display:flex; gap:.5rem; flex-wrap:wrap; margin-top:.15rem; }
.oz-header__info span{ display:inline-flex; align-items:center; gap:.2rem; font-size:.65rem; color:#64748b; }
.oz-header__actions{ display:flex; align-items:center; gap:.25rem; flex-shrink:0; }
.oz-btn{ display:inline-flex; align-items:center; gap:.25rem; padding:5px 11px; border:none; border-radius:6px; font-size:.72rem; font-weight:600; cursor:pointer; font-family:inherit; transition:all .12s; }
.oz-btn--ghost{ background:#f1f5f9; color:#475569; border:1px solid #e2e8f0; }
.oz-btn--ghost:hover{ background:#e2e8f0; }
.oz-btn--save{ background:#1e40af; color:#fff; }
.oz-btn--save:hover{ background:#1d4ed8; }
.oz-btn--submit{ background:#7c3aed; color:#fff; }
.oz-btn--submit:hover{ background:#6d28d9; }
.oz-btn--ok{ background:#15803d; color:#fff; }
.oz-btn--ok:hover{ background:#166534; }
.oz-btn--ko{ background:#dc2626; color:#fff; }
.oz-btn--ko:hover{ background:#b91c1c; }
.oz-btn:disabled{ opacity:.55; cursor:default; }
.oz-banner{ display:flex; align-items:center; gap:.4rem; padding:.28rem .9rem; font-size:.7rem; }
.oz-banner--ok{ background:#d1fae5; color:#065f46; border-top:1px solid #a7f3d0; }
.oz-banner--review{ background:#dbeafe; color:#1d4ed8; border-top:1px solid #bfdbfe; }
.oz-banner--ko{ background:#fee2e2; color:#dc2626; border-top:1px solid #fecaca; }
.oz-body{ flex:1; padding:.75rem; display:flex; flex-direction:column; gap:.75rem; overflow-y:auto; }
.oz-card{ background:#fff; border:1px solid #e2e8f0; border-radius:10px; padding:1rem; }
.oz-card__hd{ display:flex; align-items:center; gap:.5rem; margin-bottom:.7rem; }
.oz-card__title{ font-size:.77rem; font-weight:700; color:#0f172a; margin:0 0 .6rem; display:flex; align-items:center; gap:.3rem; }
.oz-g2{ display:grid; grid-template-columns:1fr 1fr; gap:.6rem; }
.oz-f{ display:flex; flex-direction:column; gap:.2rem; }
.oz-full{ grid-column:1/-1; }
.oz-lbl{ font-size:.64rem; font-weight:600; color:#64748b; }
.oz-inp{ width:100%; border:1px solid #e2e8f0; border-radius:5px; padding:5px 8px; font-size:.75rem; outline:none; font-family:inherit; color:#111827; background:#fff; box-sizing:border-box; }
.oz-inp:focus{ border-color:#93c5fd; }
.oz-inp:disabled{ background:#f8fafc; color:#64748b; }
.oz-ta-sm{ width:100%; border:1px solid #e5e7eb; border-radius:4px; padding:3px 5px; font-size:.67rem; resize:vertical; font-family:inherit; }
.oz-sel-sm{ width:100%; border:1px solid #e5e7eb; border-radius:4px; padding:3px 5px; font-size:.67rem; font-family:inherit; background:#fff; cursor:pointer; }
.oz-add{ display:inline-flex; align-items:center; gap:.2rem; padding:3px 9px; background:#eff6ff; border:1px solid #bfdbfe; color:#1d4ed8; border-radius:5px; font-size:.68rem; font-weight:600; cursor:pointer; margin-left:auto; }
.oz-add:hover{ background:#dbeafe; }
.oz-del{ background:#fee2e2; border:1px solid #fecaca; color:#dc2626; border-radius:4px; cursor:pointer; padding:2px 4px; font-size:.62rem; line-height:1; display:flex; align-items:center; }
.oz-del:hover{ background:#fecaca; }
.oz-table-wrap{ overflow-x:auto; border:1px solid #e2e8f0; border-radius:6px; }
.oz-tbl{ width:100%; border-collapse:collapse; font-size:.68rem; }
.oz-tbl thead th{ padding:.3rem .4rem; background:#0f172a; color:rgba(255,255,255,.85); font-weight:700; border-bottom:1px solid #1e293b; border-right:1px solid #334155; white-space:nowrap; font-size:.6rem; text-transform:uppercase; }
.oz-tbl tbody td{ padding:.25rem .35rem; border-bottom:1px solid #f3f4f6; border-right:1px solid #f3f4f6; vertical-align:middle; }
.oz-ec{ text-align:center; color:#94a3b8; padding:.8rem; font-style:italic; font-size:.68rem; }
.oz-n{ color:#94a3b8; font-size:.62rem; }
.tc{ text-align:center; }

/* Styles pour les résultats */
.oz-card--results { background:linear-gradient(135deg,#f8fafc,#fff); }
.oz-results-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:.75rem; margin-bottom:1rem; }
.oz-result-card { text-align:center; padding:.6rem; border-radius:8px; background:white; border:1px solid #e2e8f0; }
.oz-result-card--total { background:#eff6ff; border-color:#bfdbfe; }
.oz-result-card--critical { background:#fee2e2; border-color:#fecaca; }
.oz-result-card--moderate { background:#fff7ed; border-color:#fed7aa; }
.oz-result-card--low { background:#f0fdf4; border-color:#bbf7d0; }
.oz-result-number { font-size:1.5rem; font-weight:800; line-height:1.2; }
.oz-result-card--total .oz-result-number { color:#1d4ed8; }
.oz-result-card--critical .oz-result-number { color:#dc2626; }
.oz-result-card--moderate .oz-result-number { color:#d97706; }
.oz-result-card--low .oz-result-number { color:#15803d; }
.oz-result-label { font-size:.6rem; color:#64748b; margin-top:.2rem; text-transform:uppercase; }

.oz-chart-container { margin-top:.75rem; padding-top:.5rem; border-top:1px solid #e2e8f0; }
.oz-chart-bar { display:flex; align-items:center; gap:.5rem; margin-bottom:.5rem; font-size:.65rem; }
.oz-chart-label { width:65px; font-weight:600; color:#475569; }
.oz-chart-track { flex:1; height:8px; background:#e2e8f0; border-radius:4px; overflow:hidden; }
.oz-chart-fill { height:100%; border-radius:4px; transition:width .3s; }
.oz-chart-fill--critical { background:#dc2626; }
.oz-chart-fill--moderate { background:#d97706; }
.oz-chart-fill--low { background:#15803d; }
.oz-chart-percent { width:40px; text-align:right; font-weight:600; color:#64748b; }

.oz-critical-list { margin-top:.75rem; padding:.5rem; background:#fff5f5; border-radius:6px; border-left:3px solid #dc2626; }
.oz-critical-title { font-size:.7rem; font-weight:700; color:#dc2626; margin-bottom:.5rem; display:flex; align-items:center; gap:.3rem; }
.oz-critical-item { display:flex; align-items:center; gap:.5rem; padding:.25rem 0; font-size:.7rem; border-bottom:1px solid #fee2e2; }
.oz-critical-item:last-child { border-bottom:none; }
.oz-critical-num { background:#dc2626; color:white; border-radius:50%; width:18px; height:18px; display:inline-flex; align-items:center; justify-content:center; font-size:.6rem; font-weight:700; flex-shrink:0; }
.oz-critical-text { flex:1; color:#1e293b; }
.oz-critical-score { font-size:.6rem; color:#dc2626; font-weight:600; }

.oz-risk-header { display:flex; flex-direction:column; gap:4px; }
.oz-risk-badge { display:inline-flex; align-items:center; gap:3px; font-size:9px; padding:2px 6px; border-radius:10px; width:fit-content; margin-bottom:4px; }

.oz-card--ia { background:linear-gradient(135deg,#faf5ff,#fff); border-color:#ddd6fe; }
.oz-ia-synth { font-size:.75rem; color:#374151; line-height:1.5; margin:0 0 .5rem; }
.oz-ia-recs-title, .oz-ia-risques-title { font-size:.65rem; font-weight:700; color:#6d28d9; margin-bottom:.3rem; }
.oz-ia-recs { display:flex; flex-direction:column; gap:.2rem; margin-bottom:.4rem; }
.oz-ia-risques { margin-top:8px; padding-top:8px; border-top:1px solid #e9d5ff; }
.oz-ia-rec { display:flex; align-items:flex-start; gap:.3rem; font-size:.7rem; color:#475569; }
.oz-btn-ia { display:inline-flex; align-items:center; gap:.3rem; padding:6px 14px; background:linear-gradient(135deg,#7c3aed,#6d28d9); color:#fff; border:none; border-radius:6px; font-size:.72rem; font-weight:600; cursor:pointer; font-family:inherit; align-self:flex-start; }
.oz-btn-ia:disabled { opacity:.55; cursor:default; }

.oz-toast { position:fixed; bottom:1.2rem; right:1.2rem; padding:.6rem 1rem; border-radius:8px; font-size:.75rem; font-weight:600; z-index:9999; box-shadow:0 4px 16px rgba(0,0,0,.12); }
.ozt--success { background:#dcfce7; color:#15803d; border:1px solid #a7f3d0; }
.ozt--error { background:#fee2e2; color:#dc2626; border:1px solid #fecaca; }

.oz-spin { width:12px; height:12px; border:2px solid rgba(255,255,255,.3); border-top-color:#fff; border-radius:50%; animation:_sp .7s linear infinite; display:inline-block; }
@keyframes _sp { to { transform:rotate(360deg); } }

.toast-enter-active,.toast-leave-active{ transition:all .3s; }
.toast-enter-from,.toast-leave-to{ opacity:0; transform:translateY(8px); }
</style>