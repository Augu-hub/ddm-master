<template>
  <VerticalLayoutAudit>
    <div class="ft-shell">

      <!-- ══ TOPBAR ════════════════════════════════════════════════ -->
      <header class="ft-topbar">
        <div class="ft-topbar__left">
          <a :href="props.backUrl" class="ft-ib" title="Retour"><i class="ti ti-arrow-left"></i></a>
          <span class="ft-code">{{ form.code || 'FT-AUTO' }}</span>
          <span class="ft-sdot" :class="'sd--' + form.validation_status"></span>
          <span class="ft-vstatus">{{ vstLbl(form.validation_status) }}</span>
          <div class="ft-div"></div>
          <i class="ti ti-building ft-icon-muted"></i>
          <span class="ft-mission-lbl">{{ missionLibelle || '—' }}</span>
          <span v-if="programmeData.found" class="ft-prog-badge">{{ programmeData.programme_code }}</span>
          <span v-if="programmeData.found" class="ft-stat-lbl">{{ programmeData.total_objectifs }} obj. · {{ programmeData.total_tests }} tests</span>
        </div>
        <div class="ft-topbar__right">
          <span class="ft-chip-role"><i class="ti ti-shield-half"></i>{{ props.auditorRole }}</span>
          <span class="ft-chip-user"><i class="ti ti-user-check"></i>{{ props.auditeurNom }}</span>
          <template v-if="!isLocked">
            <button class="ft-btn ft-btn--ghost" :disabled="processing" @click="annuler"><i class="ti ti-x"></i></button>
            <button class="ft-btn ft-btn--save" :disabled="processing" @click="submit()">
              <span v-if="processing" class="ft-spin"></span>
              <i v-else class="ti ti-device-floppy"></i>
              {{ form.id ? 'Enregistrer' : 'Créer' }}
            </button>
            <button v-if="form.id && form.validation_status === 'draft'" class="ft-btn ft-btn--submit" @click="soumettre">
              <i class="ti ti-send"></i>Soumettre
            </button>
          </template>
          <template v-if="canManage && form.validation_status === 'in_review'">
            <button class="ft-btn ft-btn--validate" @click="valider('validate')"><i class="ti ti-circle-check"></i>Valider</button>
            <button class="ft-btn ft-btn--reject" @click="promptReject"><i class="ti ti-circle-x"></i>Rejeter</button>
          </template>
        </div>
      </header>

      <!-- ══ BANNERS ════════════════════════════════════════════════ -->
      <div v-if="form.validation_status === 'validated'" class="ft-banner ft-banner--ok">
        <i class="ti ti-lock"></i> Fiche <strong>validée</strong> — lecture seule
      </div>
      <div v-else-if="form.validation_status === 'in_review'" class="ft-banner ft-banner--review">
        <i class="ti ti-clock"></i> En attente de validation<span v-if="canManage"> · DM/CM peut valider ou rejeter</span>
      </div>
      <div v-else-if="form.validation_status === 'draft' && form.validation_note" class="ft-banner ft-banner--rejected">
        <i class="ti ti-circle-x"></i> Rejetée — <em>{{ form.validation_note }}</em>
      </div>

      <!-- ══ CONTENU PRINCIPAL ══════════════════════════════════════ -->
      <div class="ft-main">

        <!-- ◈ VUE LISTE DES TESTS ─────────────────────────────────── -->
        <div v-if="!ficheActif && !outilActif && !constatActif" class="ft-tests-view">
          <div v-if="!programmeData.objectifs?.length" class="ft-empty">
            <div class="ft-empty__ico"><i class="ti ti-clipboard-off"></i></div>
            <p class="ft-empty__title">Aucun test affecté</p>
            <p class="ft-empty__sub">Contactez le Chef de Mission pour vous affecter des tests dans le programme de travail.</p>
          </div>

          <div v-else class="ft-obj-list">
            <div v-for="(obj, oi) in programmeData.objectifs" :key="oi" class="ft-obj">
              <div class="ft-obj__hd">
                <span class="ft-obj__num">{{ obj.num }}</span>
                <span class="ft-obj__label">{{ obj.objectif }}</span>
                <span v-if="obj._axe_rado" class="ft-tag ft-tag--blue">{{ obj._axe_rado }}</span>
                <span v-if="obj._priorite" class="ft-tag" :class="'ft-tag--p-' + obj._priorite">{{ obj._priorite }}</span>
              </div>
              <div class="ft-tests">
                <div
                  v-for="(test, ti) in obj.tests"
                  :key="ti"
                  class="ft-test"
                  :class="getResultat(obj.num, tRef(test, oi, ti)) ? 'ft-test--done' : ''"
                >
                  <div class="ft-test__row">
                    <code class="ft-ref">{{ tRef(test, oi, ti) }}</code>
                    <div class="ft-test__info">
                      <p class="ft-test__lbl">{{ test.libelle || '—' }}</p>
                      <div class="ft-test__chips">
                        <span v-if="test.periode_testee" class="ft-chip ft-chip--blue"><i class="ti ti-calendar"></i>{{ test.periode_testee }}</span>
                        <span v-if="test.lieu" class="ft-chip ft-chip--green"><i class="ti ti-map-pin"></i>{{ test.lieu }}</span>
                        <span v-if="test.taille_echantillon" class="ft-chip ft-chip--purple">n={{ test.taille_echantillon }}</span>
                      </div>
                    </div>
                    <select
                      v-if="!isLocked"
                      class="ft-sel-result"
                      :value="getResultat(obj.num, tRef(test, oi, ti))"
                      @change="setResultat(obj.num, tRef(test, oi, ti), ($event.target as HTMLSelectElement).value)"
                    >
                      <option value="">— résultat —</option>
                      <option value="conforme">✅ Conforme</option>
                      <option value="ecart">⚠️ Écart</option>
                      <option value="nc">❌ Non conforme</option>
                      <option value="na">N/A</option>
                    </select>
                    <span v-else class="ft-result-pill" :class="`frp--${getResultat(obj.num, tRef(test, oi, ti))}`">
                      {{ getResultat(obj.num, tRef(test, oi, ti)) || '—' }}
                    </span>
                    <div class="ft-test__acts">
                      <button
                        class="ft-btn ft-btn--fiche"
                        :class="getConstat(obj.num, tRef(test, oi, ti)) ? 'ft-btn--fiche-done' : ''"
                        title="Fiche de test"
                        @click="ouvrirFiche(obj, test, oi, ti)"
                      >
                        <i class="ti ti-clipboard-text"></i> Fiche test
                      </button>
                      <div class="dropdown">
                        <button
                          class="ft-ib ft-ib--sm ft-ib--tool dropdown-toggle"
                          :class="testHasAnyOutil(obj.num, tRef(test, oi, ti)) ? 'ft-ib--active' : ''"
                          data-bs-toggle="dropdown"
                          title="Ouvrir un outil IFACI"
                        >
                          <i class="ti ti-tool"></i>
                          <span v-if="testHasAnyOutil(obj.num, tRef(test, oi, ti))" class="ft-dot"></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end ft-dd shadow-sm">
                          <li class="ft-dd__head">Ouvrir un outil sur ce test</li>
                          <li v-for="outil in props.outilsIfaci" :key="outil.code">
                            <button class="ft-dd__item" @click="ouvrirOutil(obj, test, outil.code, 0, oi, ti)">
                              <span class="ft-dd__dot" :style="`background:${outil.color}`"></span>
                              <span class="ft-dd__code" :style="`color:${outil.color}`">{{ outil.code }}</span>
                              <span class="ft-dd__lbl">{{ outil.label }}</span>
                              <i v-if="testHasOutil(obj.num, tRef(test, oi, ti), outil.code)" class="ti ti-check ft-dd__chk"></i>
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div v-if="test.procedures?.length" class="ft-procs">
                    <div
                      v-for="(proc, pi) in test.procedures"
                      :key="pi"
                      class="ft-proc"
                      :class="getOutilsForProc(obj.num, tRef(test, oi, ti), pi).length ? 'ft-proc--linked' : ''"
                    >
                      <span class="ft-proc__n">{{ pi + 1 }}</span>
                      <span class="ft-proc__txt">{{ proc }}</span>
                      <div class="ft-proc__acts">
                        <button
                          v-for="code in getOutilsForProc(obj.num, tRef(test, oi, ti), pi)"
                          :key="code"
                          class="ft-outil-tag"
                          :style="`--ot:${outilColor(code)}`"
                          @click="ouvrirOutil(obj, test, code, pi, oi, ti)"
                        >
                          <i class="ti ti-tool"></i>{{ code }}
                        </button>
                        <button
                          v-if="!isLocked"
                          class="ft-ib ft-ib--xs"
                          :class="getOutilsForProc(obj.num, tRef(test, oi, ti), pi).length ? 'ft-ib--edit' : 'ft-ib--add'"
                          @click="ouvrirChoixOutil(obj, test, pi, oi, ti)"
                        >
                          <i :class="getOutilsForProc(obj.num, tRef(test, oi, ti), pi).length ? 'ti ti-edit' : 'ti ti-plus'"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- ◈ VUE FICHE DE TEST ───────────────────────────────────── -->
        <!-- ◈ VUE FICHE DE TEST — nouveau template fidèle au modèle IFACI -->
<div v-if="ficheActif && !outilActif && !constatActif" class="ft-fiche-capture">

  <!-- Header -->
  <div class="ft-fiche-header">
    <button class="ft-btn-back" @click="ficheActif = null">
      <i class="ti ti-arrow-left"></i> Retour aux tests
    </button>
    <div class="ft-fiche-header__center">
      <div class="ft-fiche-icon"><i class="ti ti-clipboard-text"></i></div>
      <div>
        <div class="ft-fiche-title">Fiche de Test d'Audit</div>
        <div class="ft-fiche-sub">{{ ficheActif.testRef }} · Objectif {{ ficheActif.objNum }}</div>
      </div>
    </div>
    <div class="ft-fiche-header__right">
      <button v-if="!isLocked" class="ft-btn-save" :disabled="processing" @click="saveFiche">
        <i class="ti ti-device-floppy"></i> Enregistrer
      </button>
      <button class="ft-btn-close" @click="ficheActif = null"><i class="ti ti-x"></i></button>
    </div>
  </div>

  <!-- Corps de la fiche — style tableau IFACI -->
  <div class="ft-fiche-body">

    <!-- 1. OBJECTIF -->
    <div class="fi-section-title">Objectif d'audit — {{ ficheActif.objNum }}</div>
    <div class="fi-objectif">{{ getObjectifTexte() }}</div>

    <!-- 2. AUDITEUR / DATE -->
    <table class="fi-auditeur-table">
      <tr>
        <th>Auditeur interne</th>
        <th>Date</th>
      </tr>
      <tr>
        <td>{{ props.auditeurNom || '—' }}</td>
        <td>
          <input v-if="!isLocked" type="date" class="fi-date-inp" v-model="ficheActif.date" />
          <span v-else>{{ formatDate(ficheActif.date) || '—' }}</span>
        </td>
      </tr>
    </table>

    <!-- 3. SOURCE D'INFORMATIONS -->
    <div class="fi-section-title fi-section-title--light">Source d'informations</div>
    <div class="fi-source-box">
      <div v-for="(src, i) in ficheSourcesDefaut" :key="i" class="fi-source-item">
        <span class="fi-dash">-</span>{{ src }}
      </div>
      <textarea
        v-if="!isLocked"
        class="fi-ta"
        v-model="ficheActif.sourceComplementaire"
        placeholder="Source complémentaire…"
        rows="2"
      ></textarea>
      <div v-else-if="ficheActif.sourceComplementaire" class="fi-source-item">
        <span class="fi-dash">-</span>{{ ficheActif.sourceComplementaire }}
      </div>
    </div>

    <!-- 4. TESTS D'AUDIT -->
    <div class="fi-section-title">Tests d'audit — {{ ficheActif.testRef }}</div>
    <div class="fi-tests-list">
      <template v-for="(testItem, testIdx) in testsDetailList" :key="testIdx">

        <!-- Ligne test -->
        <div class="fi-test-row" :class="getTestResultValue(testIdx) ? 'fi-test-row--done' : ''">
          <div class="fi-test-num">{{ testIdx + 1 }}</div>
          <div class="fi-test-lbl">{{ testItem.libelle }}</div>

          <!-- Résultat select -->
          <select
            v-if="!isLocked"
            class="fi-result-sel"
            :value="getTestResultValue(testIdx)"
            @change="setTestResultValue(testIdx, ($event.target as HTMLSelectElement).value)"
          >
            <option value="">— résultat —</option>
            
          </select>
          <span
            v-else
            class="fi-result-badge"
            :class="'fi-rb--' + getTestResultValue(testIdx)"
          >{{ getTestResultLabel(testIdx) || '—' }}</span>

          <!-- Bouton outil lié -->
          <button
            class="fi-outil-btn"
            :class="'fi-outil-btn--' + testItem.outilRecommandation"
            :style="`--oc:${outilColor(testItem.outilRecommandation)}`"
            @click="ouvrirOutilPourTest(testItem.outilRecommandation, testIdx)"
            :title="`Ouvrir l'outil ${testItem.outilRecommandation}`"
          >
            <i class="ti ti-tool"></i>
            Outil {{ testItem.outilRecommandation }}
            <span
              v-if="getTestResultValue(testIdx)"
              class="fi-outil-dot"
            ></span>
          </button>
        </div>

        <!-- Constat / Preuve sous chaque test -->
        <div class="fi-constat-row">
          <div class="fi-constat-cell">
            <label class="fi-mini-lbl">- Constat / Observation</label>
            <textarea
              v-if="!isLocked"
              class="fi-ta fi-ta--sm"
              rows="2"
              :value="getTestConstatValue(testIdx)"
              @input="setTestConstatValue(testIdx, ($event.target as HTMLTextAreaElement).value)"
              :placeholder="testItem.constatDefaut"
            ></textarea>
            <div v-else class="fi-ro">{{ getTestConstatValue(testIdx) || testItem.constatDefaut }}</div>
          </div>
          <div class="fi-preuve-cell">
            <label class="fi-mini-lbl">- Référence de preuve</label>
            <input
              v-if="!isLocked"
              type="text"
              class="fi-inp fi-inp--sm"
              :value="getTestPreuveValue(testIdx)"
              @input="setTestPreuveValue(testIdx, ($event.target as HTMLInputElement).value)"
              :placeholder="testItem.preuveDefaut"
            />
            <div v-else class="fi-ro">
              <i class="ti ti-paperclip"></i>
              {{ getTestPreuveValue(testIdx) || testItem.preuveDefaut }}
            </div>
          </div>
        </div>

      </template>
    </div>

    <!-- 5. RÉSULTATS GLOBAUX DU TEST -->
    <div class="fi-section-title fi-section-title--light">Résultats du test d'audit</div>
    <div class="fi-global-result-box">
      <div
        v-for="(testItem, testIdx) in testsDetailList"
        :key="testIdx"
        v-if="getTestConstatValue(testIdx)"
        class="fi-global-item"
      >
        <span class="fi-dash">-</span>
        <span class="fi-global-constat">{{ getTestConstatValue(testIdx) }}</span>
        <span class="fi-result-badge fi-rb--sm" :class="'fi-rb--' + getTestResultValue(testIdx)">
          {{ getTestResultLabel(testIdx) }}
        </span>
      </div>
      <div v-if="!testsDetailList.some((_,i) => getTestConstatValue(i))" class="fi-global-placeholder">
        Les constats saisis ci-dessus apparaîtront ici.
      </div>
    </div>

  </div><!-- /ft-fiche-body -->

  <!-- Footer -->
  <div class="ft-fiche-footer">
    <button class="ft-btn ft-btn--ghost" @click="ficheActif = null">Fermer</button>
    <button v-if="!isLocked" class="ft-btn ft-btn--save" :disabled="processing" @click="saveFiche">
      <i class="ti ti-device-floppy"></i> Enregistrer
    </button>
  </div>

</div>

        <!-- ◈ VUE CONSTAT ────────────────────────────────────────── -->
        <div v-if="constatActif && !outilActif && !ficheActif" class="ft-constat-view">
          <div class="ft-constat-back">
            <button class="ft-btn ft-btn--ghost ft-btn--sm" @click="constatActif = null">
              <i class="ti ti-arrow-left"></i> Retour aux tests
            </button>
            <span class="ft-constat-ref">{{ constatActif.testRef }} — Constat &amp; Preuve</span>
          </div>
          <div class="ft-constat-body">
            <div class="fc-sect">
              <label class="fc-lbl">Résultat du test</label>
              <select
                v-if="!isLocked"
                class="fc-sel"
                :value="getResultat(constatActif.objNum, constatActif.testRef)"
                @change="setResultat(constatActif.objNum, constatActif.testRef, ($event.target as HTMLSelectElement).value)"
              >
                <option value="">— Sélectionner —</option>
                <option value="conforme">✅ Conforme</option>
                <option value="ecart">⚠️ Écart</option>
                <option value="nc">❌ Non conforme</option>
                <option value="na">N/A</option>
              </select>
              <span v-else class="ft-result-pill" :class="`frp--${getResultat(constatActif.objNum, constatActif.testRef)}`">
                {{ getResultat(constatActif.objNum, constatActif.testRef) || '—' }}
              </span>
            </div>
            <div class="fc-sect">
              <label class="fc-lbl">Constat / Observation</label>
              <textarea
                v-if="!isLocked"
                class="fc-ta"
                :value="getConstat(constatActif.objNum, constatActif.testRef)"
                @input="setConstat(constatActif.objNum, constatActif.testRef, ($event.target as HTMLTextAreaElement).value)"
                placeholder="Observation, écart constaté…"
                rows="10"
              ></textarea>
              <p v-else class="fc-ro">{{ getConstat(constatActif.objNum, constatActif.testRef) || '—' }}</p>
            </div>
            <div class="fc-sect">
              <label class="fc-lbl">Référence de preuve</label>
              <input
                v-if="!isLocked"
                type="text"
                class="fc-inp"
                :value="getPreuve(constatActif.objNum, constatActif.testRef)"
                @input="setPreuve(constatActif.objNum, constatActif.testRef, ($event.target as HTMLInputElement).value)"
                placeholder="Réf. document, pièce jointe…"
              />
              <p v-else class="fc-ro">{{ getPreuve(constatActif.objNum, constatActif.testRef) || '—' }}</p>
            </div>
            <div class="fc-foot">
              <button class="ft-btn ft-btn--ghost" @click="constatActif = null">Fermer</button>
              <button v-if="!isLocked" class="ft-btn ft-btn--save" :disabled="processing" @click="submit(true)">
                <i class="ti ti-device-floppy"></i> Enregistrer
              </button>
            </div>
          </div>
        </div>

        <!-- ◈ VUE OUTIL PLEINE PAGE ──────────────────────────────── -->
        <div v-if="outilActif && !ficheActif && !constatActif" class="ft-outil-page">
          <div class="ft-outil-topbar" :style="`--oc:${outilActif.color}`">
            <button class="ft-outil-back" @click="fermerOutil"><i class="ti ti-arrow-left"></i> Retour aux tests</button>
            <div class="ft-outil-topbar__center">
              <span class="ft-outil-num">{{ outilActif.code }}</span>
              <div>
                <div class="ft-outil-title">{{ outilActif.title }}</div>
                <div class="ft-outil-sub">
                  {{ outilActif.testRef }}<span v-if="outilActif.procIdx !== null"> · Proc. {{ (outilActif.procIdx ?? 0) + 1 }}</span>
                </div>
              </div>
            </div>
            <div class="ft-outil-topbar__right">
              <button v-if="!isLocked" class="ft-btn ft-btn--save ft-btn--sm" :disabled="outilSaving" @click="sauvegarderOutil">
                <i class="ti ti-device-floppy"></i> Enregistrer
              </button>
              <button class="ft-outil-back" @click="fermerOutil"><i class="ti ti-x"></i></button>
            </div>
          </div>

          <div class="ft-outil-body">

            <!-- OUTIL I — GRILLE D'ENTRETIEN -->
            <template v-if="outilActif.code === 'I'">
              <div class="fo-card">
                <h3 class="fo-card__title">Informations générales</h3>
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.I.date" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Interlocuteur(s)</label>
                    <input type="text" class="fo-inp" v-model="dd.I.interlocuteurs" :disabled="isLocked" />
                  </div>
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Objectif</label>
                    <textarea class="fo-ta" v-model="dd.I.objectif_audit" :disabled="isLocked" rows="2"></textarea>
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Questions</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.I.questions.push({ type: 'Ouverte', question: '', reponse: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Type</th>
                        <th>Question</th>
                        <th>Réponse</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.I.questions.length">
                        <td colspan="5" class="fo-ec">Aucune question</td>
                      </tr>
                      <tr v-for="(q, qi) in dd.I.questions" :key="qi">
                        <td class="tc fo-n">{{ qi + 1 }}</td>
                        <td>
                          <select class="fo-sel-xs" v-model="q.type" :disabled="isLocked">
                            <option>Ouverte</option>
                            <option>Fermée</option>
                          </select>
                        </td>
                        <td><textarea class="fo-ta-sm" v-model="q.question" :disabled="isLocked" rows="2"></textarea></td>
                        <td><textarea class="fo-ta-sm" v-model="q.reponse" :disabled="isLocked" rows="2"></textarea></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.I.questions.splice(qi, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-f fo-f--full">
                  <label class="fo-lbl">Synthèse</label>
                  <textarea class="fo-ta" v-model="dd.I.synthese" :disabled="isLocked" rows="4"></textarea>
                </div>
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Signature Auditeur</label>
                    <input type="text" class="fo-inp" v-model="dd.I.sig_auditeur" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Signature Interlocuteur</label>
                    <input type="text" class="fo-inp" v-model="dd.I.sig_interlocuteur" :disabled="isLocked" />
                  </div>
                </div>
              </div>
            </template>

            <!-- OUTIL II — ANALYSE DES TÂCHES -->
            <template v-else-if="outilActif.code === 'II'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Processus</label>
                    <input type="text" class="fo-inp" v-model="dd.II.processus" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.II.date" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Acteurs</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.II.acteurs.push('')"><i class="ti ti-plus"></i></button>
                </div>
                <div class="fo-acteurs">
                  <div v-for="(a, ai) in dd.II.acteurs" :key="ai" class="fo-acteur">
                    <span class="fo-acteur__badge" :style="`background:${acteurColors[ai % acteurColors.length]}`">A{{ ai + 1 }}</span>
                    <input type="text" class="fo-inp-sm" v-model="dd.II.acteurs[ai]" :disabled="isLocked" />
                    <button v-if="!isLocked && dd.II.acteurs.length > 1" class="fo-del" @click="retirerActeur(ai)">
                      <i class="ti ti-x"></i>
                    </button>
                  </div>
                </div>
                <p class="fo-legend">R=Réalisé, A=Approuvé, C=Consulté, I=Informé</p>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Tâches</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.II.taches.push({ libelle: '', roles: new Array(dd.II.acteurs.length).fill('') })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Tâche</th>
                        <th v-for="(_, ai) in dd.II.acteurs" :key="ai" class="tc">A{{ ai + 1 }}</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.II.taches.length">
                        <td :colspan="2 + dd.II.acteurs.length" class="fo-ec">Aucune tâche</td>
                      </tr>
                      <tr v-for="(t, ti) in dd.II.taches" :key="ti">
                        <td class="tc fo-n">{{ ti + 1 }}</td>
                        <td><input class="fo-inp-sm" type="text" v-model="t.libelle" :disabled="isLocked" /></td>
                        <td v-for="(_, ai) in dd.II.acteurs" :key="ai" class="tc">
                          <select class="fo-sel-xs" v-model="t.roles[ai]" :disabled="isLocked">
                            <option value="">—</option>
                            <option>R</option>
                            <option>A</option>
                            <option>C</option>
                            <option>I</option>
                          </select>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.II.taches.splice(ti, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL III — DIAGRAMME DE FLUX -->
            <template v-else-if="outilActif.code === 'III'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Processus</label>
                    <input type="text" class="fo-inp" v-model="dd.III.processus" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Version</label>
                    <input type="text" class="fo-inp" v-model="dd.III.version" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.III.date" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Activités</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.III.activites.push({ libelle: '', acteur: '', entrant: '', sortant: '', documents: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Activité</th>
                        <th>Acteur</th>
                        <th>Entrant</th>
                        <th>Sortant</th>
                        <th>Doc</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.III.activites.length">
                        <td colspan="7" class="fo-ec">Aucune activité</td>
                      </tr>
                      <tr v-for="(a, ai) in dd.III.activites" :key="ai">
                        <td class="tc fo-n">{{ ai + 1 }}</td>
                        <td><textarea class="fo-ta-sm" v-model="a.libelle" :disabled="isLocked" rows="2"></textarea></td>
                        <td><input class="fo-inp-sm" v-model="a.acteur" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="a.entrant" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="a.sortant" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="a.documents" :disabled="isLocked" /></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.III.activites.splice(ai, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="fo-card">
                <label class="fo-lbl">Description narrative</label>
                <textarea class="fo-ta" v-model="dd.III.description_narrative" :disabled="isLocked" rows="4"></textarea>
              </div>
            </template>

            <!-- OUTIL IV — APPROCHE PROCESSUS -->
            <template v-else-if="outilActif.code === 'IV'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Domaine</label>
                    <input type="text" class="fo-inp" v-model="dd.IV.domaine" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.IV.date" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Processus de réalisation</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.IV.processus.realisation.push({ nom: '', finalite: '', entrants: '', sortants: '', activites: '', clients: '', fournisseurs: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th>Nom</th>
                        <th>Finalité</th>
                        <th>Entrants</th>
                        <th>Sortants</th>
                        <th>Activités</th>
                        <th>Clients</th>
                        <th>Fournisseurs</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.IV.processus.realisation.length">
                        <td colspan="8" class="fo-ec">Aucun processus</td>
                      </tr>
                      <tr v-for="(p, pi) in dd.IV.processus.realisation" :key="pi">
                        <td><input class="fo-inp-sm" v-model="p.nom" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="p.finalite" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="p.entrants" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="p.sortants" :disabled="isLocked" /></td>
                        <td><textarea class="fo-ta-sm" v-model="p.activites" :disabled="isLocked" rows="2"></textarea></td>
                        <td><input class="fo-inp-sm" v-model="p.clients" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="p.fournisseurs" :disabled="isLocked" /></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.IV.processus.realisation.splice(pi, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL V — TEST DE CHEMINEMENT -->
            <template v-else-if="outilActif.code === 'V'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Transaction</label>
                    <input type="text" class="fo-inp" v-model="dd.V.transaction" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Référence</label>
                    <input type="text" class="fo-inp" v-model="dd.V.reference" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.V.date_test" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Étapes</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.V.etapes.push({ description: '', acteur: '', document: '', controle: '', conforme: '', observation: '', preuve: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Description</th>
                        <th>Acteur</th>
                        <th>Document</th>
                        <th class="tc">Contrôle</th>
                        <th class="tc">Conforme</th>
                        <th>Observation</th>
                        <th>Preuve</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.V.etapes.length">
                        <td colspan="9" class="fo-ec">Aucune étape</td>
                      </tr>
                      <tr v-for="(e, ei) in dd.V.etapes" :key="ei">
                        <td class="tc">{{ ei + 1 }}</td>
                        <td><textarea class="fo-ta-sm" v-model="e.description" :disabled="isLocked" rows="2"></textarea></td>
                        <td><input class="fo-inp-sm" v-model="e.acteur" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="e.document" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="e.controle" :disabled="isLocked">
                            <option>—</option>
                            <option>Oui</option>
                            <option>Non</option>
                          </select>
                        </td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="e.conforme" :disabled="isLocked">
                            <option>—</option>
                            <option value="Oui">✅ Oui</option>
                            <option value="Non">❌ Non</option>
                          </select>
                        </td>
                        <td><textarea class="fo-ta-sm" v-model="e.observation" :disabled="isLocked" rows="2"></textarea></td>
                        <td><input class="fo-inp-sm" v-model="e.preuve" :disabled="isLocked" /></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.V.etapes.splice(ei, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL VI — HIÉRARCHISATION DES RISQUES -->
            <template v-else-if="outilActif.code === 'VI'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Domaine</label>
                    <input type="text" class="fo-inp" v-model="dd.VI.domaine" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.VI.date" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Risques</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.VI.risques.push({ risque: '', probabilite: 0, impact: 0, criticite: 0 })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Risque</th>
                        <th class="tc">Probabilité</th>
                        <th class="tc">Impact</th>
                        <th class="tc">P×I</th>
                        <th class="tc">Niveau</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.VI.risques.length">
                        <td colspan="7" class="fo-ec">Aucun risque</td>
                      </tr>
                      <tr v-for="(r, ri) in dd.VI.risques" :key="ri">
                        <td class="tc">{{ ri + 1 }}</td>
                        <td><textarea class="fo-ta-sm" v-model="r.risque" :disabled="isLocked" rows="2"></textarea></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="r.probabilite" @change="viRecalc(r)" :disabled="isLocked">
                            <option value="0">—</option>
                            <option value="1">Faible</option>
                            <option value="2">Moyenne</option>
                            <option value="3">Forte</option>
                          </select>
                        </td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="r.impact" @change="viRecalc(r)" :disabled="isLocked">
                            <option value="0">—</option>
                            <option value="1">Faible</option>
                            <option value="2">Moyen</option>
                            <option value="3">Fort</option>
                          </select>
                        </td>
                        <td class="tc">
                          <span class="fo-crit" :class="viLvlClass(r.criticite)">{{ r.criticite || 0 }}</span>
                        </td>
                        <td class="tc">
                          <span :class="viLvlClass(r.criticite)">{{ viLvlLbl(r.criticite) }}</span>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.VI.risques.splice(ri, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL VII — RÉFÉRENTIEL D'AUDIT -->
            <template v-else-if="outilActif.code === 'VII'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.VII.date" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Cadre</label>
                    <select class="fo-inp" v-model="dd.VII.cadre_ref" :disabled="isLocked">
                      <option>COSO</option>
                      <option>AMF</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Matrice</h3>
                  <button v-if="!isLocked" class="fo-add" @click="viiAjouterLigne"><i class="ti ti-plus"></i></button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Objectif</th>
                        <th>Risque</th>
                        <th>Contrôle</th>
                        <th class="tc">Type</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.VII.lignes.length">
                        <td colspan="6" class="fo-ec">Aucune ligne</td>
                      </tr>
                      <tr v-for="(l, li) in dd.VII.lignes" :key="li">
                        <td class="tc">{{ li + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="l.objectif_processus" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="l.risque_associe" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="l.controle_cle" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="l.type_controle" :disabled="isLocked">
                            <option>—</option>
                            <option>Préventif</option>
                            <option>Détectif</option>
                          </select>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.VII.lignes.splice(li, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL VIII — CAUSE / EFFET -->
            <template v-else-if="outilActif.code === 'VIII'">
              <div class="fo-card">
                <div class="fo-f fo-f--full">
                  <label class="fo-lbl">Effet (dysfonctionnement)</label>
                  <input type="text" class="fo-inp" v-model="dd.VIII.effet" :disabled="isLocked" />
                </div>
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.VIII.date" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Participants</label>
                    <input type="text" class="fo-inp" v-model="dd.VIII.participants" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Causes</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.VIII.causes.push({ categorie: '', cause_primaire: '', detail_preuve: '', priorite: 0 })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th>Catégorie</th>
                        <th>Cause</th>
                        <th>Preuve</th>
                        <th class="tc">Priorité</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.VIII.causes.length">
                        <td colspan="5" class="fo-ec">Aucune cause</td>
                      </tr>
                      <tr v-for="(c, ci) in dd.VIII.causes" :key="ci">
                        <td><input class="fo-inp-sm" v-model="c.categorie" :disabled="isLocked" placeholder="Méthode, Matière…" /></td>
                        <td><input class="fo-inp-sm" v-model="c.cause_primaire" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="c.detail_preuve" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="c.priorite" :disabled="isLocked">
                            <option value="0">—</option>
                            <option value="1">Haute</option>
                            <option value="2">Moyenne</option>
                            <option value="3">Faible</option>
                          </select>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.VIII.causes.splice(ci, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="fo-card">
                <label class="fo-lbl">Synthèse</label>
                <textarea class="fo-ta" v-model="dd.VIII.synthese" :disabled="isLocked" rows="4"></textarea>
              </div>
            </template>

            <!-- OUTIL IX — QCI -->
            <template v-else-if="outilActif.code === 'IX'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Processus</label>
                    <input type="text" class="fo-inp" v-model="dd.IX.processus" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.IX.date" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Questions</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.IX.questions.push({ question: '', reponse: '', constat: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Question</th>
                        <th class="tc">Réponse</th>
                        <th>Constat</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.IX.questions.length">
                        <td colspan="5" class="fo-ec">Aucune question</td>
                      </tr>
                      <tr v-for="(q, qi) in dd.IX.questions" :key="qi">
                        <td class="tc">{{ qi + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="q.question" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="q.reponse" :disabled="isLocked">
                            <option value="">—</option>
                            <option value="oui">✅ Oui</option>
                            <option value="non">❌ Non</option>
                            <option value="partiel">⚠️ Partiel</option>
                          </select>
                        </td>
                        <td><input class="fo-inp-sm" v-model="q.constat" :disabled="isLocked" /></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.IX.questions.splice(qi, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="fo-card">
                <label class="fo-lbl">Conclusion</label>
                <textarea class="fo-ta" v-model="dd.IX.conclusion" :disabled="isLocked" rows="3"></textarea>
              </div>
            </template>

            <!-- OUTIL X — BRAINSTORMING -->
            <template v-else-if="outilActif.code === 'X'">
              <div class="fo-card">
                <div class="fo-f fo-f--full">
                  <label class="fo-lbl">Sujet</label>
                  <input type="text" class="fo-inp" v-model="dd.X.sujet" :disabled="isLocked" />
                </div>
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Animateur</label>
                    <input type="text" class="fo-inp" v-model="dd.X.animateur" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.X.date" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Idées</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.X.idees.push({ idee: '', emise_par: '', priorite: 0 })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Idée</th>
                        <th>Émis par</th>
                        <th class="tc">Priorité</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.X.idees.length">
                        <td colspan="5" class="fo-ec">Aucune idée</td>
                      </tr>
                      <tr v-for="(id, ii) in dd.X.idees" :key="ii">
                        <td class="tc">{{ ii + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="id.idee" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="id.emise_par" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="id.priorite" :disabled="isLocked">
                            <option value="0">—</option>
                            <option value="1">Haute</option>
                            <option value="2">Moyenne</option>
                            <option value="3">Faible</option>
                          </select>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.X.idees.splice(ii, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL XI — PISTE D'AUDIT -->
            <template v-else-if="outilActif.code === 'XI'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Opération testée</label>
                    <input type="text" class="fo-inp" v-model="dd.XI.operation_testee" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Processus</label>
                    <input type="text" class="fo-inp" v-model="dd.XI.processus" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-table-wrap">
                <table class="fo-t">
                  <thead>
                    <tr>
                      <th>Étape</th>
                      <th>Document</th>
                      <th>Identifiant</th>
                      <th>Date</th>
                      <th class="tc">Présent</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-if="!dd.XI.etapes.length">
                      <td colspan="5" class="fo-ec">Aucune étape</td>
                    </tr>
                    <tr v-for="(e, ei) in dd.XI.etapes" :key="ei">
                      <td><input class="fo-inp-sm" v-model="e.label" :disabled="isLocked" /></td>
                      <td><input class="fo-inp-sm" v-model="e.document" :disabled="isLocked" /></td>
                      <td><input class="fo-inp-sm" v-model="e.identifiant" :disabled="isLocked" /></td>
                      <td><input class="fo-inp-sm" type="date" v-model="e.date" :disabled="isLocked" /></td>
                      <td class="tc">
                        <select class="fo-sel-xs" v-model="e.present" :disabled="isLocked">
                          <option>—</option>
                          <option value="Oui">✅ Oui</option>
                          <option value="Non">❌ Non</option>
                        </select>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="fo-card">
                <label class="fo-lbl">Conclusion</label>
                <textarea class="fo-ta" v-model="dd.XI.conclusion" :disabled="isLocked" rows="3"></textarea>
              </div>
            </template>

            <!-- OUTIL XII — CIRCULARISATION -->
            <template v-else-if="outilActif.code === 'XII'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Date envoi</label>
                    <input type="date" class="fo-inp" v-model="dd.XII.date_envoi" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Date limite</label>
                    <input type="date" class="fo-inp" v-model="dd.XII.date_limite_reponse" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Demandes</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.XII.demandes.push({ nom_tiers: '', element_confirmer: '', montant_envoye: '', statut_reponse: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Tiers</th>
                        <th>Élément à confirmer</th>
                        <th>Montant</th>
                        <th class="tc">Statut</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.XII.demandes.length">
                        <td colspan="6" class="fo-ec">Aucune demande</td>
                      </tr>
                      <tr v-for="(d, di) in dd.XII.demandes" :key="di">
                        <td class="tc">{{ di + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="d.nom_tiers" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="d.element_confirmer" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" type="number" v-model="d.montant_envoye" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="d.statut_reponse" :disabled="isLocked">
                            <option>—</option>
                            <option value="ok">✅ Conforme</option>
                            <option value="ecart">❌ Écart</option>
                          </select>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.XII.demandes.splice(di, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL XIII — AUDIT ANALYTIQUE -->
            <template v-else-if="outilActif.code === 'XIII'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f fo-f--full">
                    <label class="fo-lbl">Source données</label>
                    <input type="text" class="fo-inp" v-model="dd.XIII.source_donnees" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Période</label>
                    <input type="text" class="fo-inp" v-model="dd.XIII.periode" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Indicateurs</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.XIII.indicateurs.push({ indicateur: '', valeur_n1: '', valeur_n: '', ecart_n_n1: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Indicateur</th>
                        <th class="tc">N-1</th>
                        <th class="tc">N</th>
                        <th class="tc">Écart</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.XIII.indicateurs.length">
                        <td colspan="6" class="fo-ec">Aucun indicateur</td>
                      </tr>
                      <tr v-for="(ind, ii) in dd.XIII.indicateurs" :key="ii">
                        <td class="tc">{{ ii + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="ind.indicateur" :disabled="isLocked" /></td>
                        <td class="tc"><input class="fo-inp-sm" type="number" v-model="ind.valeur_n1" :disabled="isLocked" /></td>
                        <td class="tc"><input class="fo-inp-sm" type="number" v-model="ind.valeur_n" :disabled="isLocked" /></td>
                        <td class="tc"><input class="fo-inp-sm" v-model="ind.ecart_n_n1" :disabled="isLocked" /></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.XIII.indicateurs.splice(ii, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

            <!-- OUTIL XIV — OBSERVATION DIRECTE -->
            <template v-else-if="outilActif.code === 'XIV'">
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Date</label>
                    <input type="date" class="fo-inp" v-model="dd.XIV.date_observation" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Auditeur</label>
                    <input type="text" class="fo-inp" v-model="dd.XIV.auditeur" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Localisation</label>
                    <input type="text" class="fo-inp" v-model="dd.XIV.localisation" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Constats</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.XIV.constats.push({ element_observe: '', conforme_referentiel: '', ecart_constate: '', preuve: '' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Élément observé</th>
                        <th class="tc">Conforme</th>
                        <th>Constat</th>
                        <th>Preuve</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.XIV.constats.length">
                        <td colspan="6" class="fo-ec">Aucun constat</td>
                      </tr>
                      <tr v-for="(c, ci) in dd.XIV.constats" :key="ci">
                        <td class="tc">{{ ci + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="c.element_observe" :disabled="isLocked" /></td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="c.conforme_referentiel" :disabled="isLocked">
                            <option>—</option>
                            <option value="oui">✅ Oui</option>
                            <option value="non">❌ Non</option>
                          </select>
                        </td>
                        <td><input class="fo-inp-sm" v-model="c.ecart_constate" :disabled="isLocked" /></td>
                        <td><input class="fo-inp-sm" v-model="c.preuve" :disabled="isLocked" /></td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.XIV.constats.splice(ci, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Points forts</label>
                    <textarea class="fo-ta" v-model="dd.XIV.points_forts" :disabled="isLocked" rows="3"></textarea>
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Points faibles</label>
                    <textarea class="fo-ta" v-model="dd.XIV.points_faibles" :disabled="isLocked" rows="3"></textarea>
                  </div>
                </div>
                <label class="fo-lbl">Conclusion</label>
                <textarea class="fo-ta" v-model="dd.XIV.conclusion" :disabled="isLocked" rows="3"></textarea>
              </div>
            </template>

            <!-- OUTIL XV — ÉCHANTILLONNAGE -->
            <template v-else-if="outilActif.code === 'XV'">
              <div class="fo-card">
                <div class="fo-f fo-f--full">
                  <label class="fo-lbl">Population</label>
                  <input type="text" class="fo-inp" v-model="dd.XV.population_reference" :disabled="isLocked" />
                </div>
                <div class="fo-g2">
                  <div class="fo-f">
                    <label class="fo-lbl">Taille N</label>
                    <input type="number" class="fo-inp" v-model.number="dd.XV.taille_population" :disabled="isLocked" />
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Niveau confiance</label>
                    <select class="fo-inp" v-model="dd.XV.niveau_confiance" @change="xvSetNiveauConfiance(dd.XV.niveau_confiance)" :disabled="isLocked">
                      <option value="90">90%</option>
                      <option value="95">95%</option>
                      <option value="99">99%</option>
                    </select>
                  </div>
                  <div class="fo-f">
                    <label class="fo-lbl">Erreur max</label>
                    <input type="number" class="fo-inp" v-model.number="dd.XV.erreur_max" @change="xvRecalc" step="0.01" :disabled="isLocked" />
                  </div>
                </div>
              </div>
              <div class="fo-card fo-card--xv-calcul">
                <div class="fo-xv-result-row">
                  <div class="fo-xv-result-card">
                    <span class="fo-xv-result-n">{{ dd.XV.taille_calculee ?? '—' }}</span>
                    <small>Taille calculée</small>
                  </div>
                  <div class="fo-xv-result-card">
                    <span class="fo-xv-result-n">{{ dd.XV.taille_retenue ?? '—' }}</span>
                    <small>Taille retenue</small>
                  </div>
                </div>
              </div>
              <div class="fo-card">
                <div class="fo-card__hd">
                  <h3 class="fo-card__title">Échantillon</h3>
                  <button v-if="!isLocked" class="fo-add" @click="dd.XV.elements.push({ reference: '', valeur: null, attribut_present: '', anomalie_detectee: 'non' })">
                    <i class="ti ti-plus"></i>
                  </button>
                </div>
                <div class="fo-table-wrap">
                  <table class="fo-t">
                    <thead>
                      <tr>
                        <th class="tc">N°</th>
                        <th>Référence</th>
                        <th v-if="dd.XV.type_sondage === 'valeur'">Valeur</th>
                        <th v-else>Attribut</th>
                        <th class="tc">Anomalie</th>
                        <th v-if="!isLocked"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-if="!dd.XV.elements.length">
                        <td colspan="5" class="fo-ec">Aucun élément</td>
                      </tr>
                      <tr v-for="(e, ei) in dd.XV.elements" :key="ei">
                        <td class="tc">{{ ei + 1 }}</td>
                        <td><input class="fo-inp-sm" v-model="e.reference" :disabled="isLocked" /></td>
                        <td v-if="dd.XV.type_sondage === 'valeur'">
                          <input class="fo-inp-sm" type="number" v-model.number="e.valeur" :disabled="isLocked" />
                        </td>
                        <td v-else>
                          <select class="fo-sel-xs" v-model="e.attribut_present" :disabled="isLocked">
                            <option value="">—</option>
                            <option value="oui">✅ Présent</option>
                            <option value="non">❌ Absent</option>
                          </select>
                        </td>
                        <td class="tc">
                          <select class="fo-sel-xs" v-model="e.anomalie_detectee" :disabled="isLocked">
                            <option value="non">Non</option>
                            <option value="oui">⚠️ Oui</option>
                          </select>
                        </td>
                        <td v-if="!isLocked">
                          <button class="fo-del" @click="dd.XV.elements.splice(ei, 1)"><i class="ti ti-x"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </template>

          </div>
        </div>

      </div>
    </div>

    <!-- ══ MODAL CHOIX OUTILS ════════════════════════════════════ -->
    <Teleport to="body">
      <Transition name="om-fade">
        <div v-if="om.visible" class="om-overlay" @click.self="om.visible = false">
          <div class="om-dialog">
            <div class="om-hd">
              <div class="om-hd__left">
                <div class="om-hd__icon"><i class="ti ti-tool"></i></div>
                <div>
                  <h2 class="om-hd__title">Outils IFACI</h2>
                  <div class="om-hd__sub">
                    <span class="om-ctx">{{ om.testRef }}</span>
                    <span v-if="om.procIdx !== null" class="om-ctx om-ctx--proc">Procédure {{ (om.procIdx ?? 0) + 1 }}</span>
                  </div>
                </div>
              </div>
              <button class="ft-ib" @click="om.visible = false"><i class="ti ti-x"></i></button>
            </div>
            <div class="om-selbar">
              <div class="om-tags">
                <span v-for="code in om.selected" :key="code" class="om-tag" :style="`--ot:${outilColor(code)}`">
                  {{ code }}<button @click="omToggle(code)">×</button>
                </span>
              </div>
              <button v-if="om.selected.length" class="om-clear" @click="om.selected = []">Effacer</button>
            </div>
            <div class="om-body">
              <div class="om-grid">
                <button
                  v-for="outil in props.outilsIfaci"
                  :key="outil.code"
                  class="om-card"
                  :class="om.selected.includes(outil.code) ? 'om-card--sel' : ''"
                  @click="omToggle(outil.code)"
                >
                  <div class="om-card__num" :style="`background:${outil.color}`">{{ outil.code }}</div>
                  <div class="om-card__body"><span class="om-card__lbl">{{ outil.label }}</span></div>
                </button>
              </div>
            </div>
            <div class="om-ft">
              <button class="ft-btn ft-btn--ghost" @click="om.visible = false">Annuler</button>
              <button class="om-confirm" :disabled="!om.selected.length" @click="omConfirmer">Ouvrir</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <!-- ══ TOAST ════════════════════════════════════════════════ -->
    <Teleport to="body">
      <Transition name="toast-pop">
        <div v-if="toast.show" class="ft-toast" :class="`ft-toast--${toast.type}`">
          <i :class="toast.type === 'success' ? 'ti ti-circle-check' : 'ti ti-alert-circle'"></i>
          {{ toast.msg }}
          <button class="ft-toast__x" @click="toast.show = false"><i class="ti ti-x"></i></button>
        </div>
      </Transition>
    </Teleport>
  </VerticalLayoutAudit>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onBeforeUnmount } from 'vue'
import { router } from '@inertiajs/vue3'
import VerticalLayoutAudit from '@/layouts/VerticalLayoutAudit.vue'

// ─────────────────────────────────────────────────────────────────
// PROPS
// ─────────────────────────────────────────────────────────────────
const props = withDefaults(defineProps<{
  mission?: any
  auditorRole?: string
  auditeurNom?: string
  missionId?: number
  assignmentId?: number
  form?: any
  phaseAuditeurs?: any[]
  programmeData?: {
    found: boolean
    programme_code?: string
    programme_label?: string
    programme_status?: string
    objectifs?: any[]
    total_objectifs?: number
    total_tests?: number
  }
  outilsIfaci?: { code: string; label: string; icon: string; color: string }[]
  processus?: any[]
  risquesMission?: any[]
  rciLignes?: any[]
  missionContext?: {
    mission_id?: number
    assignment_id?: number
    mission_libelle?: string
    code_mission?: string
  }
  backUrl?: string
  urlStore?: string
  urlUpdate?: string
  urlSoumettre?: string
  urlValider?: string
}>(), {
  phaseAuditeurs: () => [],
  outilsIfaci: () => [],
  processus: () => [],
  risquesMission: () => [],
  rciLignes: () => [],
  missionContext: () => ({}),
  programmeData: () => ({ found: false, objectifs: [], total_objectifs: 0, total_tests: 0 }),
})

// ─────────────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────────────
const form = reactive<any>({
  id: null,
  code: '',
  validation_status: 'draft',
  validation_note: '',
  ...(props.form ?? {}),
})

const dynUrls = reactive({
  update: props.urlUpdate ?? null,
  soumettre: props.urlSoumettre ?? null,
  valider: props.urlValider ?? null,
})

const processing  = ref(false)
const outilSaving = ref(false)
const toast       = ref({ show: false, type: 'success', msg: '' })
let _tt: ReturnType<typeof setTimeout> | null = null

const constatActif = ref<null | { objNum: string; testRef: string }>(null)
const ficheActif   = ref<null | { obj: any; test: any; objNum: string; testRef: string; oi: number; ti: number; date: string }>(null)
const outilActif   = ref<null | { code: string; title: string; color: string; testRef: string; objNum: string; procIdx: number | null; dataKey: string }>(null)

// ─────────────────────────────────────────────────────────────────
// RÉSULTATS
// ─────────────────────────────────────────────────────────────────
const resultatsMap = reactive<Record<string, { resultat: string; constat: string; preuve: string }>>({})

if (props.form?.resultats) {
  const arr = Array.isArray(props.form.resultats)
    ? props.form.resultats
    : (() => { try { return JSON.parse(props.form.resultats) } catch { return [] } })()
  arr.forEach((r: any) => {
    resultatsMap[r.obj_num + '::' + r.test_ref] = {
      resultat: r.resultat ?? '',
      constat:  r.constat  ?? '',
      preuve:   r.preuve   ?? '',
    }
  })
}

// Résultats sous-tests (fiche détaillée)
const subTestResultsMap = reactive<Record<string, { resultat: string; constat: string; preuve: string }>>({})

// ─────────────────────────────────────────────────────────────────
// OUTILS LIÉS
// ─────────────────────────────────────────────────────────────────
const outilsProcsMap = reactive<Record<string, string[]>>({})
const outilsDataMap  = reactive<Record<string, any>>({})

if (props.form?.outils_data) {
  const arr = Array.isArray(props.form.outils_data)
    ? props.form.outils_data
    : (() => { try { return JSON.parse(props.form.outils_data) } catch { return [] } })()
  arr.forEach((item: any) => {
    if (item?._key && item?._code) {
      outilsDataMap[item._key] = item
      const pk = item._key.split('::').slice(1).join('::')
      if (!outilsProcsMap[pk]) outilsProcsMap[pk] = []
      if (!outilsProcsMap[pk].includes(item._code)) outilsProcsMap[pk].push(item._code)
    }
  })
}

// ─────────────────────────────────────────────────────────────────
// DONNÉES OUTILS (dd)
// ─────────────────────────────────────────────────────────────────
const dd = reactive<any>({
  I:    { date: '', interlocuteurs: '', objectif_audit: '', synthese: '', sig_auditeur: '', sig_interlocuteur: '', questions: [] },
  II:   { date: '', processus: '', observations: '', acteurs: ['', '', ''], taches: [] },
  III:  { date: '', processus: '', version: '', description_narrative: '', synthese_validations: '', activites: [] },
  IV:   { date: '', domaine: '', processus: { realisation: [], management: [], support: [] } },
  V:    { date_test: '', transaction: '', reference: '', processus: '', synthese_ecarts: '', conclusion: '', etapes: [], reponses_verification: [] },
  VI:   { date: '', domaine: '', processus_id: '', risques: [] },
  VII:  { date: '', cadre_ref: 'COSO', lignes: [] },
  VIII: { date: '', effet: '', description_effet: '', participants: '', synthese: '', causes: [] },
  IX:   { date: '', processus: '', cadre_reference: 'COSO', conclusion: '', questions: [] },
  X:    { date: '', sujet: '', animateur: '', participants: '', duree: '', idees: [], actions: [] },
  XI:   { operation_testee: '', identifiant_unique: '', processus: '', conclusion: '', etapes: [], criteres: [] },
  XII:  { date_envoi: '', date_limite_reponse: '', auditeur_responsable: '', demandes: [] },
  XIII: { date: '', source_donnees: '', periode: '', conclusion: '', indicateurs: [], analyse_ecarts: [] },
  XIV:  { date_observation: '', heure_debut: '', heure_fin: '', auditeur: '', localisation: '', interlocuteurs_presents: '', objectif_audit: '', tache_local_observer: '', elements_verifier: '', pieces_attendues: '', points_forts: '', points_faibles: '', conclusion: '', constats: [] },
  XV:   { objectif_audit: '', population_reference: '', objet_test: '', type_sondage: 'attribut', taille_population: null, niveau_confiance: 95, erreur_max: 0.05, ecart_type_exploratoire: null, taux_presence_exploratoire: 0.5, taille_calculee: null, taille_retenue: null, intervalle_confiance: '', conclusion: '', elements: [] },
})

// ─────────────────────────────────────────────────────────────────
// MODAL OUTILS
// ─────────────────────────────────────────────────────────────────
const om = reactive({
  visible: false,
  selected: [] as string[],
  testRef: '',
  procIdx: null as number | null,
  objNum: '',
  obj: null as any,
  test: null as any,
  oi: 0,
  ti: 0,
})

// ─────────────────────────────────────────────────────────────────
// CONSTANTES
// ─────────────────────────────────────────────────────────────────
const acteurColors = ['#1e40af', '#065f46', '#6d28d9', '#b45309', '#be185d', '#0f172a', '#047857', '#7c3aed']

const resultatOptions = [
  { val: 'conforme', label: '✅ Conforme' },
  { val: 'ecart',    label: '⚠️ Écart' },
  { val: 'nc',       label: '❌ Non conforme' },
  { val: 'na',       label: 'N/A' },
]

const defaultObjectif = "S'assurer que le processus « Payer les factures aux fournisseurs » mis en oeuvre au sein du domaine audité est conforme au processus « Payer les factures aux fournisseurs » décrit dans la procédure P2010FFA1.8."
const defaultConstat  = "Il y a des écarts entre le processus décrit par le Directeur Financier et le processus décrit dans la procédure P2010FFA1.8."

// ─────────────────────────────────────────────────────────────────
// COMPUTED
// ─────────────────────────────────────────────────────────────────
const canManage     = computed(() => ['DM', 'CM'].includes(props.auditorRole ?? ''))
const isLocked      = computed(() => form.validation_status === 'validated' || (form.validation_status === 'in_review' && !canManage.value))
const missionLibelle = computed(() => props.mission?.libelle ?? props.missionContext?.mission_libelle ?? '')

const testsDetailList = computed(() => [
  {
    libelle: 'entretien avec le Directeur Financier',
    outilRecommandation: 'I',
    constatDefaut: 'Entretien réalisé avec Mr Peuplier',
    preuveDefaut: "Compte-rendu d'entretien",
  },

])

// ─────────────────────────────────────────────────────────────────
// HELPERS GÉNÉRAUX
// ─────────────────────────────────────────────────────────────────
function vstLbl(s: string) {
  return { draft: 'Brouillon', in_review: 'En attente', validated: 'Validé ✓' }[s] ?? s
}
function tRef(test: any, oi: number, ti: number) {
  return test.ref || ('T' + (oi + 1) + '.' + (ti + 1))
}
function pKey(on: string, tr: string, pi: number) {
  return on + '::' + tr + '::' + pi
}
function getOutilsForProc(on: string, tr: string, pi: number): string[] {
  return outilsProcsMap[pKey(on, tr, pi)] ?? []
}
function testHasAnyOutil(on: string, tr: string): boolean {
  return Object.keys(outilsProcsMap).some(k => k.startsWith(on + '::' + tr + '::') && (outilsProcsMap[k] ?? []).length > 0)
}
function testHasOutil(on: string, tr: string, code: string): boolean {
  return Object.entries(outilsProcsMap).some(([k, v]) => k.startsWith(on + '::' + tr + '::') && v.includes(code))
}
function outilColor(code: string) {
  return props.outilsIfaci?.find(o => o.code === code)?.color ?? '#374151'
}
function rk(on: string, tr: string) {
  return on + '::' + tr
}
function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return ''
  try { return new Date(dateStr).toLocaleDateString('fr-FR') } catch { return dateStr }
}
function getObjectifTexte(): string {
  if (ficheActif.value?.obj?.objectif) return ficheActif.value.obj.objectif
  if (ficheActif.value?.obj?.libelle)  return ficheActif.value.obj.libelle
  return defaultObjectif
}

// ─────────────────────────────────────────────────────────────────
// RÉSULTATS PRINCIPAUX
// ─────────────────────────────────────────────────────────────────
function getResultat(on: string, tr: string) {
  return resultatsMap[rk(on, tr)]?.resultat ?? ''
}
function setResultat(on: string, tr: string, v: string) {
  if (!resultatsMap[rk(on, tr)]) resultatsMap[rk(on, tr)] = { resultat: '', constat: '', preuve: '' }
  resultatsMap[rk(on, tr)].resultat = v
}
function getConstat(on: string, tr: string) {
  return resultatsMap[rk(on, tr)]?.constat ?? ''
}
function setConstat(on: string, tr: string, v: string) {
  if (!resultatsMap[rk(on, tr)]) resultatsMap[rk(on, tr)] = { resultat: '', constat: '', preuve: '' }
  resultatsMap[rk(on, tr)].constat = v
}
function getPreuve(on: string, tr: string) {
  return resultatsMap[rk(on, tr)]?.preuve ?? ''
}
function setPreuve(on: string, tr: string, v: string) {
  if (!resultatsMap[rk(on, tr)]) resultatsMap[rk(on, tr)] = { resultat: '', constat: '', preuve: '' }
  resultatsMap[rk(on, tr)].preuve = v
}

// ─────────────────────────────────────────────────────────────────
// SOUS-TESTS (fiche détaillée)
// ─────────────────────────────────────────────────────────────────
function getSubTestKey(testIdx: number): string {
  if (!ficheActif.value) return ''
  return `${ficheActif.value.objNum}::${ficheActif.value.testRef}::sub_${testIdx}`
}
function getTestResultValue(testIdx: number): string {
  return subTestResultsMap[getSubTestKey(testIdx)]?.resultat || ''
}
function setTestResultValue(testIdx: number, value: string) {
  const key = getSubTestKey(testIdx)
  if (!subTestResultsMap[key]) subTestResultsMap[key] = { resultat: '', constat: '', preuve: '' }
  subTestResultsMap[key].resultat = value
}
function getTestResultLabel(testIdx: number): string {
  const val = getTestResultValue(testIdx)
  return resultatOptions.find(o => o.val === val)?.label || '—'
}
function getTestConstatValue(testIdx: number): string {
  return subTestResultsMap[getSubTestKey(testIdx)]?.constat || ''
}
function setTestConstatValue(testIdx: number, value: string) {
  const key = getSubTestKey(testIdx)
  if (!subTestResultsMap[key]) subTestResultsMap[key] = { resultat: '', constat: '', preuve: '' }
  subTestResultsMap[key].constat = value
}
function getTestPreuveValue(testIdx: number): string {
  return subTestResultsMap[getSubTestKey(testIdx)]?.preuve || ''
}
function setTestPreuveValue(testIdx: number, value: string) {
  const key = getSubTestKey(testIdx)
  if (!subTestResultsMap[key]) subTestResultsMap[key] = { resultat: '', constat: '', preuve: '' }
  subTestResultsMap[key].preuve = value
}

// ─────────────────────────────────────────────────────────────────
// SÉRIALISATION
// ─────────────────────────────────────────────────────────────────
function serializeResultats() {
  const main = Object.entries(resultatsMap).map(([k, v]) => {
    const p = k.split('::')
    return { obj_num: p[0], test_ref: p.slice(1).join('::'), ...v }
  })
  const sub = Object.entries(subTestResultsMap).map(([k, v]) => {
    const p = k.split('::')
    return { obj_num: p[0], test_ref: p.slice(1).join('::'), ...v }
  })
  return [...main, ...sub]
}
function serializeOutilsData() {
  return Object.values(outilsDataMap)
}

// ─────────────────────────────────────────────────────────────────
// HELPERS OUTILS SPÉCIFIQUES
// ─────────────────────────────────────────────────────────────────
function retirerActeur(ai: number) {
  dd.II.acteurs.splice(ai, 1)
  dd.II.taches.forEach((t: any) => { if (t.roles) t.roles.splice(ai, 1) })
}

function viRecalc(r: any) {
  r.criticite = (r.probabilite || 0) * (r.impact || 0)
}
function viLvlLbl(c: number) {
  if (c >= 7) return 'Fort'; if (c >= 4) return 'Modéré'; if (c >= 1) return 'Faible'; return '—'
}
function viLvlClass(c: number) {
  if (c >= 7) return 'vi-fort'; if (c >= 4) return 'vi-mod'; if (c >= 1) return 'vi-fbl'; return ''
}

function viiAjouterLigne() {
  dd.VII.lignes.push({ objectif_processus: '', risque_associe: '', controle_cle: '', type_controle: '', composante_coso: 'Act.Ctrl', conception: '', a_tester: 'Oui', objectif_audit: '' })
}

function xvSetNiveauConfiance(nc: number) {
  dd.XV.niveau_confiance = nc
  xvRecalc()
}
function xvRecalc() {
  const t = { 90: 1.645, 95: 1.96, 99: 2.576 }[dd.XV.niveau_confiance as 90 | 95 | 99] ?? 1.96
  const eps = Number(dd.XV.erreur_max) || 0
  let n: number | null = null
  if (dd.XV.type_sondage === 'valeur') {
    const s = Number(dd.XV.ecart_type_exploratoire) || 0
    if (s > 0 && eps > 0) n = Math.ceil((t * t * s * s) / (eps * eps))
  } else {
    const p = Math.max(0.001, Math.min(0.999, Number(dd.XV.taux_presence_exploratoire) || 0.5))
    if (eps > 0) n = Math.ceil((t * t * p * (1 - p)) / (eps * eps))
  }
  dd.XV.taille_calculee = n
  dd.XV.taille_retenue  = n ? Math.ceil(n * 1.05) : null
}

// ─────────────────────────────────────────────────────────────────
// NAVIGATION
// ─────────────────────────────────────────────────────────────────
function ouvrirFiche(obj: any, test: any, oi: number, ti: number) {
  ficheActif.value = {
    obj, test, objNum: obj.num, testRef: tRef(test, oi, ti), oi, ti,
    date: new Date().toISOString().slice(0, 10),
  }
  outilActif.value  = null
  constatActif.value = null
}

async function saveFiche() {
  await submit(false)
}

function ouvrirOutilPourTest(outilCode: string, testIdx: number) {
  if (!ficheActif.value) return
  const { obj, test, oi, ti } = ficheActif.value
  const virtualTest = {
    ...test,
    libelle: testsDetailList.value[testIdx]?.libelle || test.libelle,
    ref: `${test.ref || tRef(test, oi, ti)}_${testIdx + 1}`,
  }
  ouvrirOutil(obj, virtualTest, outilCode, testIdx, oi, ti)
}

function ouvrirOutil(obj: any, test: any, code: string, procIdx: number, oi: number, ti: number) {
  const tr   = tRef(test, oi, ti)
  const pk   = pKey(obj.num, tr, procIdx)
  const dKey = code + '::' + pk
  const meta = props.outilsIfaci?.find(o => o.code === code)

  if (!outilsProcsMap[pk]) outilsProcsMap[pk] = []
  if (!outilsProcsMap[pk].includes(code)) outilsProcsMap[pk].push(code)

  const ex = outilsDataMap[dKey] ?? {}

  if (code === 'I')    Object.assign(dd.I,    { date: '', interlocuteurs: '', objectif_audit: 'Vérification : ' + (test.libelle || ''), synthese: '', sig_auditeur: props.auditeurNom ?? '', sig_interlocuteur: '', questions: [{ type: 'Ouverte', question: '', reponse: '' }], ...ex })
  else if (code === 'II')   Object.assign(dd.II,   { date: '', processus: obj._axe_rado || '', observations: '', acteurs: ['', '', ''], taches: [], ...ex })
  else if (code === 'III')  Object.assign(dd.III,  { date: '', processus: obj._axe_rado || '', version: 'V1', description_narrative: '', synthese_validations: '', activites: [], ...ex })
  else if (code === 'IV')   Object.assign(dd.IV,   { date: '', domaine: obj._process_name || '', processus: { realisation: [], management: [], support: [] }, ...ex })
  else if (code === 'V')    Object.assign(dd.V,    { date_test: '', transaction: 'Test : ' + (test.libelle || ''), reference: tr, processus: obj._axe_rado || '', synthese_ecarts: '', conclusion: '', etapes: [], reponses_verification: [], ...ex })
  else if (code === 'VI')   Object.assign(dd.VI,   { date: '', domaine: obj._axe_rado || '', processus_id: '', risques: [], ...ex })
  else if (code === 'VII')  Object.assign(dd.VII,  { date: '', cadre_ref: 'COSO', lignes: [], ...ex })
  else if (code === 'VIII') Object.assign(dd.VIII, { date: '', effet: '', description_effet: '', participants: props.auditeurNom ?? '', synthese: '', causes: [], ...ex })
  else if (code === 'IX')   Object.assign(dd.IX,   { date: '', processus: obj._axe_rado || '', cadre_reference: 'COSO', conclusion: '', questions: [], ...ex })
  else if (code === 'X')    Object.assign(dd.X,    { date: '', sujet: test.libelle ? `Analyse : ${test.libelle}` : '', animateur: props.auditeurNom ?? '', participants: '', duree: '', idees: [], actions: [], ...ex })
  else if (code === 'XI')   Object.assign(dd.XI,   { operation_testee: '', identifiant_unique: '', processus: obj._axe_rado || '', conclusion: '', etapes: [], criteres: [], ...ex })
  else if (code === 'XII')  Object.assign(dd.XII,  { date_envoi: '', date_limite_reponse: '', auditeur_responsable: props.auditeurNom ?? '', demandes: [], ...ex })
  else if (code === 'XIII') Object.assign(dd.XIII, { date: '', source_donnees: '', periode: '', conclusion: '', indicateurs: [], analyse_ecarts: [], ...ex })
  else if (code === 'XIV')  Object.assign(dd.XIV,  { date_observation: '', heure_debut: '', heure_fin: '', auditeur: props.auditeurNom ?? '', localisation: '', interlocuteurs_presents: '', objectif_audit: 'Vérification : ' + (test.libelle || ''), tache_local_observer: '', elements_verifier: '', pieces_attendues: '', points_forts: '', points_faibles: '', conclusion: '', constats: [], ...ex })
  else if (code === 'XV')   Object.assign(dd.XV,   { objectif_audit: '', population_reference: '', objet_test: test.libelle || '', type_sondage: 'attribut', taille_population: null, niveau_confiance: 95, erreur_max: 0.05, ecart_type_exploratoire: null, taux_presence_exploratoire: 0.5, taille_calculee: null, taille_retenue: null, intervalle_confiance: '', conclusion: '', elements: [], ...ex })

  outilActif.value  = { code, title: meta?.label ?? `Outil ${code}`, color: meta?.color ?? '#0f172a', testRef: tr, objNum: obj.num, procIdx, dataKey: dKey }
  constatActif.value = null
  ficheActif.value   = null
}

function fermerOutil() {
  outilActif.value = null
}

async function sauvegarderOutil() {
  const code = outilActif.value?.code
  if (code && dd[code]) {
    outilsDataMap[outilActif.value!.dataKey] = { ...(dd[code] ?? {}), _code: code, _key: outilActif.value!.dataKey }
  }
  outilSaving.value = true
  await submit(true)
  outilSaving.value = false
  showToast('success', `Outil ${code} enregistré.`)
}

// ─────────────────────────────────────────────────────────────────
// MODAL OUTILS
// ─────────────────────────────────────────────────────────────────
function ouvrirChoixOutil(obj: any, test: any, pi: number, oi: number, ti: number) {
  const tr = tRef(test, oi, ti)
  Object.assign(om, {
    visible: true,
    testRef: tr,
    procIdx: pi,
    objNum: obj.num,
    obj,
    test,
    oi,
    ti,
    selected: [...(getOutilsForProc(obj.num, tr, pi))],
  })
}

function omToggle(code: string) {
  const i = om.selected.indexOf(code)
  if (i === -1) om.selected.push(code)
  else om.selected.splice(i, 1)
}

function omConfirmer() {
  if (!om.selected.length) return
  const pk = pKey(om.objNum, om.testRef, om.procIdx ?? 0)
  outilsProcsMap[pk] = [...om.selected]
  om.visible = false
  ouvrirOutil(om.obj, om.test, om.selected[0], om.procIdx ?? 0, om.oi, om.ti)
}

// ─────────────────────────────────────────────────────────────────
// CRUD
// ─────────────────────────────────────────────────────────────────
async function submit(silent = false) {
  processing.value = !silent
  try {
    const url    = form.id ? (dynUrls.update ?? props.urlUpdate) : props.urlStore
    const method = form.id ? 'PUT' : 'POST'
    if (!url) { if (!silent) showToast('error', 'URL indisponible.'); return }

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: JSON.stringify({
        mission_id:    props.missionId    ?? props.missionContext?.mission_id,
        assignment_id: props.assignmentId ?? props.missionContext?.assignment_id,
        resultats:   JSON.stringify(serializeResultats()),
        outils_data: JSON.stringify(serializeOutilsData()),
      }),
    })

    const d = await res.json()
    if (d.success || res.ok) {
      if (!silent) showToast('success', form.id ? 'Fiche mise à jour.' : 'Fiche créée.')
      if (d.form) Object.assign(form, { id: d.form.id, code: d.form.code, validation_status: d.form.validation_status })
      if (d.urlUpdate)    dynUrls.update    = d.urlUpdate
      if (d.urlSoumettre) dynUrls.soumettre = d.urlSoumettre
      if (d.urlValider)   dynUrls.valider   = d.urlValider
    } else {
      if (!silent) showToast('error', d.message ?? 'Erreur.')
    }
  } catch {
    if (!silent) showToast('error', 'Erreur réseau.')
  } finally {
    processing.value = false
  }
}

function annuler() {
  if (props.backUrl) router.visit(props.backUrl)
}

async function soumettre() {
  processing.value = true
  try {
    const d = await (await fetch(dynUrls.soumettre ?? props.urlSoumettre ?? '', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: JSON.stringify({
        mission_id:    props.missionId    ?? props.missionContext?.mission_id,
        assignment_id: props.assignmentId ?? props.missionContext?.assignment_id,
      }),
    })).json()
    if (d.success) { form.validation_status = 'in_review'; showToast('success', 'Soumise pour validation.') }
    else showToast('error', d.error ?? 'Erreur')
  } catch {
    showToast('error', 'Erreur réseau')
  }
  processing.value = false
}

async function valider(action: string, note?: string) {
  processing.value = true
  try {
    const d = await (await fetch(dynUrls.valider ?? props.urlValider ?? '', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf() },
      body: JSON.stringify({
        mission_id:    props.missionId    ?? props.missionContext?.mission_id,
        assignment_id: props.assignmentId ?? props.missionContext?.assignment_id,
        action,
        note,
      }),
    })).json()
    if (d.success) {
      form.validation_status = d.status
      showToast('success', action === 'validate' ? 'Fiche validée ✓' : 'Rejetée.')
    } else {
      showToast('error', d.error ?? 'Erreur')
    }
  } catch {
    showToast('error', 'Erreur réseau')
  }
  processing.value = false
}

function promptReject() {
  const n = prompt('Motif du rejet :', '')
  if (n?.trim()) valider('reject', n.trim())
}

// ─────────────────────────────────────────────────────────────────
// UTILITAIRES
// ─────────────────────────────────────────────────────────────────
function showToast(t: string, m: string, dur = 4000) {
  if (_tt) clearTimeout(_tt)
  toast.value = { show: true, type: t, msg: m }
  _tt = setTimeout(() => { toast.value.show = false }, dur)
}

function csrf(): string {
  return (document.querySelector('meta[name=csrf-token]') as HTMLMetaElement)?.content ?? ''
}

onBeforeUnmount(() => { if (_tt) clearTimeout(_tt) })
</script>

<style scoped>
/* ══ VARIABLES ═════════════════════════════════════════════════ */
:root {
  --navy:   #0f172a;
  --blue:   #1e40af;
  --green:  #065f46;
  --purple: #6d28d9;
  --border: #e2e8f0;
  --bg:     #f1f5f9;
  --sh:     0 1px 3px rgba(15, 23, 42, .07);
}

/* ══ SHELL ═════════════════════════════════════════════════════ */
.ft-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: var(--bg);
  font-family: 'Segoe UI', system-ui, sans-serif;
}

/* ══ TOPBAR ════════════════════════════════════════════════════ */
.ft-topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 1rem;
  background: white;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.ft-topbar__left  { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; }
.ft-topbar__right { display: flex; align-items: center; gap: 0.3rem; }

.ft-code        { background: var(--navy); color: white; padding: 0.2rem 0.6rem; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }
.ft-sdot        { width: 8px; height: 8px; border-radius: 50%; }
.sd--draft      { background: #94a3b8; }
.sd--in_review  { background: #2563eb; }
.sd--validated  { background: #16a34a; }
.ft-vstatus     { font-size: 0.7rem; color: #475569; }
.ft-div         { width: 1px; height: 20px; background: var(--border); }
.ft-icon-muted  { font-size: 0.8rem; color: #94a3b8; }
.ft-mission-lbl { font-size: 0.75rem; color: #475569; }
.ft-prog-badge  { background: #ede9fe; color: var(--purple); padding: 0.1rem 0.5rem; border-radius: 4px; font-size: 0.65rem; font-weight: 600; }
.ft-stat-lbl    { font-size: 0.7rem; color: #64748b; }
.ft-chip-role,
.ft-chip-user   { display: inline-flex; align-items: center; gap: 0.25rem; background: #f1f5f9; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.7rem; }

/* ══ BANNERS ═══════════════════════════════════════════════════ */
.ft-banner          { display: flex; align-items: center; gap: 0.5rem; padding: 0.3rem 1rem; font-size: 0.75rem; flex-shrink: 0; }
.ft-banner--ok      { background: #d1fae5; color: #065f46; border-bottom: 1px solid #a7f3d0; }
.ft-banner--review  { background: #dbeafe; color: #1d4ed8; border-bottom: 1px solid #bfdbfe; }
.ft-banner--rejected{ background: #fee2e2; color: #dc2626; border-bottom: 1px solid #fecaca; }

/* ══ MAIN ══════════════════════════════════════════════════════ */
.ft-main { flex: 1; overflow: auto; padding: 1rem; }

/* ══ LISTE DES TESTS ════════════════════════════════════════════ */
.ft-tests-view { max-width: 1000px; margin: 0 auto; }

.ft-empty        { text-align: center; padding: 3rem; }
.ft-empty__ico   { font-size: 2.5rem; color: #94a3b8; margin-bottom: 1rem; }
.ft-empty__title { font-weight: 600; color: #475569; margin-bottom: 0.25rem; }
.ft-empty__sub   { font-size: 0.75rem; color: #94a3b8; }

.ft-obj-list { display: flex; flex-direction: column; gap: 1rem; }
.ft-obj      { background: white; border-radius: 10px; border: 1px solid var(--border); overflow: hidden; box-shadow: var(--sh); }

.ft-obj__hd    { display: flex; align-items: center; gap: 0.5rem; padding: 0.7rem 1rem; background: linear-gradient(135deg, #eff6ff, #f0fdf4); border-bottom: 1px solid var(--border); flex-wrap: wrap; }
.ft-obj__num   { background: #1e40af; color: white; padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.7rem; font-weight: 600; }
.ft-obj__label { font-weight: 600; color: #1e293b; flex: 1; }

.ft-tag      { display: inline-flex; gap: 0.2rem; padding: 0.1rem 0.5rem; border-radius: 20px; font-size: 0.65rem; }
.ft-tag--blue{ background: #dbeafe; color: #1d4ed8; }

.ft-tests { display: flex; flex-direction: column; }
.ft-test  { padding: 0.7rem 1rem; border-bottom: 1px solid #f1f5f9; }
.ft-test:hover { background: #fafbfc; }
.ft-test--done { border-left: 3px solid #10b981; }

.ft-test__row  { display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; }
.ft-test__info { flex: 1; min-width: 200px; }
.ft-test__lbl  { margin: 0 0 0.25rem; font-size: 0.8rem; font-weight: 500; color: #334155; }
.ft-test__chips{ display: flex; gap: 0.25rem; flex-wrap: wrap; }
.ft-test__acts { display: flex; align-items: center; gap: 0.3rem; }

.ft-ref          { background: #ede9fe; color: var(--purple); padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.65rem; font-weight: 600; white-space: nowrap; }
.ft-chip         { display: inline-flex; align-items: center; gap: 0.2rem; padding: 0.1rem 0.4rem; border-radius: 20px; font-size: 0.6rem; }
.ft-chip--blue   { background: #dbeafe; color: #1d4ed8; }
.ft-chip--green  { background: #d1fae5; color: #065f46; }
.ft-chip--purple { background: #ede9fe; color: #6d28d9; }

.ft-sel-result   { border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.2rem 0.4rem; font-size: 0.7rem; }
.ft-result-pill  { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 20px; font-size: 0.7rem; font-weight: 600; }
.frp--conforme   { background: #d1fae5; color: #065f46; }
.frp--ecart      { background: #fef3c7; color: #92400e; }
.frp--nc         { background: #fee2e2; color: #dc2626; }
.frp--na         { background: #f1f5f9; color: #475569; }

.ft-procs      { background: #f8fafc; border-top: 1px solid #f1f5f9; padding: 0.5rem 1rem; display: flex; flex-direction: column; gap: 0.3rem; }
.ft-proc       { display: flex; align-items: center; gap: 0.5rem; padding: 0.3rem 0.5rem; border-radius: 6px; border: 1px solid transparent; }
.ft-proc--linked{ background: #f0fdf4; border-color: #bbf7d0; }
.ft-proc__n    { font-size: 0.6rem; font-weight: 700; color: #94a3b8; min-width: 18px; }
.ft-proc__txt  { font-size: 0.7rem; color: #334155; flex: 1; }
.ft-proc__acts { display: flex; align-items: center; gap: 0.3rem; flex-wrap: wrap; }

.ft-outil-tag  { display: inline-flex; align-items: center; gap: 0.2rem; padding: 0.1rem 0.5rem; background: var(--ot, #374151); color: white; border-radius: 20px; font-size: 0.6rem; font-weight: 600; cursor: pointer; border: none; }

/* ══ BOUTONS ════════════════════════════════════════════════════ */
.ft-btn          { display: inline-flex; align-items: center; gap: 0.3rem; padding: 0.35rem 0.8rem; border-radius: 6px; font-size: 0.75rem; font-weight: 500; border: 1px solid transparent; cursor: pointer; transition: all 0.2s; }
.ft-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.ft-btn--sm      { padding: 0.25rem 0.6rem; font-size: 0.7rem; }
.ft-btn--ghost   { background: transparent; border-color: #cbd5e1; }
.ft-btn--ghost:hover { background: #f1f5f9; }
.ft-btn--save    { background: var(--navy); color: white; }
.ft-btn--save:hover { background: #1e293b; }
.ft-btn--submit  { background: #2563eb; color: white; }
.ft-btn--validate{ background: #10b981; color: white; }
.ft-btn--reject  { background: #dc2626; color: white; }
.ft-btn--fiche   { background: #eff6ff; border-color: #bfdbfe; color: #1d4ed8; }
.ft-btn--fiche-done{ background: #d1fae5; border-color: #a7f3d0; color: #065f46; }

.ft-ib       { display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; background: transparent; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer; position: relative; }
.ft-ib--sm   { width: 25px; height: 25px; }
.ft-ib--xs   { width: 22px; height: 22px; font-size: 0.7rem; }
.ft-ib--active{ background: #d1fae5; border-color: #a7f3d0; color: #065f46; }
.ft-ib--add  { background: #eff6ff; border-color: #bfdbfe; color: #1d4ed8; }
.ft-ib--edit { background: #fefce8; border-color: #fde68a; color: #b45309; }
.ft-dot      { position: absolute; top: 3px; right: 3px; width: 6px; height: 6px; background: #10b981; border-radius: 50%; }

/* ══ FICHE DE TEST ═════════════════════════════════════════════ */
.ft-fiche-capture { max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden; }

.ft-fiche-header          { display: flex; justify-content: space-between; align-items: center; padding: 0.8rem 1.2rem; background: #1e3a5f; }
.ft-fiche-header__center  { display: flex; align-items: center; gap: 0.8rem; }
.ft-fiche-header__right   { display: flex; align-items: center; gap: 0.5rem; }
.ft-fiche-icon            { width: 36px; height: 36px; background: rgba(255,255,255,0.15); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem; }
.ft-fiche-title           { font-size: 0.9rem; font-weight: 700; color: white; }
.ft-fiche-sub             { font-size: 0.65rem; color: rgba(255,255,255,0.7); margin-top: 2px; }

.ft-btn-back,
.ft-btn-close  { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.25); color: white; padding: 0.3rem 0.8rem; border-radius: 6px; cursor: pointer; font-size: 0.75rem; transition: all 0.2s; display: inline-flex; align-items: center; gap: 0.3rem; }
.ft-btn-back:hover,
.ft-btn-close:hover { background: rgba(255,255,255,0.25); }
.ft-btn-save   { background: #10b981; border: none; color: white; padding: 0.3rem 0.8rem; border-radius: 6px; cursor: pointer; font-size: 0.75rem; transition: all 0.2s; display: inline-flex; align-items: center; gap: 0.3rem; }
.ft-btn-save:hover  { background: #059669; }
.ft-btn-save:disabled{ opacity: 0.5; cursor: not-allowed; }

.ft-fiche-content { padding: 1.5rem; }
.ft-fiche-footer  { display: flex; justify-content: space-between; padding: 0.8rem 1.5rem; background: #f8fafc; border-top: 1px solid var(--border); }

.section-objectif,
.section-auditeur,
.section-source,
.section-tests  { margin-bottom: 1.5rem; }

.section-title    { font-size: 0.85rem; font-weight: 700; color: #1e3a5f; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.5rem; }
.section-subtitle { font-size: 0.85rem; font-weight: 700; color: #1e3a5f; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.5rem; }

.objectif-content        { background: #f8fafc; padding: 0.75rem 1rem; border-left: 3px solid #1e3a5f; font-size: 0.85rem; color: #1e293b; line-height: 1.5; }
.objectif-content p      { margin: 0; }

.auditeur-table           { width: 100%; border-collapse: collapse; background: #f8fafc; border: 1px solid var(--border); }
.auditeur-table th,
.auditeur-table td        { padding: 0.5rem 1rem; border-bottom: 1px solid var(--border); text-align: left; }
.auditeur-table th        { background: #e2e8f0; font-size: 0.7rem; font-weight: 700; color: #475569; width: 140px; }
.auditeur-table td        { font-size: 0.8rem; color: #1e293b; }
.date-input               { border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.2rem 0.5rem; font-size: 0.8rem; }

.source-list  { display: flex; flex-direction: column; gap: 0.5rem; }
.source-item  { display: flex; gap: 0.5rem; font-size: 0.8rem; color: #1e293b; line-height: 1.5; }
.bullet       { color: #1e3a5f; font-weight: 600; }

/* Cartes résultat test */
.test-result-card   { background: #f8fafc; border: 1px solid var(--border); border-radius: 8px; margin-bottom: 1rem; overflow: hidden; }
.test-result-header { display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1rem; background: #f1f5f9; border-bottom: 1px solid var(--border); flex-wrap: wrap; }
.test-result-num    { display: flex; align-items: center; justify-content: center; min-width: 28px; height: 28px; background: #1e40af; color: white; border-radius: 6px; font-size: 0.7rem; font-weight: 700; }
.test-result-libelle{ flex: 1; font-size: 0.75rem; font-weight: 600; color: #1e293b; }
.test-result-actions{ display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; }
.test-result-select { border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.25rem 0.5rem; font-size: 0.7rem; }

.test-result-badge  { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.65rem; font-weight: 600; }
.badge--conforme    { background: #d1fae5; color: #065f46; }
.badge--ecart       { background: #fef3c7; color: #92400e; }
.badge--nc          { background: #fee2e2; color: #dc2626; }
.badge--na          { background: #f1f5f9; color: #475569; }

.test-outil-btn       { display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.25rem 0.6rem; background: #eff6ff; border: 1px solid #bfdbfe; color: #1d4ed8; border-radius: 20px; font-size: 0.65rem; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.test-outil-btn:hover { background: #dbeafe; transform: translateY(-1px); }
.test-outil-btn.has-result { background: #d1fae5; border-color: #a7f3d0; color: #065f46; }

.test-result-body    { padding: 0.75rem 1rem; }
.test-constat,
.test-preuve         { margin-bottom: 0.75rem; }
.test-constat-label,
.test-preuve-label   { font-size: 0.65rem; font-weight: 600; color: #475569; margin-bottom: 0.25rem; display: block; text-transform: uppercase; }
.test-constat-textarea{ width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.5rem; font-size: 0.75rem; font-family: inherit; resize: vertical; }
.test-constat-display { background: #fefce8; padding: 0.5rem; border-radius: 6px; font-size: 0.75rem; color: #1e293b; }
.test-preuve-input   { width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.4rem 0.6rem; font-size: 0.75rem; }
.test-preuve-display { background: #d1fae5; padding: 0.4rem 0.6rem; border-radius: 6px; font-size: 0.75rem; color: #065f46; }

/* ══ CONSTAT ════════════════════════════════════════════════════ */
.ft-constat-view { max-width: 700px; margin: 0 auto; background: white; border-radius: 12px; padding: 1.5rem; box-shadow: var(--sh); }
.ft-constat-back { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
.ft-constat-ref  { font-size: 0.8rem; font-weight: 600; color: var(--navy); }
.ft-constat-body { display: flex; flex-direction: column; gap: 1rem; }

.fc-sect { display: flex; flex-direction: column; gap: 0.4rem; }
.fc-lbl  { font-size: 0.7rem; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.04em; }
.fc-sel  { border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.35rem 0.6rem; font-size: 0.8rem; }
.fc-ta   { border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.5rem; font-size: 0.8rem; font-family: inherit; resize: vertical; width: 100%; }
.fc-inp  { border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.35rem 0.6rem; font-size: 0.8rem; width: 100%; }
.fc-ro   { font-size: 0.8rem; color: #1e293b; background: #f8fafc; padding: 0.5rem; border-radius: 6px; margin: 0; }
.fc-foot { display: flex; justify-content: flex-end; gap: 0.5rem; padding-top: 0.5rem; }

/* ══ OUTIL PAGE ════════════════════════════════════════════════ */
.ft-outil-page { display: flex; flex-direction: column; max-width: 1200px; margin: 0 auto; width: 100%; background: white; border-radius: 12px; overflow: hidden; }

.ft-outil-topbar           { display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding: 0.8rem 1.2rem; background: var(--oc, #0f172a); flex-shrink: 0; }
.ft-outil-topbar__center   { display: flex; align-items: center; gap: 0.8rem; flex: 1; justify-content: center; }
.ft-outil-topbar__right    { display: flex; align-items: center; gap: 0.3rem; flex-shrink: 0; }
.ft-outil-back             { display: inline-flex; align-items: center; gap: 0.35rem; padding: 0.3rem 0.8rem; background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.25); border-radius: 6px; color: white; font-size: 0.75rem; cursor: pointer; }
.ft-outil-back:hover       { background: rgba(255,255,255,0.25); }
.ft-outil-num              { display: inline-flex; align-items: center; justify-content: center; min-width: 38px; height: 32px; background: rgba(255,255,255,0.2); color: white; border-radius: 8px; font-size: 0.9rem; font-weight: 700; }
.ft-outil-title            { font-size: 0.85rem; font-weight: 700; color: white; }
.ft-outil-sub              { font-size: 0.65rem; color: rgba(255,255,255,0.7); margin-top: 2px; }

.ft-outil-body { flex: 1; overflow-y: auto; padding: 1.25rem; background: var(--bg); display: flex; flex-direction: column; gap: 0.75rem; }

/* ══ CARDS OUTILS ══════════════════════════════════════════════ */
.fo-card              { background: white; border-radius: 10px; border: 1px solid var(--border); padding: 0.9rem 1rem; box-shadow: var(--sh); }
.fo-card--xv-calcul   { background: linear-gradient(135deg, #f0fdf4, #fff); border-color: #bbf7d0; }
.fo-card__hd          { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.65rem; flex-wrap: wrap; }
.fo-card__title       { font-size: 0.85rem; font-weight: 800; color: var(--navy); margin: 0; }

.fo-g2      { display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; }
.fo-f       { display: flex; flex-direction: column; gap: 0.25rem; }
.fo-f--full { grid-column: 1 / -1; }
.fo-lbl     { font-size: 0.65rem; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.04em; }

.fo-inp,
.fo-ta       { width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 0.4rem 0.6rem; font-size: 0.75rem; font-family: inherit; box-sizing: border-box; }
.fo-ta       { resize: vertical; }
.fo-inp:focus,
.fo-ta:focus { outline: none; border-color: #93c5fd; box-shadow: 0 0 0 2px rgba(147,197,253,0.2); }
.fo-inp-sm,
.fo-ta-sm    { width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.25rem 0.4rem; font-size: 0.7rem; font-family: inherit; box-sizing: border-box; }
.fo-sel-xs   { border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.15rem 0.3rem; font-size: 0.65rem; }

.fo-table-wrap { overflow-x: auto; border-radius: 6px; border: 1px solid var(--border); }
.fo-t          { width: 100%; border-collapse: collapse; font-size: 0.7rem; }
.fo-t th,
.fo-t td       { padding: 0.3rem 0.5rem; border-bottom: 1px solid var(--border); border-right: 1px solid var(--border); text-align: left; vertical-align: middle; }
.fo-t th       { background: #f8fafc; font-weight: 700; color: #475569; }
.tc            { text-align: center; }
.fo-n          { font-size: 0.6rem; font-weight: 700; color: #94a3b8; text-align: center; }
.fo-ec         { text-align: center; color: #94a3b8; padding: 1rem; font-style: italic; font-size: 0.7rem; }

.fo-add        { display: inline-flex; align-items: center; gap: 0.2rem; padding: 0.2rem 0.6rem; background: #eff6ff; border: 1px solid #bfdbfe; color: #1d4ed8; border-radius: 6px; font-size: 0.65rem; cursor: pointer; }
.fo-add:hover  { background: #dbeafe; }
.fo-del        { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; background: #fee2e2; border: 1px solid #fecaca; color: #dc2626; border-radius: 4px; cursor: pointer; font-size: 0.6rem; }
.fo-del:hover  { background: #fecaca; }

.fo-acteurs      { display: flex; flex-wrap: wrap; gap: 0.3rem; margin-bottom: 0.5rem; }
.fo-acteur       { display: flex; align-items: center; gap: 0.2rem; }
.fo-acteur__badge{ display: inline-flex; align-items: center; justify-content: center; min-width: 24px; height: 20px; border-radius: 4px; color: white; font-size: 0.6rem; font-weight: 700; }
.fo-legend       { font-size: 0.55rem; color: #94a3b8; margin: 0.3rem 0 0; }

.fo-crit    { display: inline-block; padding: 0.1rem 0.4rem; border-radius: 20px; font-size: 0.7rem; font-weight: 700; }
.vi-fort    { background: #fee2e2; color: #dc2626; }
.vi-mod     { background: #fef3c7; color: #d97706; }
.vi-fbl     { background: #d1fae5; color: #065f46; }

.fo-xv-result-row  { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.fo-xv-result-card { display: flex; flex-direction: column; align-items: center; padding: 0.5rem 1rem; background: #f0fdf4; border-radius: 8px; text-align: center; }
.fo-xv-result-n    { font-size: 1.2rem; font-weight: 800; color: var(--navy); }
.fo-xv-result-card small { font-size: 0.6rem; color: #64748b; }


/* ══ FICHE IFACI FIDÈLE AU MODÈLE ══ */
.ft-fiche-body { padding: 0; }

.fi-section-title {
  background: #1e3a5f; color: white;
  text-align: center; padding: 7px 14px;
  font-size: 12px; font-weight: 600; letter-spacing: .02em;
}
.fi-section-title--light { background: #2c5282; }

.fi-objectif {
  padding: 10px 16px; font-size: 13px; color: #1e293b;
  line-height: 1.65; border-bottom: 1px solid #e2e8f0;
}

.fi-auditeur-table { width: 100%; border-collapse: collapse; border-bottom: 1px solid #e2e8f0; }
.fi-auditeur-table th, .fi-auditeur-table td {
  padding: 8px 16px; border: 1px solid #e2e8f0;
  text-align: center; font-size: 12px;
}
.fi-auditeur-table th { background: #1e3a5f; color: white; font-weight: 600; width: 50%; }
.fi-auditeur-table td { color: #1e293b; }
.fi-date-inp { border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 6px; font-size: 12px; }

.fi-source-box {
  padding: 10px 16px; border-bottom: 1px solid #e2e8f0;
  display: flex; flex-direction: column; gap: 4px;
}
.fi-source-item { display: flex; gap: 8px; font-size: 12px; color: #1e293b; line-height: 1.5; }
.fi-dash { color: #1e3a5f; font-weight: 700; flex-shrink: 0; }

/* Tests list */
.fi-tests-list { border-bottom: 1px solid #e2e8f0; }

.fi-test-row {
  display: grid;
  grid-template-columns: 26px 1fr 130px 110px;
  align-items: center; gap: 8px;
  padding: 9px 16px; border-top: 1px solid #e8ecf0;
}
.fi-test-row--done { border-left: 3px solid #10b981; }

.fi-test-num {
  display: flex; align-items: center; justify-content: center;
  width: 22px; height: 22px; background: #1e3a5f;
  color: white; border-radius: 4px; font-size: 10px; font-weight: 700; flex-shrink: 0;
}
.fi-test-lbl { font-size: 12px; color: #1e293b; line-height: 1.5; }

.fi-result-sel {
  border: 1px solid #cbd5e1; border-radius: 5px;
  padding: 4px 6px; font-size: 11px; width: 100%;
}
.fi-result-badge {
  display: inline-block; padding: 2px 7px; border-radius: 20px;
  font-size: 11px; font-weight: 600; white-space: nowrap;
}
.fi-rb--sm { font-size: 10px; padding: 1px 6px; }
.fi-rb--conforme { background: #d1fae5; color: #065f46; }
.fi-rb--ecart    { background: #fef3c7; color: #92400e; }
.fi-rb--nc       { background: #fee2e2; color: #dc2626; }
.fi-rb--na       { background: #f1f5f9; color: #475569; }

.fi-outil-btn {
  display: flex; align-items: center; justify-content: center; gap: 5px; position: relative;
  padding: 5px 8px; background: color-mix(in srgb, var(--oc,#1e40af) 10%, white);
  border: 1px solid color-mix(in srgb, var(--oc,#1e40af) 40%, white);
  color: var(--oc, #1e40af); border-radius: 6px;
  font-size: 11px; font-weight: 600; cursor: pointer; width: 100%; transition: all .15s;
}
.fi-outil-btn:hover { filter: brightness(.95); transform: translateY(-1px); }
.fi-outil-dot {
  position: absolute; top: 3px; right: 3px;
  width: 6px; height: 6px; background: #10b981; border-radius: 50%;
}

/* Constat row */
.fi-constat-row {
  display: grid; grid-template-columns: 1fr 1fr; gap: 10px;
  padding: 6px 16px 10px; background: #fafafa;
  border-top: 1px dashed #e2e8f0;
}
.fi-mini-lbl { font-size: 10px; font-weight: 700; color: #475569; text-transform: uppercase; display: block; margin-bottom: 3px; }
.fi-ta { width: 100%; border: 1px solid #e2e8f0; border-radius: 4px; padding: 5px 7px; font-size: 11px; font-family: inherit; resize: vertical; }
.fi-ta--sm { font-size: 11px; }
.fi-inp { width: 100%; border: 1px solid #e2e8f0; border-radius: 4px; padding: 5px 7px; font-size: 11px; }
.fi-inp--sm { font-size: 11px; }
.fi-ro { font-size: 11px; color: #1e293b; background: #f1f5f9; padding: 5px 7px; border-radius: 4px; }

/* Résultats globaux */
.fi-global-result-box { padding: 10px 16px; min-height: 40px; }
.fi-global-item {
  display: flex; align-items: flex-start; gap: 6px;
  padding: 4px 0; font-size: 12px; color: #1e293b;
}
.fi-global-constat { flex: 1; line-height: 1.5; }
.fi-global-placeholder { font-size: 12px; color: #94a3b8; font-style: italic; }
/* ══ DROPDOWN ══════════════════════════════════════════════════ */
.ft-dd       { min-width: 220px; padding: 0.25rem 0; }
.ft-dd__head { padding: 0.3rem 0.75rem; font-size: 0.65rem; font-weight: 700; color: #94a3b8; text-transform: uppercase; border-bottom: 1px solid #f1f5f9; }
.ft-dd__item { display: flex; align-items: center; gap: 0.4rem; width: 100%; padding: 0.4rem 0.75rem; background: none; border: none; font-size: 0.75rem; cursor: pointer; color: #1e293b; }
.ft-dd__item:hover { background: #f8fafc; }
.ft-dd__dot  { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.ft-dd__code { font-weight: 700; font-size: 0.7rem; min-width: 28px; }
.ft-dd__lbl  { flex: 1; }
.ft-dd__chk  { color: #10b981; }

/* ══ MODAL ═════════════════════════════════════════════════════ */
.om-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
.om-dialog  { background: white; border-radius: 16px; width: 90%; max-width: 600px; max-height: 80vh; display: flex; flex-direction: column; overflow: hidden; }
.om-hd      { display: flex; justify-content: space-between; align-items: center; padding: 1rem; border-bottom: 1px solid #e2e8f0; }
.om-hd__left{ display: flex; align-items: center; gap: 0.8rem; }
.om-hd__icon{ width: 40px; height: 40px; background: linear-gradient(135deg, #1e40af, #6d28d9); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem; }
.om-hd__title{ font-size: 1rem; font-weight: 700; margin: 0; }
.om-hd__sub  { display: flex; gap: 0.3rem; margin-top: 0.2rem; }
.om-ctx      { font-size: 0.65rem; background: #f1f5f9; padding: 0.1rem 0.5rem; border-radius: 20px; }
.om-ctx--proc{ background: #ede9fe; color: #6d28d9; }

.om-selbar   { display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 1rem; background: #f8fafc; border-bottom: 1px solid #e2e8f0; }
.om-tags     { display: flex; gap: 0.3rem; flex-wrap: wrap; }
.om-tag      { display: inline-flex; align-items: center; gap: 0.2rem; background: var(--ot, #374151); color: white; padding: 0.2rem 0.4rem 0.2rem 0.6rem; border-radius: 20px; font-size: 0.7rem; }
.om-tag button{ background: none; border: none; color: white; cursor: pointer; font-size: 0.8rem; padding: 0 0.1rem; }
.om-clear    { background: none; border: 1px solid #fecaca; color: #dc2626; padding: 0.2rem 0.6rem; border-radius: 6px; font-size: 0.7rem; cursor: pointer; }
.om-body     { flex: 1; overflow: auto; padding: 1rem; }
.om-grid     { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 0.5rem; }

.om-card         { display: flex; align-items: center; gap: 0.5rem; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 10px; cursor: pointer; background: white; width: 100%; text-align: left; }
.om-card:hover   { background: #f8fafc; }
.om-card--sel    { border-color: #1e40af; background: #eff6ff; }
.om-card__num    { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; flex-shrink: 0; }
.om-card__body   { flex: 1; }
.om-card__lbl    { font-size: 0.7rem; font-weight: 600; display: block; }
.om-ft           { display: flex; justify-content: flex-end; gap: 0.5rem; padding: 1rem; border-top: 1px solid #e2e8f0; }
.om-confirm      { background: linear-gradient(135deg, #1e40af, #6d28d9); color: white; padding: 0.4rem 1rem; border-radius: 8px; border: none; cursor: pointer; font-size: 0.8rem; font-weight: 600; }
.om-confirm:disabled{ opacity: 0.5; cursor: not-allowed; }

/* ══ TOAST ═════════════════════════════════════════════════════ */
.ft-toast         { position: fixed; bottom: 1rem; right: 1rem; display: flex; align-items: center; gap: 0.5rem; padding: 0.5rem 1rem; border-radius: 8px; font-size: 0.75rem; z-index: 2000; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.ft-toast--success{ background: #065f46; color: white; }
.ft-toast--error  { background: #dc2626; color: white; }
.ft-toast__x      { background: none; border: none; color: white; opacity: 0.7; cursor: pointer; margin-left: 0.5rem; }

/* ══ SPINNER ═══════════════════════════════════════════════════ */
.ft-spin    { display: inline-block; width: 0.8rem; height: 0.8rem; border: 2px solid rgba(255,255,255,0.3); border-top-color: white; border-radius: 50%; animation: spin 0.7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ══ TRANSITIONS ════════════════════════════════════════════════ */
.om-fade-enter-active,
.om-fade-leave-active   { transition: opacity 0.2s; }
.om-fade-enter-from,
.om-fade-leave-to       { opacity: 0; }

.toast-pop-enter-active,
.toast-pop-leave-active { transition: all 0.2s; }
.toast-pop-enter-from,
.toast-pop-leave-to     { opacity: 0; transform: translateY(10px); }

/* ══ RESPONSIVE ═════════════════════════════════════════════════ */
@media (max-width: 880px) {
  .ft-prog-badge,
  .ft-stat-lbl { display: none; }
  .om-grid     { grid-template-columns: 1fr 1fr; }
  .fo-g2       { grid-template-columns: 1fr; }
  .fo-f--full  { grid-column: 1; }
}
</style>