<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('activites_flux', function (Blueprint $t) {
      $t->id();
      $t->foreignId('activite_id')->constrained('activites')->cascadeOnDelete();
      $t->enum('type', ['ENTREE','SORTIE']);
      $t->string('libelle');
      $t->string('format')->nullable();          // doc, excel, api, mail...
      $t->string('source')->nullable();
      $t->string('destination')->nullable();
      $t->json('meta')->nullable();
      $t->timestamps();
      $t->index(['activite_id','type']);
    });
  }
  public function down(): void { Schema::dropIfExists('activites_flux'); }
};

