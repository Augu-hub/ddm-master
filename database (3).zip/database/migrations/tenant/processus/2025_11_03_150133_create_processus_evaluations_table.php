<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('processus_evaluations', function (Blueprint $t) {
      $t->id();
      $t->foreignId('processus_id')->constrained('processus')->cascadeOnDelete();
      $t->unsignedTinyInteger('maturite');       // 1..5
      $t->unsignedTinyInteger('motricite');
      $t->unsignedTinyInteger('transversalite');
      $t->unsignedTinyInteger('strategique');
      $t->decimal('criticite',5,2);              // moyenne pondérée si besoin
      $t->timestamp('evalue_le')->useCurrent();
      $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
      $t->timestamps();
      $t->index(['processus_id','evalue_le']);
    });
  }
  public function down(): void { Schema::dropIfExists('processus_evaluations'); }
};
