<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('activites_idea', function (Blueprint $t) {
      $t->id();
      $t->foreignId('activite_id')->constrained('activites')->cascadeOnDelete();
      $t->unsignedBigInteger('acteur_id');
      $t->enum('role', ['I','D','E','A']);
      $t->enum('type', ['Pilotage','Operationnelle','Support']);
      $t->string('couleur',24)->nullable();
      $t->timestamps();
      $t->unique(['activite_id','acteur_id','type']);
      $t->index(['activite_id','role','type']);
    });
  }
  public function down(): void { Schema::dropIfExists('activites_idea'); }
};
