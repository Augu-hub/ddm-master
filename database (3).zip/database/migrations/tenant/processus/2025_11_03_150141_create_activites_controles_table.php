<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('activites_controles', function (Blueprint $t) {
      $t->id();
      $t->foreignId('activite_id')->constrained('activites')->cascadeOnDelete();
      $t->enum('nature', ['PREVENTIF','DETECTIF','CORRECTIF']);
      $t->string('libelle');
      $t->string('frequence')->nullable();       // quotidien, hebdo, mensuel...
      $t->string('preuve')->nullable();          // piste d’audit
      $t->unsignedTinyInteger('niveau')->nullable(); // 1..3
      $t->unsignedBigInteger('acteur_id')->nullable(); // ref. fonctions/roles si tu as
      $t->decimal('efficacite',5,2)->nullable(); // score 0..5
      $t->timestamps();
      $t->index(['activite_id','nature']);
    });
  }
  public function down(): void { Schema::dropIfExists('activites_controles'); }
};
