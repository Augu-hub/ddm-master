<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('activites_etapes', function (Blueprint $t) {
      $t->id();
      $t->foreignId('activite_id')->constrained('activites')->cascadeOnDelete();
      $t->string('code')->nullable();            // ex: A1.E1
      $t->string('libelle');
      $t->text('description')->nullable();
      $t->unsignedInteger('ordre')->default(0);
      $t->unsignedInteger('delai_estime_min')->nullable();
      $t->timestamps();
      $t->unique(['activite_id','libelle']);
      $t->index(['activite_id','ordre']);
    });
  }
  public function down(): void { Schema::dropIfExists('activites_etapes'); }
};
