<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('processus_diagrammes', function (Blueprint $t) {
      $t->id();
      $t->foreignId('processus_id')->constrained('processus')->cascadeOnDelete();
      $t->longText('bpmn_xml')->nullable();
      $t->json('elements')->nullable();     // cache JSON
      $t->unsignedInteger('version')->default(1);
      $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
      $t->timestamps();
      $t->index(['processus_id','version']);
    });
  }
  public function down(): void { Schema::dropIfExists('processus_diagrammes'); }
};
