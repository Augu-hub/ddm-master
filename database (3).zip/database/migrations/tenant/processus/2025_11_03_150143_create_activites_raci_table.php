<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('activites_raci', function (Blueprint $t) {
      $t->id();
      $t->foreignId('activite_id')->constrained('activites')->cascadeOnDelete();
      $t->unsignedBigInteger('acteur_id');       // table fonctions/roles côté tenant
      $t->enum('role', ['R','A','C','I']);
      $t->string('couleur',24)->nullable();
      $t->timestamps();
      $t->unique(['activite_id','acteur_id']);
      $t->index(['activite_id','role']);
    });
  }
  public function down(): void { Schema::dropIfExists('activites_raci'); }
};
