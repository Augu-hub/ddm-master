<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('processus_kpis', function (Blueprint $t) {
      $t->id();
      $t->foreignId('processus_id')->constrained('processus')->cascadeOnDelete();
      $t->string('nom');
      $t->string('unite')->nullable();           // %, j, XOF...
      $t->decimal('cible',14,4)->nullable();
      $t->decimal('valeur_actuelle',14,4)->nullable();
      $t->enum('tendance', ['UP','FLAT','DOWN'])->nullable();
      $t->json('meta')->nullable();
      $t->timestamps();
      $t->unique(['processus_id','nom']);
    });
  }
  public function down(): void { Schema::dropIfExists('processus_kpis'); }
};

