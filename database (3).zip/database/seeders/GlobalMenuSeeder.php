<?php
// database/seeders/GlobalMenuSeeder.php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use App\Models\Master\Module;
use App\Models\User;

class GlobalMenuSeeder extends Seeder
{
    /** cache module_code => ['id'=>..., 'service_id'=>...] */
    private array $moduleCache = [];

    /** cache key => id (menus) */
    private array $menuIdByKey = [];

    public function run(): void
    {
        DB::transaction(function () {
            // 1) Nettoyage optionnel des pivots uniquement
            if (Schema::hasTable('menu_user')) DB::table('menu_user')->delete();
            if (Schema::hasTable('menu_permission')) DB::table('menu_permission')->delete();

            // 2) Arborescence (upsert)
            $this->insertTree(null, [
                // ===== TITRE PRINCIPAL =====
                [
                    'key'   => 'seed-root',
                    'label' => 'DIADDEM',
                    'icon'  => 'ti ti-database-cog',
                    'type'  => 'title',
                ],

                // ===== TABLEAU DE BORD (global) =====
                [
                    'key'   => 'dashboard',
                    'label' => 'Tableau de bord',
                    'icon'  => 'ti ti-layout-dashboard',
                    'type'  => 'item',
                    'url'   => '/',
                ],

                // ===== PARAMÉTRAGE (PARAM) =====
                [
                    'key'   => 'param',
                    'label' => 'Paramétrage',
                    'icon'  => 'ti ti-adjustments',
                    'type'  => 'item',
                    'module_code' => 'param.projects',
                    'children' => [
                        // ---- Noyau standardisé param.core.* ----
                        [
                            'key'   => 'param-core',
                            'label' => 'Param — Noyau',
                            'icon'  => 'ti ti-settings-cog',
                            'type'  => 'item',
                            'module_code' => 'param.projects',
                            'children' => [
                                ['key'=>'param-home','label'=>'Accueil','icon'=>'ti ti-home','type'=>'item','route_name'=>'param.core.home','module_code'=>'param.projects'],
                                ['key'=>'param-registry','label'=>'Registre','icon'=>'ti ti-folders','type'=>'item','route_name'=>'param.core.registry.index','module_code'=>'param.projects'],
                                ['key'=>'param-models','label'=>'Modèles','icon'=>'ti ti-template','type'=>'item','route_name'=>'param.core.models.index','module_code'=>'param.projects'],
                                ['key'=>'param-reports','label'=>'Rapports','icon'=>'ti ti-report','type'=>'item','route_name'=>'param.core.reports.index','module_code'=>'param.projects'],
                                ['key'=>'param-settings','label'=>'Paramètres','icon'=>'ti ti-settings','type'=>'item','route_name'=>'param.core.settings.index','module_code'=>'param.projects'],
                            ],
                        ],

                        // ---- Tes écrans existants ----
                        [
                            'key'   => 'project',
                            'label' => 'Projets',
                            'icon'  => 'ti ti-folders',
                            'type'  => 'item',
                            'route_name' => 'param.projects.projects.index',
                            'module_code' => 'param.projects',
                        ],
                        [
                            'key'   => 'entity',
                            'label' => 'Entités',
                            'icon'  => 'ti ti-building-community',
                            'type'  => 'item',
                            'route_name' => 'param.entities.index',
                            'module_code' => 'param.projects',
                        ],
                        [
                            'key'   => 'process',
                            'label' => 'Macro-Processus-Activité',
                            'icon'  => 'ti ti-sitemap',
                            'type'  => 'item',
                            'route_name' => 'param.mpa.index',
                            'module_code' => 'param.projects',
                        ],
                        [
                            'key'   => 'function',
                            'label' => 'Fonctions',
                            'icon'  => 'ti ti-components',
                            'type'  => 'item',
                            'route_name' => 'param.functions.index',
                            'module_code' => 'param.projects',
                        ],
                        [
                            'key'   => 'charts',
                            'label' => 'Organigrammes Projet',
                            'icon'  => 'ti ti-chart-infographic',
                            'type'  => 'item',
                            'module_code' => 'param.projects',
                            'children' => [
                                [
                                    'key'   => 'entity_chart',
                                    'label' => 'Organigramme Entités',
                                    'icon'  => 'ti ti-building-skyscraper',
                                    'type'  => 'item',
                                    'route_name' => 'param.charts.entity',
                                    'module_code' => 'param.projects',
                                ],
                                [
                                    'key'   => 'function_chart',
                                    'label' => 'Organigramme Fonctions',
                                    'icon'  => 'ti ti-hierarchy',
                                    'type'  => 'item',
                                    'route_name' => 'param.charts.function',
                                    'module_code' => 'param.projects',
                                ],
                            ]
                        ],
                        [
                            'key'   => 'distribution',
                            'label' => 'Répartition MPA / Fonction',
                            'icon'  => 'ti ti-arrows-shuffle',
                            'type'  => 'item',
                            'route_name' => 'param.distribution.index',
                            'module_code' => 'param.projects',
                        ],
                        [
                            'key'   => 'charts_entity',
                            'label' => 'Organigrammes Entité',
                            'icon'  => 'ti ti-chart-infographic',
                            'type'  => 'item',
                            'route_name' => 'param.charts.entity-functions',
                            'module_code' => 'param.projects',
                        ],
                    ],
                ],

                // ===== PROCESSUS =====
                [
                    'key'   => 'process-module',
                    'label' => 'Processus',
                    'icon'  => 'ti ti-flow-branch',
                    'type'  => 'item',
                    'module_code' => 'process.core',
                    'children' => [
                        ['key'=>'process-home','label'=>'Accueil','icon'=>'ti ti-home','type'=>'item','route_name'=>'process.core.home','module_code'=>'process.core'],
                        ['key'=>'process-registry','label'=>'Registre des processus','icon'=>'ti ti-list-details','type'=>'item','route_name'=>'process.core.registry.index','module_code'=>'process.core'],
                        ['key'=>'process-models','label'=>'Modèles & référentiels','icon'=>'ti ti-template','type'=>'item','route_name'=>'process.core.models.index','module_code'=>'process.core'],
                        ['key'=>'process-reports','label'=>'Rapports & KPIs','icon'=>'ti ti-report-analytics','type'=>'item','route_name'=>'process.core.reports.index','module_code'=>'process.core'],
                        ['key'=>'process-settings','label'=>'Paramètres','icon'=>'ti ti-settings','type'=>'item','route_name'=>'process.core.settings.index','module_code'=>'process.core'],
                    ],
                ],

                // ===== RISQUES =====
                [
                    'key'   => 'risk-module',
                    'label' => 'Risques',
                    'icon'  => 'ti ti-alert-triangle',
                    'type'  => 'item',
                    'module_code' => 'risk.core',
                    'children' => [
                        ['key'=>'risk-home','label'=>'Accueil','icon'=>'ti ti-home','type'=>'item','route_name'=>'risk.core.home','module_code'=>'risk.core'],
                        ['key'=>'risk-registry','label'=>'Registre des risques','icon'=>'ti ti-clipboard-list','type'=>'item','route_name'=>'risk.core.registry.index','module_code'=>'risk.core'],
                        ['key'=>'risk-models','label'=>'Modèles (cartes, matrices)','icon'=>'ti ti-layout-grid','type'=>'item','route_name'=>'risk.core.models.index','module_code'=>'risk.core'],
                        ['key'=>'risk-reports','label'=>'Rapports & tableaux de bord','icon'=>'ti ti-report-analytics','type'=>'item','route_name'=>'risk.core.reports.index','module_code'=>'risk.core'],
                        ['key'=>'risk-settings','label'=>'Paramètres & appétence','icon'=>'ti ti-adjustments','type'=>'item','route_name'=>'risk.core.settings.index','module_code'=>'risk.core'],
                    ],
                ],

                // ===== AUDIT =====
                [
                    'key'   => 'audit-module',
                    'label' => 'Audit Interne',
                    'icon'  => 'ti ti-checklist',
                    'type'  => 'item',
                    'module_code' => 'audit.core',
                    'children' => [
                        ['key'=>'audit-home','label'=>'Accueil','icon'=>'ti ti-home','type'=>'item','route_name'=>'audit.core.home','module_code'=>'audit.core'],
                        ['key'=>'audit-registry','label'=>'Registre (plans, missions)','icon'=>'ti ti-notebook','type'=>'item','route_name'=>'audit.core.registry.index','module_code'=>'audit.core'],
                        ['key'=>'audit-models','label'=>'Programmes & modèles','icon'=>'ti ti-template','type'=>'item','route_name'=>'audit.core.models.index','module_code'=>'audit.core'],
                        ['key'=>'audit-reports','label'=>'Rapports & suivi reco','icon'=>'ti ti-report-search','type'=>'item','route_name'=>'audit.core.reports.index','module_code'=>'audit.core'],
                        ['key'=>'audit-settings','label'=>'Paramètres','icon'=>'ti ti-settings','type'=>'item','route_name'=>'audit.core.settings.index','module_code'=>'audit.core'],
                    ],
                ],

                // ===== ADMINISTRATION =====
                [
                    'key'   => 'builtin',
                    'label' => 'Administration',
                    'icon'  => 'ti ti-settings',
                    'type'  => 'item',
                    'children' => [
                        ['key'=>'services','label'=>'Services','icon'=>'ti ti-packages','type'=>'item','url'=>'/admin/services'],
                        ['key'=>'modules','label'=>'Modules','icon'=>'ti ti-apps','type'=>'item','url'=>'/admin/modules'],

                        ['key'=>'assign-services','label'=>'Affecter Services → Utilisateur','icon'=>'ti ti-user-plus','type'=>'item','url'=>'/admin/assign/users-services'],
                        ['key'=>'assign-modules','label'=>'Affecter Modules → Utilisateur','icon'=>'ti ti-user-cog','type'=>'item','url'=>'/admin/assign/users-modules'],

                        ['key'=>'permissions','label'=>'Permissions','icon'=>'ti ti-key','type'=>'item','url'=>'/admin/permissions'],
                        ['key'=>'roles','label'=>'Rôles','icon'=>'ti ti-user-shield','type'=>'item','url'=>'/admin/roles'],
                        ['key'=>'users','label'=>'Utilisateurs','icon'=>'ti ti-users','type'=>'item','url'=>'/admin/users'],
                        ['key'=>'menus','label'=>'Menus','icon'=>'ti ti-menu-2','type'=>'item','url'=>'/admin/menus'],
                        ['key'=>'i18n','label'=>'Traductions','icon'=>'ti ti-language','type'=>'item','url'=>'/admin/translations'],
                        ['key'=>'tenants','label'=>'Clients','icon'=>'ti ti-building-store','type'=>'item','url'=>'/admin/tenants'],
                    ]
                ],
            ]);

            $this->command->info('✅ GlobalMenuSeeder: arborescence upsertée avec succès.');
        });

        // 3) Lier le SUPER ADMIN à tous les modules (pivot module_user)
        $this->attachSuperAdminToAllModules();
    }

    /** Upsert récursif de l’arbre des menus */
    private function insertTree(?int $parentId, array $items): void
    {
        foreach ($items as $sort => $item) {
            $children = $item['children'] ?? [];
            unset($item['children']);

            // Résoudre module_id / service_id à partir de module_code (si fourni)
            $moduleId   = null;
            $serviceId  = null;
            if (!empty($item['module_code'])) {
                [$moduleId, $serviceId] = $this->resolveModule($item['module_code']);
                unset($item['module_code']);
            }

            // Données du menu (alignées à ta migration)
            $data = [
                'label'        => $item['label'],
                'type'         => $item['type'] ?? 'item',
                'icon'         => $item['icon'] ?? null,
                'url'          => $item['url'] ?? null,
                'route_name'   => $item['route_name'] ?? null,
                'target'       => $item['target'] ?? null,
                'parent_id'    => $parentId,
                'sort'         => $sort,
                'service_id'   => $serviceId,     // hérite du service du module s’il existe
                'module_id'    => $moduleId,
                'visible'      => true,
                'badge_json'   => null,
                'tooltip_json' => null,
                'meta_json'    => null,
                'updated_at'   => now(),
            ];

            // Upsert par key (unique)
            DB::table('menus')->updateOrInsert(
                ['key' => $item['key']],
                array_merge($data, ['created_at' => now()])
            );

            // Récupération de l'id du menu pour la suite (parent des enfants)
            $menuId = DB::table('menus')->where('key', $item['key'])->value('id');
            $this->menuIdByKey[$item['key']] = (int) $menuId;

            // Recurse
            if (!empty($children)) {
                $this->insertTree($menuId, $children);
            }
        }
    }

    /** Retourne [module_id, service_id] à partir d’un code de module */
    private function resolveModule(string $moduleCode): array
    {
        if (isset($this->moduleCache[$moduleCode])) {
            return $this->moduleCache[$moduleCode];
        }

        if (! Schema::hasTable('modules')) {
            $this->command->warn("⚠️ Table modules absente — module_code={$moduleCode} ignoré.");
            return $this->moduleCache[$moduleCode] = [null, null];
        }

        $row = Module::query()->where('code', $moduleCode)->select('id','service_id')->first();

        if (! $row) {
            $this->command->warn("ℹ️ Module introuvable pour module_code={$moduleCode} — le menu sera créé sans liaison module.");
            return $this->moduleCache[$moduleCode] = [null, null];
        }

        return $this->moduleCache[$moduleCode] = [(int)$row->id, (int)$row->service_id];
    }

    /**
     * Lie l'utilisateur super admin à tous les modules (pivot module_user).
     */
    private function attachSuperAdminToAllModules(): void
    {
        // Configurable via .env
        $email = env('GLOBAL_SUPERADMIN_EMAIL', 'admin@diaddem.local');

        // Vérifications
        if (! Schema::hasTable('users') || ! Schema::hasTable('modules') || ! Schema::hasTable('module_user')) {
            $this->command->warn('⚠️ Tables "users/modules/module_user" manquantes — liaison super admin → modules ignorée.');
            return;
        }

        $superId = User::where('email', $email)->value('id');
        if (! $superId) {
            $this->command->warn("⚠️ Super admin introuvable (email: {$email}). Exécute le SuperAdminSeeder avant/après.");
            return;
        }

        $moduleIds = Module::pluck('id')->all();
        if (empty($moduleIds)) {
            $this->command->warn('ℹ️ Aucun module trouvé — exécute le seed des modules d’abord.');
            return;
        }

        $now  = now();
        $rows = array_map(fn ($mid) => [
            'module_id'  => $mid,
            'user_id'    => $superId,
            'created_at' => $now,
            'updated_at' => $now,
        ], $moduleIds);

        DB::table('module_user')->upsert($rows, ['module_id','user_id']);

        $this->command->info("✅ Super admin ({$email}) lié à tous les modules (".count($moduleIds).").");
    }
}
