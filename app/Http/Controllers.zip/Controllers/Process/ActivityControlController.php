<?php

namespace App\Http\Controllers\Tenant\Process;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ActivityControlController extends Controller
{
    //
}
