<?php

namespace App\Http\Controllers\Auditor;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Models\Param\Auditor;
use Inertia\Inertia;

class FicheTestController extends BasePhaseFormController
{
    protected string $table       = 'mission_phase_fiche_test';
    protected string $formCode    = 'fiche-test';
    protected string $codePrefix  = 'FT';
    protected string $inertiaPage = 'dashboards/Auditor/Forms/FicheTest';
    protected string $routeEdit   = 'auditor.ac.fiche-test.edit';
    private  string $conn         = 'tenant';

    private const OUTIL_TABLES = [
        'I'    => 'outil_entretiens',
        'II'   => 'outil_analyse_taches',
        'III'  => 'outil_diagramme_flux',
        'IV'   => 'outil_approche_processus',
        'V'    => 'outil_test_cheminement',
        'VI'   => 'outil_hierarchisation_risques',
        'VII'  => 'outil_referentiel_audit',
        'VIII' => 'outil_cause_effet',
        'IX'   => 'outil_qci',
        'X'    => 'outil_brainstorming',
        'XI'   => 'outil_piste_audit',
        'XII'  => 'outil_circularisation',
        'XIII' => 'outil_audit_analytique',
        'XIV'  => 'outil_observation',
        'XV'   => 'outil_echantillonnage',
    ];

    private const OUTIL_CHILDREN = [
        'I'    => [['table' => 'outil_entretien_questions',            'fk' => 'entretien_id']],
        'II'   => [['table' => 'outil_analyse_taches_lignes',          'fk' => 'grille_id']],
        'IV'   => [['table' => 'outil_approche_processus_lignes',      'fk' => 'fiche_id']],
        'V'    => [['table' => 'outil_test_cheminement_etapes',        'fk' => 'test_id']],
        'VI'   => [['table' => 'outil_hierarchisation_risques_lignes', 'fk' => 'fiche_id']],
        'VIII' => [['table' => 'outil_cause_effet_causes',             'fk' => 'diagramme_id']],
        'IX'   => [
            ['table' => 'outil_qci_sections',  'fk' => 'qci_id'],
            ['table' => 'outil_qci_questions', 'fk' => 'qci_id'],
        ],
        'X'    => [['table' => 'outil_brainstorming_idees',            'fk' => 'session_id']],
        'XI'   => [
            ['table' => 'outil_piste_audit_etapes',    'fk' => 'piste_id'],
            ['table' => 'outil_piste_audit_resultats', 'fk' => 'piste_id'],
        ],
        'XII'  => [['table' => 'outil_circularisation_demandes',       'fk' => 'fiche_id']],
        'XIII' => [
            ['table' => 'outil_audit_analytique_lignes', 'fk' => 'procedure_id'],
            ['table' => 'outil_audit_analytique_ecarts', 'fk' => 'procedure_id'],
        ],
        'XIV'  => [['table' => 'outil_observation_constats',           'fk' => 'observation_id']],
        'XV'   => [['table' => 'outil_echantillonnage_elements',       'fk' => 'fiche_id']],
    ];

    public const OUTILS_IFACI = [
        'I'    => ['code' => 'I',    'label' => "Grille d'Entretien",              'icon' => 'ti-message-question', 'color' => '#1e40af'],
        'II'   => ['code' => 'II',   'label' => "Grille d'Analyse des Tâches",    'icon' => 'ti-layout-list',      'color' => '#065f46'],
        'III'  => ['code' => 'III',  'label' => 'Diagramme de Flux',              'icon' => 'ti-git-branch',       'color' => '#6d28d9'],
        'IV'   => ['code' => 'IV',   'label' => 'Approche Processus',             'icon' => 'ti-sitemap',          'color' => '#b45309'],
        'V'    => ['code' => 'V',    'label' => 'Test de Cheminement',            'icon' => 'ti-route',            'color' => '#be185d'],
        'VI'   => ['code' => 'VI',   'label' => 'Hiérarchisation des Risques',    'icon' => 'ti-alert-triangle',   'color' => '#dc2626'],
        'VII'  => ['code' => 'VII',  'label' => "Référentiel d'Audit",            'icon' => 'ti-table',            'color' => '#0891b2'],
        'VIII' => ['code' => 'VIII', 'label' => 'Cause / Effet (Ishikawa 5M)',    'icon' => 'ti-git-merge',        'color' => '#7c3aed'],
        'IX'   => ['code' => 'IX',   'label' => 'Questionnaire de Contrôle Int.', 'icon' => 'ti-clipboard-check',  'color' => '#0f766e'],
        'X'    => ['code' => 'X',    'label' => 'Brainstorming',                  'icon' => 'ti-bulb',             'color' => '#d97706'],
        'XI'   => ['code' => 'XI',   'label' => "Piste d'Audit",                  'icon' => 'ti-route-scan',       'color' => '#4f46e5'],
        'XII'  => ['code' => 'XII',  'label' => 'Circularisation',                'icon' => 'ti-mail-forward',     'color' => '#0369a1'],
        'XIII' => ['code' => 'XIII', 'label' => 'Audit Analytique',               'icon' => 'ti-chart-line',       'color' => '#15803d'],
        'XIV'  => ['code' => 'XIV',  'label' => 'Observation Directe',            'icon' => 'ti-eye',              'color' => '#9333ea'],
        'XV'   => ['code' => 'XV',   'label' => 'Échantillonnage Statistique',    'icon' => 'ti-calculator',       'color' => '#0c4a6e'],
    ];

    private const PROGRAMMES = [
        ['table' => 'mission_phase_prog_ci',           'code' => 'PTCI',    'label' => 'Contrôle Interne'],
        ['table' => 'mission_phase_prog_conformite',   'code' => 'PTCONF',  'label' => 'Conformité'],
        ['table' => 'mission_phase_prog_marches',      'code' => 'PTMAR',   'label' => 'Marchés'],
        ['table' => 'mission_phase_prog_transactions', 'code' => 'PTTRANS', 'label' => 'Transactions'],
    ];

    protected array $validationRules = [
        'mission_id'    => 'required|integer',
        'assignment_id' => 'required|integer',
    ];

    protected function getRole(int $missionId, int $auditorId): string
    {
        $row = DB::connection($this->conn)
            ->table('mission_phase_assignment_auditeurs as mpaa')
            ->join('mission_phase_assignments as mpa', 'mpa.id', '=', 'mpaa.assignment_id')
            ->where('mpa.mission_programmation_id', $missionId)
            ->where('mpaa.auditeur_id', $auditorId)
            ->select('mpaa.role_code')
            ->orderByRaw("FIELD(mpaa.role_code,'DM','CM','AS','AJ')")
            ->first();
        return $row?->role_code ?? 'AJ';
    }

    protected function formData(Request $request, Auditor $auditor): array { return []; }

    /**
     * Génère un résumé des résultats de l'outil
     * Ce sont CES RÉSULTATS qui seront affichés dans la fiche de test
     */
    private function resumeOutil(string $code, array $record, array $children): array
    {
        $resume = ['titre' => '', 'resultats' => [], 'conclusion' => '', 'score' => null];

        switch ($code) {
            case 'I': // Entretien
                $resume['titre'] = $record['interlocuteur'] ?? $record['intitule'] ?? 'Entretien';
                $resume['resultats'] = collect($children['outil_entretien_questions'] ?? [])
                    ->map(fn($q) => [
                        'question' => is_object($q) ? $q->libelle : ($q['libelle'] ?? ''),
                        'reponse'  => is_object($q) ? $q->reponse : ($q['reponse'] ?? ''),
                        'type'     => is_object($q) ? $q->type : ($q['type'] ?? 'Ouverte'),
                    ])->toArray();
                $resume['conclusion'] = $record['synthese'] ?? '';
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            case 'V': // Test de cheminement
                $resume['titre'] = $record['intitule'] ?? $record['processus_audite'] ?? 'Test de cheminement';
                $etapes = $children['outil_test_cheminement_etapes'] ?? [];
                $conformes = collect($etapes)->filter(fn($e) => strtolower(is_object($e) ? ($e->conforme_procedure ?? '') : ($e['conforme_procedure'] ?? '')) === 'oui')->count();
                $resume['resultats'] = [
                    ['label' => 'Étapes totales', 'valeur' => count($etapes)],
                    ['label' => 'Étapes conformes', 'valeur' => $conformes],
                    ['label' => 'Taux de conformité', 'valeur' => count($etapes) > 0 ? round(($conformes / count($etapes)) * 100, 1) . '%' : 'N/A'],
                ];
                $resume['conclusion'] = $record['conclusion'] ?? '';
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            case 'VI': // Hiérarchisation des risques
                $resume['titre'] = $record['perimetre'] ?? $record['intitule'] ?? 'Analyse des risques';
                $risques = $children['outil_hierarchisation_risques_lignes'] ?? [];
                $critiques = collect($risques)->filter(fn($r) => ((is_object($r) ? $r->probabilite : ($r['probabilite'] ?? 0)) * (is_object($r) ? $r->impact : ($r['impact'] ?? 0))) >= 7)->count();
                $resume['resultats'] = [
                    ['label' => 'Risques identifiés', 'valeur' => count($risques)],
                    ['label' => 'Risques critiques (P×I≥7)', 'valeur' => $critiques],
                    ['label' => 'Risques majeurs', 'valeur' => collect($risques)->filter(fn($r) => ((is_object($r) ? $r->probabilite : ($r['probabilite'] ?? 0)) * (is_object($r) ? $r->impact : ($r['impact'] ?? 0))) >= 4 && ((is_object($r) ? $r->probabilite : ($r['probabilite'] ?? 0)) * (is_object($r) ? $r->impact : ($r['impact'] ?? 0))) < 7)->count()],
                ];
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            case 'VIII': // Cause/Effet
                $resume['titre'] = $record['effet_central'] ?? $record['intitule'] ?? 'Analyse Cause/Effet';
                $causes = $children['outil_cause_effet_causes'] ?? [];
                $prioritaires = collect($causes)->filter(fn($c) => (int)(is_object($c) ? ($c->priorite ?? 0) : ($c['priorite'] ?? 0)) === 1)->count();
                $resume['resultats'] = [
                    ['label' => 'Causes identifiées', 'valeur' => count($causes)],
                    ['label' => 'Causes prioritaires', 'valeur' => $prioritaires],
                ];
                $resume['conclusion'] = $record['synthese'] ?? '';
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            case 'IX': // QCI
                $resume['titre'] = $record['processus'] ?? $record['intitule'] ?? 'Questionnaire CI';
                $questions = $children['outil_qci_questions'] ?? [];
                $oui = collect($questions)->filter(fn($q) => in_array(strtolower(is_object($q) ? ($q->reponse ?? '') : ($q['reponse'] ?? '')), ['oui', 'o', 'yes']))->count();
                $resume['resultats'] = [
                    ['label' => 'Questions', 'valeur' => count($questions)],
                    ['label' => 'Conformes (Oui)', 'valeur' => $oui],
                    ['label' => 'Taux de conformité', 'valeur' => count($questions) > 0 ? round(($oui / count($questions)) * 100, 1) . '%' : 'N/A'],
                ];
                $resume['conclusion'] = $record['conclusion'] ?? '';
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            case 'XIV': // Observation directe
                $resume['titre'] = $record['tache_local_observer'] ?? $record['objectif_audit'] ?? 'Observation';
                $constats = $children['outil_observation_constats'] ?? [];
                $conformes = collect($constats)->filter(fn($c) => strtolower(is_object($c) ? ($c->conforme_referentiel ?? '') : ($c['conforme_referentiel'] ?? '')) === 'oui')->count();
                $resume['resultats'] = [
                    ['label' => 'Points observés', 'valeur' => count($constats)],
                    ['label' => 'Points conformes', 'valeur' => $conformes],
                    ['label' => 'Points non conformes', 'valeur' => count($constats) - $conformes],
                ];
                $resume['conclusion'] = $record['conclusion'] ?? '';
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            case 'XV': // Échantillonnage
                $resume['titre'] = $record['population_reference'] ?? 'Échantillonnage';
                $elements = $children['outil_echantillonnage_elements'] ?? [];
                $anomalies = collect($elements)->filter(fn($e) => strtolower(is_object($e) ? ($e->anomalie_detectee ?? '') : ($e['anomalie_detectee'] ?? '')) === 'oui')->count();
                $resume['resultats'] = [
                    ['label' => 'Taille population', 'valeur' => $record['taille_population'] ?? 'N/A'],
                    ['label' => 'Taille échantillon', 'valeur' => $record['taille_retenue'] ?? 'N/A'],
                    ['label' => 'Échantillon testé', 'valeur' => count($elements)],
                    ['label' => 'Anomalies détectées', 'valeur' => $anomalies],
                    ['label' => 'Taux d\'anomalie', 'valeur' => count($elements) > 0 ? round(($anomalies / count($elements)) * 100, 1) . '%' : 'N/A'],
                ];
                $resume['conclusion'] = $record['conclusion'] ?? '';
                $resume['score'] = $record['ia_result'] ? (json_decode($record['ia_result'], true)['score'] ?? null) : null;
                break;

            default:
                $resume['titre'] = $record['intitule'] ?? "Outil {$code}";
                $resume['resultats'] = [['label' => 'Données disponibles', 'valeur' => 'Consulter l\'outil pour plus de détails']];
                break;
        }

        return $resume;
    }

    private function chargerOutilsLiesBD(int $ficheTestId): array
    {
        $liaisons = DB::connection($this->conn)->table('fiche_test_outils')
            ->where('fiche_test_id', $ficheTestId)
            ->where('is_current', 1)
            ->orderBy('created_at')
            ->get();

        $outilsLies = [];
        $outilsParTest = [];

        foreach ($liaisons as $l) {
            if (!isset(self::OUTIL_TABLES[$l->outil_code])) continue;
            $mainTable = self::OUTIL_TABLES[$l->outil_code];
            $record    = DB::connection($this->conn)->table($mainTable)->where('id', $l->outil_id)->first();
            if (!$record) continue;

            $procIdx = property_exists($l, 'proc_idx') ? (int) $l->proc_idx : 0;
            $key = $l->outil_code . '::' . $l->procedure_code . '::' . $l->test_ref . '::' . $procIdx;
            $children = $this->loadChildren($l->outil_code, $l->outil_id);

            $resume = $this->resumeOutil($l->outil_code, (array) $record, $children);

            $outilsLies[$key] = [
                'outil_code'     => $l->outil_code,
                'procedure_code' => $l->procedure_code,
                'test_ref'       => $l->test_ref,
                'proc_idx'       => $procIdx,
                'obj_num'        => $l->obj_num,
                'outil_id'       => $l->outil_id,
                'record'         => (array) $record,
                'ia_result'      => $record->ia_result ? json_decode($record->ia_result, true) : null,
                'statut'         => $record->statut ?? 'draft',
                'children'       => $children,
                'label'          => self::OUTILS_IFACI[$l->outil_code]['label'] ?? "Outil {$l->outil_code}",
                'color'          => self::OUTILS_IFACI[$l->outil_code]['color'] ?? '#374151',
                'resume'         => $resume,
            ];

            // Index par test pour affichage dans la vue
            $testKey = ($l->obj_num ?? '') . '::' . $l->test_ref;
            if (!isset($outilsParTest[$testKey])) $outilsParTest[$testKey] = [];
            $outilsParTest[$testKey][] = [
                'outil_code' => $l->outil_code,
                'proc_idx'   => $procIdx,
                'outil_id'   => $l->outil_id,
                'key'        => $key,
                'label'      => self::OUTILS_IFACI[$l->outil_code]['label'] ?? "Outil {$l->outil_code}",
                'color'      => self::OUTILS_IFACI[$l->outil_code]['color'] ?? '#374151',
                'resume'     => $resume,
                'statut'     => $record->statut ?? 'draft',
                'ia_score'   => $record->ia_result ? (json_decode($record->ia_result, true)['score'] ?? null) : null,
            ];
        }

        return ['outilsLies' => $outilsLies, 'outilsParTest' => $outilsParTest];
    }

    private function loadChildren(string $outilCode, int $outilId): array
    {
        $result = [];
        $orderColumns = [
            'outil_entretien_questions' => 'ordre',
            'outil_analyse_taches_lignes' => 'ordre',
            'outil_approche_processus_lignes' => 'ordre',
            'outil_test_cheminement_etapes' => 'position',
            'outil_hierarchisation_risques_lignes' => 'ordre',
            'outil_cause_effet_causes' => 'ordre',
            'outil_qci_questions' => 'ordre',
            'outil_brainstorming_idees' => 'ordre',
            'outil_piste_audit_etapes' => 'position',
            'outil_circularisation_demandes' => 'ordre',
            'outil_audit_analytique_lignes' => 'ordre',
            'outil_observation_constats' => 'ordre',
            'outil_echantillonnage_elements' => 'ordre',
        ];

        foreach (self::OUTIL_CHILDREN[$outilCode] ?? [] as $def) {
            $table = $def['table'];
            $orderCol = $orderColumns[$table] ?? 'id';
            
            $result[$table] = DB::connection($this->conn)
                ->table($table)
                ->where($def['fk'], $outilId)
                ->orderBy($orderCol)
                ->get()
                ->toArray();
        }
        return $result;
    }

    protected function buildPayload(int $missionId, int $assignmentId, Auditor $auditor, mixed $form = null): array
    {
        $auditeurNom = trim($auditor->last_name . ' ' . $auditor->first_name);

        $missionRow = DB::connection($this->conn)->table('mission_programmation')
            ->where('id', $missionId)
            ->select('id', 'mission_id', 'code_mission', 'libelle', 'objectif', 'date_debut', 'date_fin', 'lieux')
            ->first();

        $realMissionId = $missionRow?->mission_id ?? $missionId;

        $phaseAuditeurs = DB::connection($this->conn)
            ->table('mission_phase_assignment_auditeurs as mpaa')
            ->join('auditors as a', 'a.id', '=', 'mpaa.auditeur_id')
            ->where('mpaa.assignment_id', $assignmentId)
            ->select('a.id', 'a.last_name', 'a.first_name', 'a.audit_code', 'mpaa.role_code',
                DB::raw("TRIM(CONCAT(COALESCE(a.last_name,''),' ',COALESCE(a.first_name,''))) as full_name"))
            ->orderByRaw("FIELD(mpaa.role_code,'DM','CM','AS','AJ')")
            ->get()->map(fn($a) => [
                'id'         => $a->id,
                'full_name'  => trim($a->full_name),
                'role_code'  => $a->role_code,
                'audit_code' => $a->audit_code,
                'is_current' => $a->id === $auditor->id,
            ])->toArray();

        $programmeData = $this->chargerTestsAuditeur($missionId, $assignmentId, $auditeurNom, $auditor->id);
        $outilVI       = $this->chargerDonneesOutilVI($realMissionId);
        $rciLignes     = $this->chargerLignesRCIpourVII($missionId, $assignmentId);

        $ficheData = null;
        $outilsLies = [];
        $outilsParTest = [];

        if ($form) {
            $ficheData = array_merge((array) $form, [
                'resultats'   => $this->decodeArr($form->resultats ?? null),
                'constats'    => $this->decodeArr($form->constats ?? null),
                'outils_data' => $this->decodeArr($form->outils_data ?? null),
                'media_items' => $this->decodeArr($form->media_items ?? null),
            ]);
            $loaded = $this->chargerOutilsLiesBD($form->id);
            $outilsLies = $loaded['outilsLies'];
            $outilsParTest = $loaded['outilsParTest'];
        }

        $formId = $form?->id ?? null;
        $role = $this->getRole($missionId, $auditor->id);

        return array_merge(
            parent::buildPayload($missionId, $assignmentId, $auditor, $form),
            [
                'form'           => $ficheData,
                'mission'        => $missionRow ? (array) $missionRow : null,
                'phaseAuditeurs' => $phaseAuditeurs,
                'programmeData'  => $programmeData,
                'outilsIfaci'    => array_values(self::OUTILS_IFACI),
                'outilsLies'     => $outilsLies,
                'outilsParTest'  => $outilsParTest,
                'processus'      => $outilVI['processus'],
                'risquesMission' => $outilVI['risques'],
                'rciLignes'      => $rciLignes,
                'auditorRole'    => $role,
                'auditeurNom'    => $auditeurNom,
                'missionContext' => [
                    'mission_id'      => $missionId,
                    'assignment_id'   => $assignmentId,
                    'mission_libelle' => $missionRow?->libelle ?? '',
                    'code_mission'    => $missionRow?->code_mission ?? '',
                ],
                'urlIndex'     => route('audit.ac.realisation.fiche-test'),
                'urlStore'     => route('auditor.ac.fiche-test.store'),
                'urlUpdate'    => $formId ? route('auditor.ac.fiche-test.update', $formId) : null,
                'urlSoumettre' => $formId ? route('auditor.ac.fiche-test.soumettre', $formId) : null,
                'urlValider'   => $formId ? route('auditor.ac.fiche-test.valider', $formId) : null,
                'backUrl'      => url("/m/audit.core/auditor/missions/{$missionId}/phases"),
                'urlSaveOutil' => $formId ? route('auditor.ac.fiche-test.save-outil', $formId) : null,
                'urlLoadOutil' => $formId ? route('auditor.ac.fiche-test.load-outil', $formId) : null,
                'urlIaGlobal'  => $formId ? route('auditor.ac.fiche-test.ia-global', $formId) : null,
                'urlEmail'     => $formId ? route('auditor.ac.fiche-test.email', $formId) : null,
            ]
        );
    }

    public function index(Request $request)
    {
        try {
            $auditor = $this->getAuditor();
            if (!$auditor) abort(403);
            $missionId    = (int) ($request->input('mission_id') ?? session('mission_id', 0));
            $assignmentId = (int) ($request->input('assignment_id') ?? session('assignment_id', 0));
            if (!$missionId || !$assignmentId) abort(422, 'Contexte mission manquant.');
            $existing = DB::connection($this->conn)->table($this->table)
                ->where('assignment_id', $assignmentId)->where('auditeur_id', $auditor->id)->first();
            if ($existing) {
                return redirect()->route($this->routeEdit, ['form' => $existing->id, 'mission_id' => $missionId, 'assignment_id' => $assignmentId]);
            }
            return Inertia::render($this->inertiaPage, $this->buildPayload($missionId, $assignmentId, $auditor, null));
        } catch (\Exception $e) {
            Log::error('[FT] index: ' . $e->getMessage());
            return back()->with('error', $e->getMessage());
        }
    }

    public function edit(Request $request, int $formId)
    {
        try {
            $auditor = $this->getAuditor();
            if (!$auditor) abort(403);
            $form = DB::connection($this->conn)->table($this->table)->where('id', $formId)->first();
            if (!$form) abort(404, 'Fiche introuvable.');
            if ((int) $form->auditeur_id !== $auditor->id) {
                $role = $this->getRole((int) $form->mission_id, $auditor->id);
                if (!in_array($role, ['DM', 'CM'])) abort(403, 'Accès refusé.');
            }
            $missionId    = (int) ($request->input('mission_id') ?? $form->mission_id);
            $assignmentId = (int) ($request->input('assignment_id') ?? $form->assignment_id);
            if (!$form->outils_migrated) $this->migrerOutilsLegacy($formId, $missionId, $assignmentId);
            return Inertia::render($this->inertiaPage, $this->buildPayload($missionId, $assignmentId, $auditor, $form));
        } catch (\Exception $e) {
            Log::error('[FT] edit: ' . $e->getMessage());
            return back()->with('error', $e->getMessage());
        }
    }

    public function store(Request $request): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) abort(403);
        $missionId    = (int) $request->input('mission_id', 0);
        $assignmentId = (int) $request->input('assignment_id', 0);
        if (!$missionId || !$assignmentId) {
            return response()->json(['success' => false, 'message' => 'Contexte mission manquant.'], 422);
        }
        $existing = DB::connection($this->conn)->table($this->table)
            ->where('assignment_id', $assignmentId)->where('auditeur_id', $auditor->id)->first();
        if ($existing) return $this->update($request, $existing->id);
        $id = DB::connection($this->conn)->table($this->table)->insertGetId([
            'assignment_id' => $assignmentId, 'mission_id' => $missionId, 'auditeur_id' => $auditor->id,
            'code'        => $this->genCode($missionId),
            'resultats'   => $this->toJson($request->input('resultats', '[]')),
            'constats'    => $this->toJson($request->input('constats', '[]')),
            'outils_data' => $this->toJson($request->input('outils_data', '{}')),
            'media_items' => $this->toJson($request->input('media_items', '[]')),
            'outils_migrated'   => 1,
            'validation_status' => 'draft',
            'created_by'  => $auditor->id,
            'created_at'  => now(),
            'updated_at'  => now(),
        ]);
        $role = $this->getRole($missionId, $auditor->id);
        $this->log($assignmentId, $auditor->id, $role, 'saved', null, 'draft');
        $form = DB::connection($this->conn)->table($this->table)->where('id', $id)->first();
        return response()->json([
            'success' => true, 'form' => $this->hydrateForm($form), 'message' => 'Fiche de test créée.',
            'urlUpdate'    => route('auditor.ac.fiche-test.update', $id),
            'urlSoumettre' => route('auditor.ac.fiche-test.soumettre', $id),
            'urlValider'   => route('auditor.ac.fiche-test.valider', $id),
            'urlSaveOutil' => route('auditor.ac.fiche-test.save-outil', $id),
            'urlLoadOutil' => route('auditor.ac.fiche-test.load-outil', $id),
            'urlIaGlobal'  => route('auditor.ac.fiche-test.ia-global', $id),
            'urlEmail'     => route('auditor.ac.fiche-test.email', $id),
        ]);
    }

    public function update(Request $request, int $formId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) abort(403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $formId)->first();
        if (!$row) return response()->json(['success' => false, 'message' => 'Formulaire introuvable.'], 404);
        $missionId    = (int) ($request->input('mission_id') ?? $row->mission_id);
        $assignmentId = (int) ($request->input('assignment_id') ?? $row->assignment_id);
        $role = $this->getRole($missionId, $auditor->id);
        if ((int) $row->auditeur_id !== $auditor->id && !in_array($role, ['DM', 'CM'])) {
            return response()->json(['success' => false, 'message' => 'Accès refusé.'], 403);
        }
        if (!$this->canEdit($row, $role)) {
            return response()->json(['success' => false, 'message' => 'Modification non autorisée.'], 403);
        }
        DB::connection($this->conn)->table($this->table)->where('id', $formId)->update([
            'resultats'   => $this->toJson($request->input('resultats', '[]')),
            'constats'    => $this->toJson($request->input('constats', '[]')),
            'outils_data' => $this->toJson($request->input('outils_data', '{}')),
            'media_items' => $this->toJson($request->input('media_items', '[]')),
            'updated_at'  => now(),
        ]);
        $this->log($assignmentId, $auditor->id, $role, 'saved', $row->validation_status, $row->validation_status);
        $updated = DB::connection($this->conn)->table($this->table)->where('id', $formId)->first();
        return response()->json(['success' => true, 'form' => $this->hydrateForm($updated), 'message' => 'Fiche mise à jour.']);
    }

    public function soumettre(Request $request, int $formId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['error' => 'Non autorisé'], 403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $formId)->first();
        if (!$row) return response()->json(['error' => 'Formulaire introuvable'], 404);
        if ((int) $row->auditeur_id !== $auditor->id) return response()->json(['error' => 'Seul le propriétaire peut soumettre'], 403);
        if ($row->validation_status !== 'draft') return response()->json(['error' => 'Statut invalide'], 422);
        DB::connection($this->conn)->table($this->table)->where('id', $formId)->update([
            'validation_status' => 'in_review', 'submitted_at' => now(), 'submitted_by' => $auditor->id, 'updated_at' => now(),
        ]);
        $role = $this->getRole((int) $row->mission_id, $auditor->id);
        $this->log((int) $row->assignment_id, $auditor->id, $role, 'submitted', 'draft', 'in_review');
        return response()->json(['success' => true, 'status' => 'in_review']);
    }

    public function valider(Request $request, int $formId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['error' => 'Non autorisé'], 403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $formId)->first();
        if (!$row) return response()->json(['error' => 'Formulaire introuvable'], 404);
        $role = $this->getRole((int) $row->mission_id, $auditor->id);
        if (!in_array($role, ['DM', 'CM'])) return response()->json(['error' => 'Seuls DM/CM peuvent valider'], 403);
        if ($row->validation_status !== 'in_review') return response()->json(['error' => 'Doit être soumis avant validation'], 422);
        $action = $request->input('action', 'validate');
        $note   = $request->input('note');
        if ($action === 'reject') {
            if (!$note) return response()->json(['error' => 'Motif obligatoire'], 422);
            DB::connection($this->conn)->table($this->table)->where('id', $formId)->update(['validation_status' => 'draft', 'validation_note' => $note, 'updated_at' => now()]);
            $this->log((int) $row->assignment_id, $auditor->id, $role, 'rejected', 'in_review', 'draft', $note);
            return response()->json(['success' => true, 'status' => 'draft', 'action' => 'rejected']);
        }
        DB::connection($this->conn)->table($this->table)->where('id', $formId)->update([
            'validation_status' => 'validated', 'validated_at' => now(), 'validated_by' => $auditor->id,
            'validation_note' => $note, 'updated_at' => now(),
        ]);
        $this->log((int) $row->assignment_id, $auditor->id, $role, 'validated', 'in_review', 'validated', $note);
        return response()->json(['success' => true, 'status' => 'validated', 'action' => 'validated']);
    }

    public function destroy(Request $request, int $formId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['error' => 'Non autorisé'], 403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $formId)->first();
        if (!$row) return response()->json(['error' => 'Formulaire introuvable'], 404);
        $role = $this->getRole((int) $row->mission_id, $auditor->id);
        if (!in_array($role, ['DM', 'CM'])) return response()->json(['error' => 'Seuls DM/CM peuvent supprimer'], 403);
        if ($row->validation_status === 'validated') return response()->json(['error' => 'Fiche validée non supprimable'], 403);
        $outilsLies = DB::connection($this->conn)->table('fiche_test_outils')->where('fiche_test_id', $formId)->get();
        foreach ($outilsLies as $ol) { $this->supprimerOutilBD($ol->outil_code, $ol->outil_id); }
        DB::connection($this->conn)->table('fiche_test_outils')->where('fiche_test_id', $formId)->delete();
        DB::connection($this->conn)->table($this->table)->where('id', $formId)->delete();
        $this->log((int) $row->assignment_id, $auditor->id, $role, 'deleted', $row->validation_status, null);
        return response()->json(['success' => true]);
    }

    public function saveOutil(Request $request, int $ficheTestId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['success' => false, 'error' => 'Non autorisé'], 403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->first();
        if (!$row) return response()->json(['success' => false, 'error' => 'Fiche introuvable'], 404);
        if ($row->validation_status === 'validated') {
            return response()->json(['success' => false, 'error' => 'Fiche validée — modification impossible'], 403);
        }

        $outilCode     = strtoupper(trim($request->input('outil_code', '')));
        $procedureCode = trim($request->input('procedure_code', ''));
        $testRef       = trim($request->input('test_ref', ''));
        $objNum        = trim($request->input('obj_num', ''));
        $procIdx       = (int) $request->input('proc_idx', 0);
        $data          = $request->input('data', []);
        $children      = $request->input('children', []);

        if (!$outilCode || !isset(self::OUTIL_TABLES[$outilCode])) {
            return response()->json(['success' => false, 'error' => "Code outil invalide : {$outilCode}"], 422);
        }

        $mainTable = self::OUTIL_TABLES[$outilCode];

        DB::connection($this->conn)->beginTransaction();
        try {
            $q = DB::connection($this->conn)->table('fiche_test_outils')
                ->where('fiche_test_id', $ficheTestId)
                ->where('outil_code', $outilCode)
                ->where('procedure_code', $procedureCode)
                ->where('test_ref', $testRef)
                ->where('is_current', 1);

            if ($this->columnExists('fiche_test_outils', 'proc_idx')) {
                $q->where('proc_idx', $procIdx);
            }

            $existing = $q->first();
            $outilId  = null;

            if ($existing) {
                $outilId = $existing->outil_id;
                $this->updateOutilRecord($outilCode, $outilId, $data, $auditor->id);
                $this->autoSave($outilCode, $mainTable, $outilId, $ficheTestId, $procedureCode, $data, $auditor->id);
            } else {
                $outilId = $this->insertOutilRecord($outilCode, $mainTable, $data, [
                    'mission_id'     => $row->mission_id,
                    'assignment_id'  => $row->assignment_id,
                    'procedure_code' => $procedureCode,
                    'test_ref'       => $testRef,
                    'obj_num'        => $objNum,
                    'created_by'     => $auditor->id,
                ]);

                $insertData = [
                    'fiche_test_id'  => $ficheTestId,
                    'mission_id'     => $row->mission_id,
                    'assignment_id'  => $row->assignment_id,
                    'procedure_code' => $procedureCode,
                    'test_ref'       => $testRef,
                    'obj_num'        => $objNum,
                    'outil_code'     => $outilCode,
                    'outil_table'    => $mainTable,
                    'outil_id'       => $outilId,
                    'version'        => 1,
                    'is_current'     => 1,
                    'created_by'     => $auditor->id,
                    'created_at'     => now(),
                    'updated_at'     => now(),
                ];

                if ($this->columnExists('fiche_test_outils', 'proc_idx')) {
                    $insertData['proc_idx'] = $procIdx;
                }

                DB::connection($this->conn)->table('fiche_test_outils')->insert($insertData);
            }

            if ($outilId && !empty($children)) {
                $this->syncChildren($outilCode, $outilId, $children);
            }

            DB::connection($this->conn)->commit();
            $saved = DB::connection($this->conn)->table($mainTable)->where('id', $outilId)->first();
            $childrenLoaded = $this->loadChildren($outilCode, $outilId);
            $resume = $this->resumeOutil($outilCode, (array) $saved, $childrenLoaded);

            return response()->json([
                'success'    => true,
                'outil_id'   => $outilId,
                'outil_code' => $outilCode,
                'proc_idx'   => $procIdx,
                'record'     => $saved,
                'children'   => $childrenLoaded,
                'resume'     => $resume,
                'message'    => "Outil {$outilCode} sauvegardé.",
            ]);

        } catch (\Exception $e) {
            DB::connection($this->conn)->rollBack();
            Log::error("[FT saveOutil] {$outilCode}: " . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function loadOutil(Request $request, int $ficheTestId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['success' => false, 'error' => 'Non autorisé'], 403);

        $outilCode     = strtoupper(trim($request->query('outil_code', '')));
        $procedureCode = trim($request->query('procedure_code', ''));
        $testRef       = trim($request->query('test_ref', ''));
        $procIdx       = (int) $request->query('proc_idx', 0);

        if (!$outilCode || !isset(self::OUTIL_TABLES[$outilCode])) {
            return response()->json(['success' => false, 'error' => 'Code outil invalide'], 422);
        }

        $mainTable = self::OUTIL_TABLES[$outilCode];

        $q = DB::connection($this->conn)->table('fiche_test_outils')
            ->where('fiche_test_id', $ficheTestId)
            ->where('outil_code', $outilCode)
            ->where('procedure_code', $procedureCode)
            ->where('test_ref', $testRef)
            ->where('is_current', 1);

        if ($this->columnExists('fiche_test_outils', 'proc_idx')) {
            $q->where('proc_idx', $procIdx);
        }

        $liaison = $q->first();

        if (!$liaison) {
            return response()->json(['success' => true, 'found' => false, 'record' => null, 'children' => []]);
        }

        $record   = DB::connection($this->conn)->table($mainTable)->where('id', $liaison->outil_id)->first();
        $children = $this->loadChildren($outilCode, $liaison->outil_id);
        $resume   = $this->resumeOutil($outilCode, (array) $record, $children);

        return response()->json([
            'success'   => true,
            'found'     => true,
            'outil_id'  => $liaison->outil_id,
            'proc_idx'  => $procIdx,
            'record'    => $record,
            'children'  => $children,
            'resume'    => $resume,
            'ia_result' => $record?->ia_result ? json_decode($record->ia_result, true) : null,
        ]);
    }

    public function iaGlobal(Request $request, int $ficheTestId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['success' => false, 'error' => 'Non autorisé'], 403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->first();
        if (!$row) return response()->json(['success' => false, 'error' => 'Fiche introuvable'], 404);
        
        $outilsLies = DB::connection($this->conn)->table('fiche_test_outils')->where('fiche_test_id', $ficheTestId)->where('is_current', 1)->get();
        $syntheses = [];
        
        foreach ($outilsLies as $ol) {
            if (!isset(self::OUTIL_TABLES[$ol->outil_code])) continue;
            $record = DB::connection($this->conn)->table(self::OUTIL_TABLES[$ol->outil_code])->where('id', $ol->outil_id)->first();
            if (!$record) continue;
            
            $iaData = $record->ia_result ? json_decode($record->ia_result, true) : null;
            $children = $this->loadChildren($ol->outil_code, $ol->outil_id);
            $resume = $this->resumeOutil($ol->outil_code, (array) $record, $children);
            
            $syntheses[] = [
                'outil_code'     => $ol->outil_code,
                'outil_label'    => self::OUTILS_IFACI[$ol->outil_code]['label'] ?? '',
                'test_ref'       => $ol->test_ref,
                'proc_idx'       => $ol->proc_idx ?? 0,
                'ia_score'       => $iaData['score'] ?? null,
                'ia_synthese'    => $iaData['synthese'] ?? null,
                'ia_risques'     => $iaData['risques'] ?? [],
                'ia_recs'        => $iaData['recommandations'] ?? [],
                'resume'         => $resume,
            ];
        }
        
        if (empty($syntheses)) {
            return response()->json(['success' => false, 'error' => "Aucun outil avec analyse IA trouvé."], 422);
        }
        
        $missionRow = DB::connection($this->conn)->table('mission_programmation')->where('id', $row->mission_id)->first();
        $prompt = "Tu es expert en audit interne IFACI. Synthèse des analyses IA de " . count($syntheses) . " outils pour la mission : " . ($missionRow?->libelle ?? 'N/A') . "\n\n" . json_encode($syntheses, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n\nGénère une synthèse globale. Retourne UNIQUEMENT un JSON valide avec: synthese (string), risques_majeurs (array), points_forts (array), recommandations (array), score_global (number 0-10), conclusion (string), fiabilite (haute|moyenne|faible).";
        
        try {
            $r = Http::withHeaders(['x-api-key' => config('services.anthropic.key'), 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json'])
                ->timeout(45)->post('https://api.anthropic.com/v1/messages', ['model' => 'claude-sonnet-4-20250514', 'max_tokens' => 2000, 'system' => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide sans markdown.', 'messages' => [['role' => 'user', 'content' => $prompt]]])->json();
            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];
            
            DB::connection($this->conn)->table('fiche_test_ia_global')->where('fiche_test_id', $ficheTestId)->update(['is_current' => 0, 'updated_at' => now()]);
            $iaGlobalId = DB::connection($this->conn)->table('fiche_test_ia_global')->insertGetId([
                'fiche_test_id' => $ficheTestId, 'mission_id' => $row->mission_id, 'assignment_id' => $row->assignment_id,
                'outils_analyses' => json_encode(array_column($syntheses, 'outil_code')),
                'synthese' => $data['synthese'] ?? '', 'risques_majeurs' => json_encode($data['risques_majeurs'] ?? []),
                'points_forts' => json_encode($data['points_forts'] ?? []), 'recommandations' => json_encode($data['recommandations'] ?? []),
                'score_global' => $data['score_global'] ?? null, 'conclusion' => $data['conclusion'] ?? '',
                'fiabilite' => $data['fiabilite'] ?? null, 'generated_by' => 'claude-sonnet-4-20250514',
                'generated_at' => now(), 'is_current' => 1, 'created_at' => now(), 'updated_at' => now(),
            ]);
            DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->update(['ia_global_id' => $iaGlobalId, 'updated_at' => now()]);
            return response()->json(['success' => true, 'ia_global' => $data, 'ia_global_id' => $iaGlobalId]);
        } catch (\Exception $e) {
            Log::error('[FT iaGlobal]: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function envoyerEmail(Request $request, int $ficheTestId): JsonResponse
    {
        $auditor = $this->getAuditor();
        if (!$auditor) return response()->json(['success' => false, 'error' => 'Non autorisé'], 403);
        $row = DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->first();
        if (!$row) return response()->json(['success' => false, 'error' => 'Fiche introuvable'], 404);
        
        $v = $request->validate([
            'type' => 'required|in:rapport_info,demande_confirmation,relance,validation_finale',
            'destinataire_nom' => 'required|string|max:255',
            'destinataire_email' => 'required|email|max:255',
            'sujet' => 'required|string|max:500',
            'corps_html' => 'required|string',
            'outils_inclus' => 'nullable|array',
        ]);
        
        $token = $v['type'] === 'demande_confirmation' ? Str::random(64) : null;
        $emailId = DB::connection($this->conn)->table('fiche_test_emails')->insertGetId([
            'fiche_test_id' => $ficheTestId, 'mission_id' => $row->mission_id, 'assignment_id' => $row->assignment_id,
            'type' => $v['type'], 'destinataire_nom' => $v['destinataire_nom'],
            'destinataire_email' => $v['destinataire_email'], 'sujet' => $v['sujet'], 'corps_html' => $v['corps_html'],
            'outils_inclus' => json_encode($v['outils_inclus'] ?? []), 'token_confirm' => $token,
            'statut' => 'pending', 'sent_by' => $auditor->id, 'created_at' => now(), 'updated_at' => now(),
        ]);
        
        try {
            $corps = $v['corps_html'];
            if ($token) {
                $confirmUrl = route('audit.confirmation.publique', ['token' => $token]);
                $corps .= "\n\n<p><a href='{$confirmUrl}' style='background:#1e40af;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:bold;'>Confirmer / Répondre</a></p>";
            }
            Mail::html($corps, function ($msg) use ($v) {
                $msg->to($v['destinataire_email'], $v['destinataire_nom'])->subject($v['sujet']);
            });
            DB::connection($this->conn)->table('fiche_test_emails')->where('id', $emailId)->update(['statut' => 'sent', 'envoye_at' => now(), 'updated_at' => now()]);
            return response()->json(['success' => true, 'email_id' => $emailId, 'token' => $token, 'message' => 'Email envoyé.']);
        } catch (\Exception $e) {
            DB::connection($this->conn)->table('fiche_test_emails')->where('id', $emailId)->update(['statut' => 'failed', 'error_msg' => $e->getMessage(), 'updated_at' => now()]);
            Log::error('[FT email]: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function confirmationPublique(string $token)
    {
        $email = DB::connection($this->conn)->table('fiche_test_emails')->where('token_confirm', $token)->where('statut', 'sent')->first();
        if (!$email) abort(404, 'Lien invalide ou expiré.');
        $fiche = DB::connection($this->conn)->table($this->table)->where('id', $email->fiche_test_id)->first();
        $mission = $fiche ? DB::connection($this->conn)->table('mission_programmation')->where('id', $fiche->mission_id)->select('libelle', 'code_mission')->first() : null;
        return Inertia::render('Auditor/Confirmation/Publique', ['email' => $email, 'token' => $token, 'mission' => $mission ? (array) $mission : null]);
    }

    public function confirmationSoumettre(Request $request, string $token): JsonResponse
    {
        $email = DB::connection($this->conn)->table('fiche_test_emails')->where('token_confirm', $token)->where('statut', 'sent')->first();
        if (!$email) return response()->json(['success' => false, 'error' => 'Token invalide.'], 404);
        
        $decision = $request->input('decision', 'confirmed');
        $commentaire = $request->input('commentaire');
        $nomConfirmataire = $request->input('nom_confirmataire', 'Audité');
        
        DB::connection($this->conn)->table('fiche_test_emails')->where('id', $email->id)->update([
            'statut' => $decision, 'confirme_at' => now(), 'confirme_par' => $nomConfirmataire,
            'commentaire_audite' => $commentaire, 'updated_at' => now(),
        ]);
        
        if ($decision === 'confirmed') {
            DB::connection($this->conn)->table($this->table)->where('id', $email->fiche_test_id)->update([
                'email_confirmed_at' => now(), 'email_confirmed_by' => $nomConfirmataire, 'updated_at' => now(),
            ]);
        }
        return response()->json(['success' => true, 'decision' => $decision]);
    }

    // ════════════════════════════════════════════════════════════
    // HELPERS CRUD
    // ════════════════════════════════════════════════════════════

    private function columnExists(string $table, string $column): bool
    {
        try {
            $cols = DB::connection($this->conn)->getSchemaBuilder()->getColumnListing($table);
            return in_array($column, $cols);
        } catch (\Exception) {
            return false;
        }
    }

    private function mapOutilFields(string $code, array $d): array
    {
        return match ($code) {
            'I'    => ['intitule' => $d['objectif_audit'] ?? '', 'objectif' => $d['objectif_audit'] ?? null, 'interlocuteur' => $d['interlocuteurs'] ?? null, 'date_entretien' => $d['date'] ?? null, 'synthese' => $d['synthese'] ?? null, 'sig_auditeur' => $d['sig_auditeur'] ?? null, 'sig_interlocuteur' => $d['sig_interlocuteur'] ?? null],
            'II'   => ['intitule' => $d['processus'] ?? 'Analyse des tâches', 'processus' => $d['processus'] ?? null, 'date_analyse' => $d['date'] ?? null, 'observations' => $d['observations'] ?? null, 'acteurs_json' => json_encode($d['acteurs'] ?? [])],
            'III'  => ['intitule' => $d['processus'] ?? 'Diagramme de flux', 'processus' => $d['processus'] ?? null, 'version' => $d['version'] ?? 'V1', 'description_narrative' => $d['description_narrative'] ?? null, 'synthese_validations' => $d['synthese_validations'] ?? null, 'activites_json' => json_encode($d['activites'] ?? [])],
            'IV'   => ['intitule' => $d['domaine'] ?? 'Approche processus', 'date_analyse' => $d['date'] ?? null],
            'V'    => ['intitule' => $d['transaction'] ?? 'Test de cheminement', 'processus_audite' => $d['processus'] ?? null, 'reference_transaction' => $d['reference'] ?? null, 'date_test' => $d['date_test'] ?? null, 'auditeur' => $d['auditeur'] ?? null, 'synthese_ecarts' => $d['synthese_ecarts'] ?? null, 'conclusion' => $d['conclusion'] ?? null, 'questions_verification' => json_encode($d['reponses_verification'] ?? [])],
            'VI'   => ['intitule' => $d['domaine'] ?? 'Hiérarchisation risques', 'perimetre' => $d['domaine'] ?? null, 'date_analyse' => $d['date'] ?? null, 'echelle' => $d['echelle'] ?? '3'],
            'VII'  => ['processus' => $d['processus'] ?? null, 'cadre_ref' => $d['cadre_ref'] ?? 'COSO', 'date' => $d['date'] ?? null, 'lignes' => json_encode($d['lignes'] ?? []), 'validation_diffuse_le' => $d['validation_diffuse_le'] ?? null, 'validation_reunion_le' => $d['validation_reunion_le'] ?? null, 'validation_valide_par' => $d['validation_valide_par'] ?? null, 'validation_date' => $d['validation_date'] ?? null, 'validation_commentaires' => $d['validation_commentaires'] ?? null],
            'VIII' => ['intitule' => $d['effet'] ?? 'Cause/Effet', 'effet_central' => $d['effet'] ?? null, 'description' => $d['description_effet'] ?? null, 'participants' => $d['participants'] ?? null, 'date_analyse' => $d['date'] ?? null, 'synthese' => $d['synthese'] ?? null],
            'IX'   => ['intitule' => $d['processus'] ?? 'QCI', 'processus' => $d['processus'] ?? null, 'cadre_reference' => $d['cadre_reference'] ?? 'COSO', 'date_qci' => $d['date'] ?? null, 'conclusion' => $d['conclusion'] ?? null],
            'X'    => ['intitule' => $d['sujet'] ?? 'Brainstorming', 'problematique' => $d['sujet'] ?? null, 'animateur' => $d['animateur'] ?? null, 'participants' => $d['participants'] ?? null, 'duree' => $d['duree'] ?? null, 'date_session' => $d['date'] ?? null, 'synthese' => $d['synthese'] ?? null],
            'XI'   => ['operation_testee' => $d['operation_testee'] ?? 'Piste audit', 'identifiant_unique' => $d['identifiant_unique'] ?? null, 'processus' => $d['processus'] ?? null, 'auditeur' => $d['auditeur'] ?? null, 'date_piste' => $d['date'] ?? null, 'conclusion' => $d['conclusion'] ?? null],
            'XII'  => ['date_envoi' => $d['date_envoi'] ?? null, 'date_limite' => $d['date_limite_reponse'] ?? null, 'adresse_reception' => $d['adresse_reception'] ?? null, 'auditeur_responsable' => $d['auditeur_responsable'] ?? null],
            'XIII' => ['auditeur' => $d['auditeur'] ?? null, 'source_donnees' => $d['source_donnees'] ?? null, 'date_procedure' => $d['date'] ?? null, 'periode' => $d['periode'] ?? null, 'conclusion' => $d['conclusion'] ?? null],
            'XIV'  => ['date_observation' => $d['date_observation'] ?? null, 'heure_debut' => $d['heure_debut'] ?? null, 'heure_fin' => $d['heure_fin'] ?? null, 'auditeur' => $d['auditeur'] ?? null, 'localisation' => $d['localisation'] ?? null, 'interlocuteurs_presents' => $d['interlocuteurs_presents'] ?? null, 'objectif_audit' => $d['objectif_audit'] ?? null, 'tache_local_observer' => $d['tache_local_observer'] ?? null, 'elements_verifier' => $d['elements_verifier'] ?? null, 'pieces_attendues' => $d['pieces_attendues'] ?? null, 'points_forts' => $d['points_forts'] ?? null, 'points_faibles' => $d['points_faibles'] ?? null, 'conclusion' => $d['conclusion'] ?? null],
            'XV'   => ['auditeur' => $d['auditeur'] ?? null, 'objectif_audit' => $d['objectif_audit'] ?? null, 'population_reference' => $d['population_reference'] ?? null, 'objet_test' => $d['objet_test'] ?? null, 'type_sondage' => $d['type_sondage'] ?? null, 'taille_population' => $d['taille_population'] ?? null, 'niveau_confiance' => $d['niveau_confiance'] ?? 95, 'coefficient_t' => $d['coefficient_t'] ?? null, 'erreur_max' => $d['erreur_max'] ?? null, 'ecart_type_exploratoire' => $d['ecart_type_exploratoire'] ?? null, 'taux_presence_exploratoire' => $d['taux_presence_exploratoire'] ?? null, 'taille_calculee' => $d['taille_calculee'] ?? null, 'taille_retenue' => $d['taille_retenue'] ?? null, 'intervalle_confiance' => $d['intervalle_confiance'] ?? null, 'conclusion' => $d['conclusion'] ?? null],
            default => [],
        };
    }

    private function normalizeChildRow(string $outilCode, string $table, array $row): array
    {
        if ($outilCode === 'I' && $table === 'outil_entretien_questions') {
            return ['type' => $row['type'] ?? 'Ouverte', 'libelle' => $row['question'] ?? ($row['libelle'] ?? ''), 'reponse' => $row['reponse'] ?? null, 'note' => $row['note'] ?? null];
        }
        if ($outilCode === 'II' && $table === 'outil_analyse_taches_lignes') {
            return ['libelle' => $row['libelle'] ?? ($row['tache'] ?? ''), 'acteur' => $row['acteur'] ?? null, 'frequence' => $row['frequence'] ?? null, 'risque' => $row['risque'] ?? null, 'controle' => $row['controle'] ?? null, 'observation' => $row['observation'] ?? null, 'roles_json' => isset($row['roles']) ? json_encode($row['roles']) : ($row['roles_json'] ?? null)];
        }
        if ($outilCode === 'IV' && $table === 'outil_approche_processus_lignes') {
            return ['type' => $row['type_processus'] ?? ($row['type'] ?? ''), 'libelle' => $row['nom'] ?? ($row['libelle'] ?? ''), 'finalite' => $row['finalite'] ?? null, 'elements_entrants' => $row['entrants'] ?? ($row['elements_entrants'] ?? null), 'elements_sortants' => $row['sortants'] ?? ($row['elements_sortants'] ?? null), 'activites_princ' => $row['activites'] ?? ($row['activites_princ'] ?? null), 'clients' => $row['clients'] ?? null, 'fournisseurs' => $row['fournisseurs'] ?? null, 'contrats_interface' => $row['contrats_interface'] ?? null, 'valeur' => $row['valeur'] ?? null];
        }
        if ($outilCode === 'V' && $table === 'outil_test_cheminement_etapes') {
            return ['position' => $row['position'] ?? 1, 'label' => $row['label'] ?? null, 'document_piece' => $row['document'] ?? ($row['document_piece'] ?? null), 'identifiant' => $row['identifiant'] ?? null, 'date_etape' => $row['date'] ?? ($row['date_etape'] ?? null), 'acteur' => $row['acteur'] ?? null, 'lien_etape_precedente' => $row['lien_precedent'] ?? ($row['lien_etape_precedente'] ?? null), 'present' => strtolower($row['present'] ?? ''), 'controle_applique' => $row['controle'] ?? ($row['controle_applique'] ?? ''), 'conforme_procedure' => $row['conforme'] ?? ($row['conforme_procedure'] ?? ''), 'observation_ecart' => $row['observation'] ?? ($row['observation_ecart'] ?? null), 'preuve_collectee' => $row['preuve'] ?? ($row['preuve_collectee'] ?? null)];
        }
        if ($outilCode === 'VI' && $table === 'outil_hierarchisation_risques_lignes') {
            return ['libelle' => $row['risque'] ?? ($row['libelle'] ?? ''), 'categorie' => $row['type'] ?? ($row['categorie'] ?? null), 'causes' => $row['causes'] ?? null, 'consequences' => $row['consequences'] ?? null, 'probabilite' => (int) ($row['probabilite'] ?? 1), 'impact' => (int) ($row['impact'] ?? 1), 'traitement' => $row['traitement'] ?? null, 'responsable' => $row['responsable'] ?? null, 'from_mission' => (int) ($row['from_mission'] ?? 0), 'risk_id' => $row['risk_id'] ?? null];
        }
        if ($outilCode === 'VIII' && $table === 'outil_cause_effet_causes') {
            $im = [1 => 'majeure', 2 => 'mineure', 3 => 'potentielle'];
            return ['categorie' => $row['categorie'] ?? '', 'libelle' => $row['cause_primaire'] ?? ($row['libelle'] ?? ''), 'sous_cause' => $row['cause_secondaire'] ?? ($row['sous_cause'] ?? null), 'detail_preuve' => $row['detail_preuve'] ?? null, 'importance' => $im[(int)($row['priorite'] ?? 0)] ?? 'mineure', 'priorite' => (int) ($row['priorite'] ?? 0), 'action_corrective' => $row['action_corrective'] ?? null];
        }
        if ($outilCode === 'IX' && $table === 'outil_qci_questions') {
            $nm = ['critique' => 'Fort', 'eleve' => 'Fort', 'modere' => 'Moyen', 'faible' => 'Faible'];
            return ['section_id' => $row['section_id'] ?? 0, 'num' => $row['id'] ?? ($row['num'] ?? null), 'libelle' => $row['question'] ?? ($row['libelle'] ?? ''), 'reponse' => $row['reponse'] ?? '', 'commentaire' => $row['constat'] ?? ($row['commentaire'] ?? null), 'risque_si_non' => $row['risque_si_non'] ?? null, 'niveau_risque' => $nm[$row['impact'] ?? ''] ?? ($row['niveau_risque'] ?? ''), 'impact' => $row['impact'] ?? null];
        }
        if ($outilCode === 'X' && $table === 'outil_brainstorming_idees') {
            return ['libelle' => $row['idee'] ?? ($row['libelle'] ?? ''), 'emis_par' => $row['emise_par'] ?? ($row['emis_par'] ?? null), 'theme' => $row['theme'] ?? null, 'categorie' => $row['categorie'] ?? null, 'votes' => (int) ($row['votes'] ?? 0), 'retenue' => (int) ($row['retenue'] ?? 0), 'a_approfondir' => (int) ($row['a_approfondir'] ?? 0), 'priorite' => (int) ($row['priorite'] ?? 0), 'description_approfondie' => $row['description_approfondie'] ?? null, 'comment_fonctionne' => $row['comment_fonctionne'] ?? null, 'faisabilite' => $row['faisabilite'] ?? ''];
        }
        if ($outilCode === 'XI' && $table === 'outil_piste_audit_etapes') {
            return ['position' => $row['position'] ?? 1, 'label' => $row['label'] ?? null, 'document_piece' => $row['document'] ?? ($row['document_piece'] ?? null), 'identifiant' => $row['identifiant'] ?? null, 'date_etape' => $row['date'] ?? ($row['date_etape'] ?? null), 'acteur' => $row['acteur'] ?? null, 'lien_etape_precedente' => $row['lien_precedent'] ?? ($row['lien_etape_precedente'] ?? null), 'present' => strtolower($row['present'] ?? '')];
        }
        if ($outilCode === 'XII' && $table === 'outil_circularisation_demandes') {
            $sm = ['CONFORME' => 'ok', 'ÉCART' => 'ecart', 'SANS_RÉPONSE' => 'sans_reponse', 'sans_réponse' => 'sans_reponse', 'en_attente' => 'en_attente', '' => 'en_attente'];
            $toFloat = fn($v) => ($v !== null && $v !== '') ? (float) str_replace([' ', ','], ['', '.'], $v) : null;
            return ['nom_tiers' => $row['tiers'] ?? '', 'element_confirmer' => $row['element_confirmer'] ?? null, 'date_envoi_demande' => $row['date_envoi'] ?? null, 'date_reponse' => $row['date_reponse'] ?? null, 'montant_envoye' => $toFloat($row['montant_periode'] ?? null), 'montant_confirme' => $toFloat($row['montant_confirme'] ?? null), 'ecart' => $toFloat($row['ecart'] ?? null), 'statut_reponse' => $sm[$row['statut'] ?? ''] ?? 'en_attente', 'observation' => $row['observation'] ?? null, 'niveau_fiabilite' => (int) ($row['niveau_fiabilite'] ?? 3)];
        }
        if ($outilCode === 'XIII' && $table === 'outil_audit_analytique_lignes') {
            $toD = fn($v) => ($v !== null && $v !== '') ? (float) str_replace([' ', ','], ['', '.'], (string)$v) : null;
            return ['indicateur' => $row['indicateur'] ?? '', 'description' => $row['description'] ?? null, 'valeur_n1' => $toD($row['valeur_n1'] ?? $row['valeur_n-1'] ?? null), 'valeur_n' => $toD($row['valeur_n'] ?? null), 'valeur_budget' => $toD($row['budget_prevu'] ?? $row['valeur_budget'] ?? null), 'ecart_n_n1' => $toD($row['ecart_n_n1'] ?? null), 'ecart_pct_n_n1' => $toD($row['ecart_pct_n_n1'] ?? null), 'ecart_n_budg' => $toD($row['ecart_n_budget'] ?? $row['ecart_n_budg'] ?? null), 'ecart_pct_budg' => $toD($row['ecart_pct_budg'] ?? null)];
        }
        if ($outilCode === 'XIV' && $table === 'outil_observation_constats') {
            return ['element_observe' => $row['element_observe'] ?? '', 'conforme_referentiel' => strtolower($row['conforme_referentiel'] ?? ''), 'ecart_constate' => $row['ecart_constate'] ?? null, 'risque_associe' => $row['risque_associe'] ?? null, 'preuve' => $row['preuve'] ?? null];
        }
        if ($outilCode === 'XV' && $table === 'outil_echantillonnage_elements') {
            return ['reference' => $row['reference'] ?? '', 'valeur' => is_numeric($row['valeur'] ?? null) ? (float)$row['valeur'] : null, 'attribut_present' => strtolower($row['attribut_present'] ?? ''), 'anomalie_detectee' => strtolower($row['anomalie_detectee'] ?? 'non'), 'nature_anomalie' => $row['nature_anomalie'] ?? null];
        }
        return $row;
    }

    private function insertOutilRecord(string $outilCode, string $table, array $data, array $meta): int
    {
        $base = ['mission_id' => $meta['mission_id'], 'assignment_id' => $meta['assignment_id'], 'procedure_code' => $meta['procedure_code'], 'test_ref' => $meta['test_ref'], 'obj_num' => $meta['obj_num'] ?? null, 'statut' => 'draft', 'created_by' => $meta['created_by'], 'created_at' => now(), 'updated_at' => now()];
        return DB::connection($this->conn)->table($table)->insertGetId(array_merge($base, $this->mapOutilFields($outilCode, $data)));
    }

    private function updateOutilRecord(string $outilCode, int $outilId, array $data, int $userId): void
    {
        $fields = $this->mapOutilFields($outilCode, $data);
        $fields['updated_by'] = $userId;
        $fields['updated_at'] = now();
        $fields['auto_save_at'] = now();
        DB::connection($this->conn)->table(self::OUTIL_TABLES[$outilCode])->where('id', $outilId)->update($fields);
    }

    private function syncChildren(string $outilCode, int $outilId, array $children): void
    {
        $orderColumns = [
            'outil_entretien_questions' => 'ordre',
            'outil_analyse_taches_lignes' => 'ordre',
            'outil_approche_processus_lignes' => 'ordre',
            'outil_test_cheminement_etapes' => 'position',
            'outil_hierarchisation_risques_lignes' => 'ordre',
            'outil_cause_effet_causes' => 'ordre',
            'outil_qci_questions' => 'ordre',
            'outil_brainstorming_idees' => 'ordre',
            'outil_piste_audit_etapes' => 'position',
            'outil_circularisation_demandes' => 'ordre',
            'outil_audit_analytique_lignes' => 'ordre',
            'outil_observation_constats' => 'ordre',
            'outil_echantillonnage_elements' => 'ordre',
        ];

        foreach (self::OUTIL_CHILDREN[$outilCode] ?? [] as $def) {
            $table = $def['table'];
            $fk    = $def['fk'];
            $rows  = $children[$table] ?? null;
            if ($rows === null) continue;
            
            DB::connection($this->conn)->table($table)->where($fk, $outilId)->delete();
            
            foreach ($rows as $idx => $row) {
                if (!is_array($row)) continue;
                $row = $this->normalizeChildRow($outilCode, $table, $row);
                $row[$fk] = $outilId;
                $orderCol = $orderColumns[$table] ?? 'ordre';
                $row[$orderCol] = $row[$orderCol] ?? ($idx + 1);
                $row['created_at'] = now();
                $row['updated_at'] = now();
                unset($row['id'], $row['_id'], $row['_from_mission']);
                
                try {
                    DB::connection($this->conn)->table($table)->insert($row);
                } catch (\Exception $e) {
                    Log::error("[FT syncChildren] {$outilCode}/{$table}: " . $e->getMessage());
                    throw $e;
                }
            }
        }
    }

    private function supprimerOutilBD(string $outilCode, int $outilId): void
    {
        foreach (self::OUTIL_CHILDREN[$outilCode] ?? [] as $def) {
            DB::connection($this->conn)->table($def['table'])->where($def['fk'], $outilId)->delete();
        }
        if (isset(self::OUTIL_TABLES[$outilCode])) {
            DB::connection($this->conn)->table(self::OUTIL_TABLES[$outilCode])->where('id', $outilId)->delete();
        }
    }

    private function autoSave(string $code, string $table, int $outilId, int $ficheTestId, string $procedureCode, array $data, int $userId): void
    {
        try {
            DB::connection($this->conn)->table('outil_auto_saves')->insert([
                'outil_code' => $code, 'outil_table' => $table, 'outil_id' => $outilId,
                'fiche_test_id' => $ficheTestId, 'procedure_code' => $procedureCode,
                'snapshot' => json_encode($data, JSON_UNESCAPED_UNICODE), 'saved_by' => $userId, 'saved_at' => now(),
            ]);
        } catch (\Exception) {}
    }

    private function migrerOutilsLegacy(int $ficheTestId, int $missionId, int $assignmentId): void
    {
        try {
            $row = DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->first();
            if (!$row) return;
            $outilsData = $this->decodeArr($row->outils_data ?? null);
            if (empty($outilsData)) {
                DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->update(['outils_migrated' => 1, 'updated_at' => now()]);
                return;
            }
            foreach ($outilsData as $item) {
                $code = $item['_code'] ?? null;
                $key  = $item['_key'] ?? null;
                if (!$code || !$key || !isset(self::OUTIL_TABLES[$code])) continue;
                $parts = explode('::', $key);
                $procedureCode = $parts[1] ?? '';
                $testRef = isset($parts[2]) ? ($parts[1] . '::' . $parts[2]) : ($parts[1] ?? '');
                if (DB::connection($this->conn)->table('fiche_test_outils')->where('fiche_test_id', $ficheTestId)->where('outil_code', $code)->where('procedure_code', $procedureCode)->where('test_ref', $testRef)->exists()) continue;
                $mainTable = self::OUTIL_TABLES[$code];
                $outilId = $this->insertOutilRecord($code, $mainTable, $item, ['mission_id' => $missionId, 'assignment_id' => $assignmentId, 'procedure_code' => $procedureCode, 'test_ref' => $testRef, 'obj_num' => $parts[1] ?? null, 'created_by' => $row->auditeur_id]);
                $insertData = ['fiche_test_id' => $ficheTestId, 'mission_id' => $missionId, 'assignment_id' => $assignmentId, 'procedure_code' => $procedureCode, 'test_ref' => $testRef, 'obj_num' => $parts[1] ?? null, 'outil_code' => $code, 'outil_table' => $mainTable, 'outil_id' => $outilId, 'version' => 1, 'is_current' => 1, 'created_by' => $row->auditeur_id, 'created_at' => now(), 'updated_at' => now()];
                if ($this->columnExists('fiche_test_outils', 'proc_idx')) $insertData['proc_idx'] = 0;
                DB::connection($this->conn)->table('fiche_test_outils')->insert($insertData);
                $childData = [];
                foreach (self::OUTIL_CHILDREN[$code] ?? [] as $def) {
                    if (isset($item[$def['table']]) && is_array($item[$def['table']])) $childData[$def['table']] = $item[$def['table']];
                }
                if ($outilId && !empty($childData)) $this->syncChildren($code, $outilId, $childData);
            }
            DB::connection($this->conn)->table($this->table)->where('id', $ficheTestId)->update(['outils_migrated' => 1, 'updated_at' => now()]);
        } catch (\Exception $e) {
            Log::warning('[FT migrerLegacy]: ' . $e->getMessage());
        }
    }

    private function chargerLignesRCIpourVII(int $missionId, int $assignmentId): array
    {
        try {
            $rciForm = DB::connection($this->conn)->table('mission_phase_ref_ci')
                ->when($assignmentId, fn($q) => $q->where('assignment_id', $assignmentId))
                ->when(!$assignmentId && $missionId, fn($q) => $q->where('mission_id', $missionId))
                ->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")
                ->orderByDesc('updated_at')->first();
            if (!$rciForm && $missionId) $rciForm = DB::connection($this->conn)->table('mission_phase_ref_ci')->where('mission_id', $missionId)->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")->orderByDesc('updated_at')->first();
            if (!$rciForm) return [];
            $lignes = $this->decodeArr($rciForm->criteres ?? null);
            if (empty($lignes)) return [];
            return array_map(fn(array $l) => ['objectif_processus' => $l['objectif_operationnel'] ?? $l['objectif_strategique'] ?? '', 'risque_associe' => $l['risque_libelle'] ?? '', 'controle_cle' => $l['description_controle'] ?? '', 'type_controle' => $l['type_controle'] ?? '', 'composante_coso' => $l['composante_coso'] ?? 'Act.Ctrl', 'conception' => '', 'a_tester' => 'Oui', 'objectif_audit' => $l['objectif_operationnel'] ?? '', '_from_rci' => true, '_risque_code' => $l['risque_code'] ?? '', '_criticite' => (float)($l['criticite_residuelle'] ?? 0), '_responsable' => $l['responsable_controle'] ?? '', '_process_code' => $l['process_code'] ?? ''], $lignes);
        } catch (\Exception $e) {
            Log::warning('[FT-VII] chargerLignesRCI: ' . $e->getMessage());
            return [];
        }
    }

    private function chargerDonneesOutilVI(int $realMissionId): array
    {
        $cssToHex = static fn(string $css): string => match(trim(strtolower($css))) {
            'success'=>'#28a745', 'danger'=>'#dc3545', 'warning'=>'#ffc107', 'info'=>'#17a2b8',
            'primary'=>'#0d6efd', 'secondary'=>'#6c757d', 'dark'=>'#343a40', 'light'=>'#f8f9fa',
            default => str_starts_with($css,'#') ? $css : '#6c757d'
        };
        $riskIds = DB::connection($this->conn)->table('mission_risk')->where('mission_id', $realMissionId)->pluck('risk_id')->toArray();
        $risks = [];
        if (!empty($riskIds)) {
            $risks = DB::connection($this->conn)->table('risks as r')
                ->leftJoin('risk_frequency_levels as rfl', fn($j) => $j->on('rfl.id','=','r.frequency_level_id')->whereNull('rfl.deleted_at'))
                ->leftJoin('risk_impact_levels as ril', fn($j) => $j->on('ril.id','=','r.impact_level_id')->whereNull('ril.deleted_at'))
                ->leftJoin('risk_types as rt', fn($j) => $j->on('rt.id','=','r.risk_type_id')->whereNull('rt.deleted_at'))
                ->leftJoin('processes as p','p.id','=','r.process_id')
                ->leftJoin('activities as a','a.id','=','r.activity_id')
                ->whereIn('r.id', $riskIds)->whereNull('r.deleted_at')
                ->select('r.id','r.code','r.label','r.description','r.process_id','r.activity_id','r.criticality','r.frequency_net','r.impact_net','r.status','r.owner','r.control_procedure',
                    DB::raw('rfl.level AS frequency_level'), DB::raw('rfl.label AS frequency_label'), DB::raw('rfl.color AS frequency_color'),
                    DB::raw('ril.level AS impact_level'), DB::raw('ril.label AS impact_label'), DB::raw('ril.color AS impact_color'),
                    DB::raw('rt.label AS risk_type_label'), DB::raw('rt.color AS risk_type_color'),
                    DB::raw('p.name AS process_name'), DB::raw('p.code AS process_code'),
                    DB::raw('a.name AS activity_name'))
                ->orderByDesc('r.criticality')->get()->map(function($r) use($cssToHex){
                    $fl = $r->frequency_level ? (int)$r->frequency_level : null;
                    $il = $r->impact_level ? (int)$r->impact_level : null;
                    $crit = ($fl && $il) ? ($fl * $il) : ((int)($r->criticality ?? 0));
                    return [
                        'id' => $r->id, 'code' => $r->code, 'label' => $r->label, 'description' => $r->description,
                        'process_id' => $r->process_id, 'activity_id' => $r->activity_id, 'criticality' => $crit,
                        'frequency_level' => $fl, 'frequency_label' => $r->frequency_label ?? '—', 'frequency_color' => $cssToHex($r->frequency_color ?? 'secondary'),
                        'frequency_net' => $r->frequency_net ? (float)$r->frequency_net : null,
                        'impact_level' => $il, 'impact_label' => $r->impact_label ?? '—', 'impact_color' => $cssToHex($r->impact_color ?? 'secondary'),
                        'impact_net' => $r->impact_net ? (float)$r->impact_net : null, 'status' => $r->status, 'owner' => $r->owner,
                        'control_procedure' => $r->control_procedure, 'risk_type_label' => $r->risk_type_label ?? '—',
                        'risk_type_color' => $cssToHex($r->risk_type_color ?? 'secondary'), 'process_name' => $r->process_name ?? '—',
                        'process_code' => $r->process_code ?? '—', 'activity_name' => $r->activity_name ?? '—',
                    ];
                })->toArray();
        }
        return ['processus' => [], 'risques' => $risks];
    }

    private function chargerTestsAuditeur(int $missionId, int $assignmentId, string $auditeurNom, int $auditorId): array
    {
        foreach (self::PROGRAMMES as $prog) {
            $row = DB::connection($this->conn)->table($prog['table'])
                ->where('assignment_id', $assignmentId)
                ->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")
                ->orderByDesc('updated_at')->first();
            if (!$row) {
                $row = DB::connection($this->conn)->table($prog['table'])
                    ->where('mission_id', $missionId)
                    ->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")
                    ->orderByDesc('updated_at')->first();
            }
            if (!$row) continue;
            
            $lignes = $this->decodeArr($row->lignes ?? null);
            $mesObjectifs = [];
            
            foreach ($lignes as $obj) {
                $testsAffecter = [];
                foreach ($obj['tests'] ?? [] as $test) {
                    $at = trim($test['auditeur'] ?? '');
                    if ($at !== '' && (strtolower($at) === strtolower($auditeurNom) || 
                        str_contains(strtolower($at), strtolower(explode(' ', $auditeurNom)[0] ?? '')) || 
                        str_contains(strtolower($auditeurNom), strtolower(explode(' ', $at)[0] ?? '')))) {
                        $testsAffecter[] = $test;
                    }
                }
                if (!empty($testsAffecter)) {
                    $mesObjectifs[] = array_merge($obj, ['tests' => $testsAffecter]);
                }
            }
            
            return [
                'found'            => true,
                'programme_code'   => $prog['code'],
                'programme_label'  => $prog['label'],
                'programme_status' => $row->validation_status,
                'objectifs'        => $mesObjectifs,
                'total_objectifs'  => count($mesObjectifs),
                'total_tests'      => array_sum(array_map(fn($o) => count($o['tests'] ?? []), $mesObjectifs)),
                'tous_tests'       => array_sum(array_map(fn($o) => count($o['tests'] ?? []), $lignes)),
            ];
        }
        return ['found' => false, 'programme_code' => null, 'programme_label' => null, 'objectifs' => [], 'total_objectifs' => 0, 'total_tests' => 0];
    }

    private function hydrateForm(mixed $row): array
    {
        if (!$row) return [];
        return array_merge((array) $row, [
            'resultats'   => $this->decodeArr($row->resultats   ?? null),
            'constats'    => $this->decodeArr($row->constats    ?? null),
            'outils_data' => $this->decodeArr($row->outils_data ?? null),
            'media_items' => $this->decodeArr($row->media_items ?? null),
        ]);
    }

    private function decodeArr(mixed $v): array
    {
        if (is_array($v)) return $v;
        if (!$v) return [];
        $d = json_decode($v, true);
        return is_array($d) ? $d : [];
    }

    private function toJson(mixed $v): string
    {
        if (is_string($v)) {
            json_decode($v);
            if (json_last_error() === JSON_ERROR_NONE) return $v;
        }
        return json_encode($v ?? [], JSON_UNESCAPED_UNICODE);
    }
}