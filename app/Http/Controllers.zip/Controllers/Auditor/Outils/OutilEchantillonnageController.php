<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil XV — Échantillonnage Statistique
 *
 * Structure réelle (feuille XV) :
 *
 * Étape 1 — Définition de la population et du test
 *   population_reference, objet_test, type_sondage (valeur/attribut), taille_population (N)
 *
 * Étape 2 — Paramètres statistiques
 *   niveau_confiance (90/95/99), coefficient_t (calculé), erreur_max (ε),
 *   ecart_type_exploratoire (σ) pour Valeur,
 *   taux_presence_exploratoire (p) pour Attribut
 *
 * Étape 3 — Calcul de la taille d'échantillon (formules ISO IFACI)
 *   - Valeur  : n ≥ (t² × σ²) / ε²
 *   - Attribut: n ≥ (t² × p×(1-p)) / ε²
 *   - Taille retenue (arrondi supérieur + marge sécurité)
 *
 * Étape 4 — Suivi de l'échantillon
 *   référence, valeur (sondage valeur), attribut présent (oui/non),
 *   anomalie détectée (oui/non), nature de l'anomalie
 *
 * Étape 5 — Extrapolation et conclusion
 *   moyenne_echantillon (m), taux_attributs (p), precision (ε),
 *   intervalle_confiance, conclusion
 *
 * Tables :
 *   outil_echantillonnage          → en-tête + paramètres + extrapolation + conclusion
 *   outil_echantillonnage_elements → lignes suivi échantillon (étape 4)
 */
class OutilEchantillonnageController extends Controller
{
    private string $conn = 'tenant';

    /** Coefficients t selon niveau de confiance */
    const COEFF_T = [90 => 1.645, 95 => 1.96, 99 => 2.576];

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_echantillonnage')->where('id', $id)->first();
        abort_if(!$record, 404, 'Fiche d\'échantillonnage introuvable.');
        return $record;
    }

    /**
     * Calcule la taille d'échantillon et le coefficient t.
     * @param int   $niveauConfiance  90 | 95 | 99
     * @param float $erreurMax        ε (valeur absolue ou ratio)
     * @param float|null $sigma       σ pour sondage Valeur
     * @param float|null $p           p pour sondage Attribut (0–1)
     * @param string $typeSondage     'valeur' | 'attribut'
     */
    private function calculerEchantillon(int $niveauConfiance, float $erreurMax, ?float $sigma, ?float $p, string $typeSondage): array
    {
        $t = self::COEFF_T[$niveauConfiance] ?? 1.96;
        $n = null;

        if ($typeSondage === 'valeur' && $sigma !== null && $erreurMax > 0) {
            $n = (int) ceil(($t * $t * $sigma * $sigma) / ($erreurMax * $erreurMax));
        } elseif ($typeSondage === 'attribut' && $p !== null && $erreurMax > 0) {
            $pVal = max(0.001, min(0.999, $p)); // éviter 0 ou 1
            $n = (int) ceil(($t * $t * $pVal * (1 - $pVal)) / ($erreurMax * $erreurMax));
        }

        // Marge de sécurité +5%
        $n_retenu = $n ? (int) ceil($n * 1.05) : null;

        return ['coefficient_t' => $t, 'taille_calculee' => $n, 'taille_retenue' => $n_retenu];
    }

    /**
     * Extrapolation à la population depuis les résultats de l'échantillon.
     */
    private function extrapolation(int $ficheId, ?float $taillePopulation): array
    {
        $elements = DB::connection($this->conn)
            ->table('outil_echantillonnage_elements')
            ->where('fiche_id', $ficheId)
            ->get();

        $n = $elements->count();
        if ($n === 0) return ['moyenne' => null, 'taux_attributs' => null, 'nb_anomalies' => 0];

        $somme         = $elements->sum('valeur');
        $moyenne       = round($somme / $n, 2);
        $nb_attributs  = $elements->where('attribut_present', 'oui')->count();
        $taux_attributs= round($nb_attributs / $n, 4); // ratio 0–1
        $nb_anomalies  = $elements->where('anomalie_detectee', 'oui')->count();

        return compact('moyenne', 'taux_attributs', 'nb_anomalies');
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_echantillonnage as oe')
            ->leftJoin('missions as m', 'm.id', '=', 'oe.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oe.created_by')
            ->select('oe.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oe.created_at');

        if ($missionId) $query->where('oe.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/Echantillonnage/Index', [
            'fiches'   => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $fiche    = $this->findOrFail($id);
        $elements = DB::connection($this->conn)->table('outil_echantillonnage_elements')
            ->where('fiche_id', $id)->orderBy('ordre')->get();

        $extrapolation = $this->extrapolation($id, $fiche->taille_population);

        return Inertia::render('Auditor/Outils/Echantillonnage/Edit', [
            'fiche'         => $fiche,
            'elements'      => $elements,
            'extrapolation' => $extrapolation,
            'coefficients'  => self::COEFF_T,
            'missions'      => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'                 => 'required|integer',
            'objectif_audit'             => 'nullable|string',
            // Étape 1
            'population_reference'       => 'nullable|string|max:255',
            'objet_test'                 => 'nullable|string|max:255',
            'type_sondage'               => 'nullable|in:valeur,attribut',
            'taille_population'          => 'nullable|integer|min:1',
            // Étape 2
            'niveau_confiance'           => 'nullable|in:90,95,99',
            'erreur_max'                 => 'nullable|numeric|min:0',
            'ecart_type_exploratoire'    => 'nullable|numeric|min:0',
            'taux_presence_exploratoire' => 'nullable|numeric|min:0|max:1',
            // Étape 5
            'intervalle_confiance'       => 'nullable|string|max:255',
            'conclusion'                 => 'nullable|string',
            // Étape 4 — éléments
            'elements'                          => 'nullable|array',
            'elements.*.reference'              => 'required|string|max:100',
            'elements.*.valeur'                 => 'nullable|numeric',
            'elements.*.attribut_present'       => 'nullable|in:oui,non',
            'elements.*.anomalie_detectee'       => 'nullable|in:oui,non',
            'elements.*.nature_anomalie'         => 'nullable|string',
            'elements.*.ordre'                   => 'nullable|integer',
        ]);

        // Calcul taille échantillon
        $calcul = $this->calculerEchantillon(
            (int)   ($v['niveau_confiance'] ?? 95),
            (float) ($v['erreur_max'] ?? 0.05),
            isset($v['ecart_type_exploratoire']) ? (float) $v['ecart_type_exploratoire'] : null,
            isset($v['taux_presence_exploratoire']) ? (float) $v['taux_presence_exploratoire'] : null,
            $v['type_sondage'] ?? 'attribut'
        );

        $id = DB::connection($this->conn)->table('outil_echantillonnage')->insertGetId([
            'mission_id'                 => $v['mission_id'],
            'objectif_audit'             => $v['objectif_audit'] ?? null,
            'population_reference'       => $v['population_reference'] ?? null,
            'objet_test'                 => $v['objet_test'] ?? null,
            'type_sondage'               => $v['type_sondage'] ?? null,
            'taille_population'          => $v['taille_population'] ?? null,
            'niveau_confiance'           => $v['niveau_confiance'] ?? 95,
            'coefficient_t'              => $calcul['coefficient_t'],
            'erreur_max'                 => $v['erreur_max'] ?? null,
            'ecart_type_exploratoire'    => $v['ecart_type_exploratoire'] ?? null,
            'taux_presence_exploratoire' => $v['taux_presence_exploratoire'] ?? null,
            'taille_calculee'            => $calcul['taille_calculee'],
            'taille_retenue'             => $calcul['taille_retenue'],
            'intervalle_confiance'       => $v['intervalle_confiance'] ?? null,
            'conclusion'                 => $v['conclusion'] ?? null,
            'statut'                     => 'draft',
            'created_by'                 => Auth::id(),
            'created_at'                 => now(),
            'updated_at'                 => now(),
        ]);

        foreach (($v['elements'] ?? []) as $idx => $e) {
            DB::connection($this->conn)->table('outil_echantillonnage_elements')->insert([
                'fiche_id'          => $id,
                'reference'         => $e['reference'],
                'valeur'            => $e['valeur'] ?? null,
                'attribut_present'  => $e['attribut_present'] ?? null,
                'anomalie_detectee' => $e['anomalie_detectee'] ?? 'non',
                'nature_anomalie'   => $e['nature_anomalie'] ?? null,
                'ordre'             => $e['ordre'] ?? ($idx + 1),
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);
        }

        return redirect()->route('auditor.outils.echantillonnage.edit', $id)
            ->with('success', 'Fiche d\'échantillonnage créée.');
    }

    public function update(Request $request, int $id)
    {
        $fiche = $this->findOrFail($id);
        abort_if($fiche->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'objectif_audit'                    => 'nullable|string',
            'population_reference'              => 'nullable|string|max:255',
            'objet_test'                        => 'nullable|string|max:255',
            'type_sondage'                      => 'nullable|in:valeur,attribut',
            'taille_population'                 => 'nullable|integer|min:1',
            'niveau_confiance'                  => 'nullable|in:90,95,99',
            'erreur_max'                        => 'nullable|numeric|min:0',
            'ecart_type_exploratoire'           => 'nullable|numeric|min:0',
            'taux_presence_exploratoire'        => 'nullable|numeric|min:0|max:1',
            'intervalle_confiance'              => 'nullable|string|max:255',
            'conclusion'                        => 'nullable|string',
            'elements'                          => 'nullable|array',
            'elements.*.reference'              => 'required|string|max:100',
            'elements.*.valeur'                 => 'nullable|numeric',
            'elements.*.attribut_present'       => 'nullable|in:oui,non',
            'elements.*.anomalie_detectee'      => 'nullable|in:oui,non',
            'elements.*.nature_anomalie'        => 'nullable|string',
            'elements.*.ordre'                  => 'nullable|integer',
        ]);

        $calcul = $this->calculerEchantillon(
            (int)   ($v['niveau_confiance'] ?? 95),
            (float) ($v['erreur_max'] ?? 0.05),
            isset($v['ecart_type_exploratoire']) ? (float) $v['ecart_type_exploratoire'] : null,
            isset($v['taux_presence_exploratoire']) ? (float) $v['taux_presence_exploratoire'] : null,
            $v['type_sondage'] ?? 'attribut'
        );

        DB::connection($this->conn)->table('outil_echantillonnage')->where('id', $id)->update([
            'objectif_audit'             => $v['objectif_audit'] ?? null,
            'population_reference'       => $v['population_reference'] ?? null,
            'objet_test'                 => $v['objet_test'] ?? null,
            'type_sondage'               => $v['type_sondage'] ?? null,
            'taille_population'          => $v['taille_population'] ?? null,
            'niveau_confiance'           => $v['niveau_confiance'] ?? 95,
            'coefficient_t'              => $calcul['coefficient_t'],
            'erreur_max'                 => $v['erreur_max'] ?? null,
            'ecart_type_exploratoire'    => $v['ecart_type_exploratoire'] ?? null,
            'taux_presence_exploratoire' => $v['taux_presence_exploratoire'] ?? null,
            'taille_calculee'            => $calcul['taille_calculee'],
            'taille_retenue'             => $calcul['taille_retenue'],
            'intervalle_confiance'       => $v['intervalle_confiance'] ?? null,
            'conclusion'                 => $v['conclusion'] ?? null,
            'updated_at'                 => now(),
        ]);

        DB::connection($this->conn)->table('outil_echantillonnage_elements')->where('fiche_id', $id)->delete();
        foreach (($v['elements'] ?? []) as $idx => $e) {
            DB::connection($this->conn)->table('outil_echantillonnage_elements')->insert([
                'fiche_id'          => $id,
                'reference'         => $e['reference'],
                'valeur'            => $e['valeur'] ?? null,
                'attribut_present'  => $e['attribut_present'] ?? null,
                'anomalie_detectee' => $e['anomalie_detectee'] ?? 'non',
                'nature_anomalie'   => $e['nature_anomalie'] ?? null,
                'ordre'             => $e['ordre'] ?? ($idx + 1),
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);
        }

        return back()->with('success', 'Fiche d\'échantillonnage mise à jour.');
    }

    public function soumettre(int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_echantillonnage')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Fiche soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_echantillonnage')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Fiche validée.' : 'Fiche rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_echantillonnage')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_echantillonnage_elements')->where('fiche_id', $id)->delete();
        DB::connection($this->conn)->table('outil_echantillonnage')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.echantillonnage.index')->with('success', 'Fiche supprimée.');
    }
}
