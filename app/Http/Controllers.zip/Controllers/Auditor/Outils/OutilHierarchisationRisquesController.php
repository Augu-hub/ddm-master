<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil VI — Hiérarchisation des Risques
 * Matrice probabilité × impact, criticité calculée, classement par priorité.
 */
class OutilHierarchisationRisquesController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_hierarchisation_risques')->where('id', $id)->first();
        abort_if(!$record, 404, 'Fiche hiérarchisation des risques introuvable.');
        return $record;
    }

    /** Calcule la criticité (1–9 ou 1–25 selon échelle) */
    private function criticite(int $probabilite, int $impact): int
    {
        return $probabilite * $impact;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_hierarchisation_risques as ohr')
            ->leftJoin('missions as m', 'm.id', '=', 'ohr.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'ohr.created_by')
            ->select('ohr.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('ohr.created_at');

        if ($missionId) $query->where('ohr.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/HierarchisationRisques/Index', [
            'fiches'   => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $fiche = $this->findOrFail($id);
        $risques = DB::connection($this->conn)->table('outil_hierarchisation_risques_lignes')
            ->where('fiche_id', $id)->orderByDesc('criticite')->get();

        return Inertia::render('Auditor/Outils/HierarchisationRisques/Edit', [
            'fiche'    => $fiche,
            'risques'  => $risques,
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'   => 'required|integer',
            'intitule'     => 'required|string|max:255',
            'perimetre'    => 'nullable|string',
            'date_analyse' => 'nullable|date',
            'echelle'      => 'nullable|in:3,5',  // échelle 3×3 ou 5×5
            'risques'      => 'nullable|array',
            'risques.*.libelle'      => 'required|string',
            'risques.*.categorie'    => 'nullable|string|max:100',
            'risques.*.probabilite'  => 'required|integer|min:1|max:5',
            'risques.*.impact'       => 'required|integer|min:1|max:5',
            'risques.*.traitement'   => 'nullable|string',
            'risques.*.responsable'  => 'nullable|string|max:255',
            'risques.*.echeance'     => 'nullable|date',
        ]);

        $id = DB::connection($this->conn)->table('outil_hierarchisation_risques')->insertGetId([
            'mission_id'   => $v['mission_id'],
            'intitule'     => $v['intitule'],
            'perimetre'    => $v['perimetre'] ?? null,
            'date_analyse' => $v['date_analyse'] ?? null,
            'echelle'      => $v['echelle'] ?? '5',
            'statut'       => 'draft',
            'created_by'   => Auth::id(),
            'created_at'   => now(),
            'updated_at'   => now(),
        ]);

        foreach (($v['risques'] ?? []) as $r) {
            DB::connection($this->conn)->table('outil_hierarchisation_risques_lignes')->insert([
                'fiche_id'      => $id,
                'libelle'       => $r['libelle'],
                'categorie'     => $r['categorie'] ?? null,
                'probabilite'   => $r['probabilite'],
                'impact'        => $r['impact'],
                'criticite'     => $this->criticite($r['probabilite'], $r['impact']),
                'traitement'    => $r['traitement'] ?? null,
                'responsable'   => $r['responsable'] ?? null,
                'echeance'      => $r['echeance'] ?? null,
                'created_at'    => now(),
                'updated_at'    => now(),
            ]);
        }

        return redirect()->route('auditor.ac.outil-hierarchisation-risques.edit', $id)
            ->with('success', 'Fiche hiérarchisation des risques créée.');
    }

    public function update(Request $request, int $id)
    {
        $fiche = $this->findOrFail($id);
        abort_if($fiche->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'     => 'required|string|max:255',
            'perimetre'    => 'nullable|string',
            'date_analyse' => 'nullable|date',
            'echelle'      => 'nullable|in:3,5',
            'risques'      => 'nullable|array',
            'risques.*.libelle'     => 'required|string',
            'risques.*.categorie'   => 'nullable|string|max:100',
            'risques.*.probabilite' => 'required|integer|min:1|max:5',
            'risques.*.impact'      => 'required|integer|min:1|max:5',
            'risques.*.traitement'  => 'nullable|string',
            'risques.*.responsable' => 'nullable|string|max:255',
            'risques.*.echeance'    => 'nullable|date',
        ]);

        DB::connection($this->conn)->table('outil_hierarchisation_risques')->where('id', $id)->update([
            'intitule'     => $v['intitule'],
            'perimetre'    => $v['perimetre'] ?? null,
            'date_analyse' => $v['date_analyse'] ?? null,
            'echelle'      => $v['echelle'] ?? '5',
            'updated_at'   => now(),
        ]);

        DB::connection($this->conn)->table('outil_hierarchisation_risques_lignes')->where('fiche_id', $id)->delete();
        foreach (($v['risques'] ?? []) as $r) {
            DB::connection($this->conn)->table('outil_hierarchisation_risques_lignes')->insert([
                'fiche_id'    => $id,
                'libelle'     => $r['libelle'],
                'categorie'   => $r['categorie'] ?? null,
                'probabilite' => $r['probabilite'],
                'impact'      => $r['impact'],
                'criticite'   => $this->criticite($r['probabilite'], $r['impact']),
                'traitement'  => $r['traitement'] ?? null,
                'responsable' => $r['responsable'] ?? null,
                'echeance'    => $r['echeance'] ?? null,
                'created_at'  => now(),
                'updated_at'  => now(),
            ]);
        }

        return back()->with('success', 'Fiche hiérarchisation mise à jour.');
    }

    public function soumettre(int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_hierarchisation_risques')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Fiche soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_hierarchisation_risques')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Fiche validée.' : 'Fiche rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_hierarchisation_risques')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_hierarchisation_risques_lignes')->where('fiche_id', $id)->delete();
        DB::connection($this->conn)->table('outil_hierarchisation_risques')->where('id', $id)->delete();
        return redirect()->route('auditor.ac.outil-hierarchisation-risques.index')->with('success', 'Fiche supprimée.');
    }
}
