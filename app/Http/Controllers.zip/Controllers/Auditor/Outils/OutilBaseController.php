<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

/**
 * ══════════════════════════════════════════════════════════════
 *  OutilBaseController
 *  Classe de base pour tous les contrôleurs d'outils IFACI I→XV
 *
 *  Chaque sous-classe définit :
 *    protected string $outilCode   = 'I';
 *    protected string $outilTable  = 'outil_entretiens';
 *    protected string $outilLabel  = "Grille d'Entretien";
 *    protected string $codePrefix  = 'ENTR';
 *    protected string $conn        = 'tenant';
 *
 *  Surcharges possibles :
 *    buildIaPrompt(array $data): string
 *    getOutilData(int $id): array   (données pour IA / email)
 *    syncLignes(int $id, array $data): void
 * ══════════════════════════════════════════════════════════════
 */
abstract class OutilBaseController extends Controller
{
    protected string $conn       = 'tenant';
    protected string $outilCode  = '';
    protected string $outilTable = '';
    protected string $outilLabel = '';
    protected string $codePrefix = '';

    // ════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════

    protected function db()
    {
        return DB::connection($this->conn);
    }

    protected function findRecord(int $id): object
    {
        $r = $this->db()->table($this->outilTable)->where('id', $id)->first();
        abort_if(!$r, 404, "{$this->outilLabel} introuvable (id={$id}).");
        return $r;
    }

    protected function genCode(int $missionId): string
    {
        $year = date('Y');
        $seq  = $this->db()->table($this->outilTable)->where('mission_id', $missionId)->count() + 1;
        return "{$this->codePrefix}-{$year}-" . str_pad($seq, 4, '0', STR_PAD_LEFT);
    }

    protected function decode(mixed $v): array
    {
        if (is_array($v)) return $v;
        if (!$v) return [];
        $d = json_decode($v, true);
        return is_array($d) ? $d : [];
    }

    protected function toJson(mixed $v): string
    {
        if (is_string($v)) {
            json_decode($v);
            if (json_last_error() === JSON_ERROR_NONE) return $v;
        }
        return json_encode($v ?? [], JSON_UNESCAPED_UNICODE);
    }

    // ════════════════════════════════════════════════════════
    //  LIAISON FicheTest ↔ Outil (fiche_test_outils)
    // ════════════════════════════════════════════════════════

    /**
     * Enregistre ou met à jour le lien procédure → outil.
     * Gère le versioning : chaque nouvel usage = version+1.
     */
    protected function enregistrerUsage(
        int    $ficheTestId,
        int    $missionId,
        int    $assignmentId,
        string $procedureCode,
        string $testRef,
        string $objNum,
        int    $outilId
    ): int {
        // Marquer l'ancienne version inactive
        $this->db()->table('fiche_test_outils')
            ->where('fiche_test_id', $ficheTestId)
            ->where('procedure_code', $procedureCode)
            ->where('test_ref', $testRef)
            ->where('outil_code', $this->outilCode)
            ->update(['is_current' => 0, 'updated_at' => now()]);

        // Prochaine version
        $version = ($this->db()->table('fiche_test_outils')
            ->where('fiche_test_id', $ficheTestId)
            ->where('procedure_code', $procedureCode)
            ->where('test_ref', $testRef)
            ->where('outil_code', $this->outilCode)
            ->max('version') ?? 0) + 1;

        return $this->db()->table('fiche_test_outils')->insertGetId([
            'fiche_test_id'  => $ficheTestId,
            'mission_id'     => $missionId,
            'assignment_id'  => $assignmentId,
            'procedure_code' => $procedureCode,
            'test_ref'       => $testRef,
            'obj_num'        => $objNum,
            'outil_code'     => $this->outilCode,
            'outil_table'    => $this->outilTable,
            'outil_id'       => $outilId,
            'version'        => $version,
            'is_current'     => 1,
            'created_by'     => Auth::id(),
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);
    }

    /**
     * Charge l'outil courant (version active) pour une procédure.
     */
    protected function chargerCourant(int $ficheTestId, string $procedureCode, string $testRef): ?object
    {
        $usage = $this->db()->table('fiche_test_outils')
            ->where('fiche_test_id', $ficheTestId)
            ->where('procedure_code', $procedureCode)
            ->where('test_ref', $testRef)
            ->where('outil_code', $this->outilCode)
            ->where('is_current', 1)
            ->first();

        return $usage
            ? $this->db()->table($this->outilTable)->where('id', $usage->outil_id)->first()
            : null;
    }

    /**
     * Historique des versions pour une procédure.
     */
    protected function historique(int $ficheTestId, string $procedureCode, string $testRef): array
    {
        return $this->db()->table('fiche_test_outils as u')
            ->leftJoin('users as uc', 'uc.id', '=', 'u.created_by')
            ->where('u.fiche_test_id', $ficheTestId)
            ->where('u.procedure_code', $procedureCode)
            ->where('u.test_ref', $testRef)
            ->where('u.outil_code', $this->outilCode)
            ->select('u.*', DB::raw("TRIM(CONCAT(COALESCE(uc.prenom,''),' ',COALESCE(uc.nom,''))) as auteur"))
            ->orderByDesc('u.version')
            ->get()
            ->map(fn($r) => [
                'id'             => $r->id,
                'outil_id'       => $r->outil_id,
                'version'        => $r->version,
                'is_current'     => (bool) $r->is_current,
                'ia_score'       => $r->ia_score,
                'ia_suggestion'  => $r->ia_suggestion ? json_decode($r->ia_suggestion, true) : null,
                'auteur'         => trim($r->auteur ?? ''),
                'created_at'     => $r->created_at,
            ])->toArray();
    }

    // ════════════════════════════════════════════════════════
    //  AUTO-SAVE
    // ════════════════════════════════════════════════════════

    protected function autoSave(int $outilId, array $snapshot, ?int $ficheTestId = null, ?string $procedureCode = null): void
    {
        try {
            $this->db()->table($this->outilTable)->where('id', $outilId)->update(['auto_save_at' => now()]);
            $this->db()->table('outil_auto_saves')->insert([
                'outil_code'     => $this->outilCode,
                'outil_table'    => $this->outilTable,
                'outil_id'       => $outilId,
                'fiche_test_id'  => $ficheTestId,
                'procedure_code' => $procedureCode,
                'snapshot'       => json_encode($snapshot, JSON_UNESCAPED_UNICODE),
                'saved_by'       => Auth::id(),
                'saved_at'       => now(),
            ]);
        } catch (\Exception $e) {
            Log::warning("[AutoSave][{$this->outilCode}#{$outilId}] {$e->getMessage()}");
        }
    }

    // ════════════════════════════════════════════════════════
    //  SUGGESTION IA
    // ════════════════════════════════════════════════════════

    public function ia(Request $request, int $id): JsonResponse
    {
        $record = $this->findRecord($id);
        $data   = $this->getOutilData($id);
        $result = $this->genererIa($id, $data);

        // Stocker dans usage lié si dispo
        $usage = $this->db()->table('fiche_test_outils')
            ->where('outil_table', $this->outilTable)
            ->where('outil_id', $id)
            ->where('is_current', 1)
            ->first();

        if ($usage) {
            $this->db()->table('fiche_test_outils')->where('id', $usage->id)->update([
                'ia_suggestion'   => json_encode($result, JSON_UNESCAPED_UNICODE),
                'ia_score'        => $result['score'] ?? null,
                'ia_generated_at' => now(),
                'updated_at'      => now(),
            ]);
        }

        return response()->json(['success' => true, 'ia_result' => $result]);
    }

    protected function genererIa(int $outilId, array $data): array
    {
        try {
            $prompt = $this->buildIaPrompt($data);

            $response = Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => "Tu es un expert en audit interne IFACI. Analyse les données fournies et retourne UNIQUEMENT un objet JSON valide avec exactement ces clés : synthese (string), points_forts (array of strings), points_faibles (array of strings), risques (array of strings), recommandations (array of strings), score (number 0-10). Aucun markdown, aucune explication.",
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($response['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $result = json_decode($text, true) ?? [];

            $this->db()->table($this->outilTable)->where('id', $outilId)->update([
                'ia_result'       => json_encode($result, JSON_UNESCAPED_UNICODE),
                'ia_score'        => $result['score'] ?? null,
                'ia_generated_at' => now(),
                'updated_at'      => now(),
            ]);

            return $result;
        } catch (\Exception $e) {
            Log::error("[IA][{$this->outilCode}] {$e->getMessage()}");
            return ['error' => 'IA indisponible : ' . $e->getMessage()];
        }
    }

    /**
     * À surcharger dans chaque contrôleur pour le prompt spécifique.
     */
    protected function buildIaPrompt(array $data): string
    {
        return "Analyse les données de l'outil {$this->outilLabel} (Outil {$this->outilCode} IFACI) :\n\n"
            . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
            . "\n\nFournis ton analyse JSON.";
    }

    /**
     * À surcharger dans chaque contrôleur pour fournir les données structurées.
     */
    protected function getOutilData(int $id): array
    {
        return (array) $this->findRecord($id);
    }

    // ════════════════════════════════════════════════════════
    //  WORKFLOW : soumettre / valider / rejeter
    // ════════════════════════════════════════════════════════

    public function soumettre(int $id): JsonResponse
    {
        $r = $this->findRecord($id);
        if ($r->statut === 'validated') return response()->json(['error' => 'Déjà validé.'], 422);
        if ($r->statut === 'in_review')  return response()->json(['error' => 'Déjà soumis.'], 422);

        $this->db()->table($this->outilTable)->where('id', $id)->update([
            'statut'       => 'in_review',
            'submitted_by' => Auth::id(),
            'submitted_at' => now(),
            'updated_at'   => now(),
        ]);

        return response()->json(['success' => true, 'statut' => 'in_review']);
    }

    public function valider(Request $request, int $id): JsonResponse
    {
        $r = $this->findRecord($id);
        if ($r->statut !== 'in_review') return response()->json(['error' => 'Doit être soumis.'], 422);

        $action = $request->input('action', 'validate');
        $note   = $request->input('note');

        if ($action === 'reject') {
            if (!$note) return response()->json(['error' => 'Motif obligatoire.'], 422);
            $this->db()->table($this->outilTable)->where('id', $id)->update([
                'statut' => 'draft', 'validation_note' => $note, 'updated_at' => now(),
            ]);
            return response()->json(['success' => true, 'statut' => 'draft', 'action' => 'rejected']);
        }

        $this->db()->table($this->outilTable)->where('id', $id)->update([
            'statut'          => 'validated',
            'validation_note' => $note,
            'validated_by'    => Auth::id(),
            'validated_at'    => now(),
            'updated_at'      => now(),
        ]);
        return response()->json(['success' => true, 'statut' => 'validated', 'action' => 'validated']);
    }

    public function destroy(int $id): JsonResponse
    {
        $r = $this->findRecord($id);
        if ($r->statut === 'validated') return response()->json(['error' => 'Impossible de supprimer un document validé.'], 403);

        // Détacher des usages
        $this->db()->table('fiche_test_outils')
            ->where('outil_table', $this->outilTable)->where('outil_id', $id)->delete();

        $this->db()->table($this->outilTable)->where('id', $id)->delete();
        return response()->json(['success' => true]);
    }

    // ════════════════════════════════════════════════════════
    //  EMAIL VERS AUDITÉ
    // ════════════════════════════════════════════════════════

    public function envoyerEmail(Request $request, int $ficheTestId): JsonResponse
    {
        $v = $request->validate([
            'audite_nom'    => 'required|string|max:255',
            'audite_email'  => 'required|email',
            'type'          => 'required|in:rapport_info,demande_confirmation,relance,validation_finale',
            'outil_ids'     => 'nullable|array',
            'message_perso' => 'nullable|string|max:2000',
            'mission_ref'   => 'nullable|string',
            'auditeur_nom'  => 'nullable|string',
        ]);

        $token   = Str::random(64);
        $sujet   = $this->buildEmailSujet($v['type'], $v['mission_ref'] ?? '');
        $corps   = $this->buildEmailCorps($v, $token, $ficheTestId);
        $isConf  = $v['type'] === 'demande_confirmation';

        // Charger les données de cet outil si ids fournis
        $sections = [];
        foreach ($v['outil_ids'] ?? [] as $outilId) {
            $rec = $this->db()->table($this->outilTable)->where('id', $outilId)->first();
            if ($rec) {
                $sections[] = $this->buildEmailSection($rec);
            }
        }

        $corps = $this->buildEmailHtml($v, $sections, $token, $ficheTestId);

        $ft = $this->db()->table('mission_phase_fiche_test')->where('id', $ficheTestId)->first();
        if (!$ft) return response()->json(['error' => 'Fiche de test introuvable.'], 404);

        $notifId = $this->db()->table('fiche_test_emails')->insertGetId([
            'fiche_test_id'      => $ficheTestId,
            'mission_id'         => $ft->mission_id,
            'assignment_id'      => $ft->assignment_id,
            'type'               => $v['type'],
            'destinataire_nom'   => $v['audite_nom'],
            'destinataire_email' => $v['audite_email'],
            'sujet'              => $sujet,
            'corps_html'         => $corps,
            'outils_inclus'      => json_encode($v['outil_ids'] ?? []),
            'token_confirm'      => $isConf ? $token : null,
            'statut'             => 'pending',
            'sent_by'            => Auth::id(),
            'created_at'         => now(), 'updated_at' => now(),
        ]);

        try {
            Mail::html($corps, fn($msg) => $msg
                ->to($v['audite_email'], $v['audite_nom'])
                ->subject($sujet)
                ->from(config('mail.from.address'), $v['auditeur_nom'] ?? config('mail.from.name'))
            );

            $this->db()->table('fiche_test_emails')->where('id', $notifId)->update([
                'statut' => 'sent', 'envoye_at' => now(), 'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'notif_id' => $notifId, 'token' => $isConf ? $token : null]);
        } catch (\Exception $e) {
            $this->db()->table('fiche_test_emails')->where('id', $notifId)->update([
                'statut' => 'failed', 'error_msg' => $e->getMessage(), 'updated_at' => now(),
            ]);
            Log::error("[Email][Outil{$this->outilCode}] " . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    protected function buildEmailSujet(string $type, string $missionRef): string
    {
        return match ($type) {
            'demande_confirmation' => "[Audit] Demande de confirmation — {$missionRef}",
            'validation_finale'    => "[Audit] Rapport final validé — {$missionRef}",
            'relance'              => "[Audit] Relance — {$missionRef}",
            default                => "[Audit] Rapport d'informations — {$missionRef}",
        };
    }

    protected function buildEmailSection(object $rec): array
    {
        return ['titre' => $this->outilLabel, 'contenu' => ''];
    }

    protected function buildEmailHtml(array $v, array $sections, string $token, int $ficheTestId): string
    {
        $confirmUrl  = url("/audit/confirmation/{$token}");
        $isConf      = $v['type'] === 'demande_confirmation';
        $nomAudite   = htmlspecialchars($v['audite_nom']);
        $auditeurNom = htmlspecialchars($v['auditeur_nom'] ?? '');
        $missionRef  = htmlspecialchars($v['mission_ref'] ?? '');

        $sectionsHtml = collect($sections)->map(fn($s) =>
            "<h3 style='color:#1e40af;font-size:14px;margin:12px 0 4px;'>" . htmlspecialchars($s['titre']) . "</h3>"
            . "<div style='background:#f8fafc;border-left:3px solid #1e40af;padding:10px;border-radius:0 4px 4px 0;font-size:13px;white-space:pre-wrap;'>"
            . htmlspecialchars($s['contenu'] ?? '') . "</div>"
        )->implode('');

        if ($v['message_perso'] ?? '') {
            $sectionsHtml .= "<div style='background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:12px;margin:12px 0;'>"
                           . "<p style='margin:0;font-size:13px;'><strong>Message de l'auditeur :</strong><br>" . htmlspecialchars($v['message_perso']) . "</p></div>";
        }

        $confirmBtns = $isConf ? "
        <div style='text-align:center;margin:20px 0;'>
          <a href='{$confirmUrl}' style='background:#15803d;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:bold;display:inline-block;margin:4px;'>✅ Confirmer les informations</a>
          <a href='{$confirmUrl}?action=reject' style='background:#dc2626;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:bold;display:inline-block;margin:4px;'>❌ Signaler une anomalie</a>
        </div>
        <p style='text-align:center;font-size:11px;color:#9ca3af;'>Ce lien est valable 30 jours.</p>" : '';

        return "<!DOCTYPE html><html lang='fr'><head><meta charset='UTF-8'></head>
<body style='margin:0;padding:20px;background:#f1f5f9;font-family:Arial,sans-serif;'>
<div style='max-width:660px;margin:0 auto;'>
  <div style='background:#1e40af;padding:20px;border-radius:8px 8px 0 0;'>
    <h1 style='color:white;margin:0;font-size:18px;'>🔍 Mission d'Audit — {$missionRef}</h1>
  </div>
  <div style='background:white;padding:24px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 8px 8px;'>
    <p>Bonjour <strong>{$nomAudite}</strong>,</p>
    <p style='font-size:14px;'>{$auditeurNom} vous transmet les informations collectées lors de la mission d'audit.</p>
    {$sectionsHtml}
    {$confirmBtns}
    <hr style='border:none;border-top:1px solid #e2e8f0;margin:16px 0;'>
    <p style='font-size:11px;color:#9ca3af;'>Message généré automatiquement par le système d'audit interne.</p>
  </div>
</div></body></html>";
    }
}
