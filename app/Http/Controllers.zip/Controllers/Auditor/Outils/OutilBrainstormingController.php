<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil X — Brainstorming / Remue-méninges
 * Collecte d'idées, regroupement par thème, vote/priorisation.
 */
class OutilBrainstormingController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_brainstorming')->where('id', $id)->first();
        abort_if(!$record, 404, 'Session de brainstorming introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_brainstorming as ob')
            ->leftJoin('missions as m', 'm.id', '=', 'ob.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'ob.created_by')
            ->select('ob.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('ob.created_at');

        if ($missionId) $query->where('ob.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/Brainstorming/Index', [
            'sessions' => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $session = $this->findOrFail($id);
        $idees = DB::connection($this->conn)->table('outil_brainstorming_idees')
            ->where('session_id', $id)->orderByDesc('votes')->orderBy('ordre')->get();

        return Inertia::render('Auditor/Outils/Brainstorming/Edit', [
            'session'  => $session,
            'idees'    => $idees,
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'    => 'required|integer',
            'intitule'      => 'required|string|max:255',
            'problematique' => 'nullable|string',
            'animateur'     => 'nullable|string|max:255',
            'participants'  => 'nullable|string',
            'date_session'  => 'nullable|date',
            'idees'         => 'nullable|array',
            'idees.*.libelle'   => 'required|string',
            'idees.*.theme'     => 'nullable|string|max:100',
            'idees.*.votes'     => 'nullable|integer|min:0',
            'idees.*.retenue'   => 'nullable|boolean',
            'idees.*.ordre'     => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_brainstorming')->insertGetId([
            'mission_id'    => $v['mission_id'],
            'intitule'      => $v['intitule'],
            'problematique' => $v['problematique'] ?? null,
            'animateur'     => $v['animateur'] ?? null,
            'participants'  => $v['participants'] ?? null,
            'date_session'  => $v['date_session'] ?? null,
            'statut'        => 'draft',
            'created_by'    => Auth::id(),
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);

        foreach (($v['idees'] ?? []) as $idx => $i) {
            DB::connection($this->conn)->table('outil_brainstorming_idees')->insert([
                'session_id' => $id,
                'libelle'    => $i['libelle'],
                'theme'      => $i['theme'] ?? null,
                'votes'      => $i['votes'] ?? 0,
                'retenue'    => $i['retenue'] ?? false,
                'ordre'      => $i['ordre'] ?? ($idx + 1),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return redirect()->route('auditor.outils.brainstorming.edit', $id)
            ->with('success', 'Session de brainstorming créée.');
    }

    public function update(Request $request, int $id)
    {
        $session = $this->findOrFail($id);
        abort_if($session->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'      => 'required|string|max:255',
            'problematique' => 'nullable|string',
            'animateur'     => 'nullable|string|max:255',
            'participants'  => 'nullable|string',
            'date_session'  => 'nullable|date',
            'idees'         => 'nullable|array',
            'idees.*.libelle' => 'required|string',
            'idees.*.theme'   => 'nullable|string|max:100',
            'idees.*.votes'   => 'nullable|integer|min:0',
            'idees.*.retenue' => 'nullable|boolean',
            'idees.*.ordre'   => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_brainstorming')->where('id', $id)->update([
            'intitule'      => $v['intitule'],
            'problematique' => $v['problematique'] ?? null,
            'animateur'     => $v['animateur'] ?? null,
            'participants'  => $v['participants'] ?? null,
            'date_session'  => $v['date_session'] ?? null,
            'updated_at'    => now(),
        ]);

        DB::connection($this->conn)->table('outil_brainstorming_idees')->where('session_id', $id)->delete();
        foreach (($v['idees'] ?? []) as $idx => $i) {
            DB::connection($this->conn)->table('outil_brainstorming_idees')->insert([
                'session_id' => $id,
                'libelle'    => $i['libelle'],
                'theme'      => $i['theme'] ?? null,
                'votes'      => $i['votes'] ?? 0,
                'retenue'    => $i['retenue'] ?? false,
                'ordre'      => $i['ordre'] ?? ($idx + 1),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return back()->with('success', 'Session de brainstorming mise à jour.');
    }

    public function soumettre(int $id)
    {
        $s = $this->findOrFail($id);
        abort_if($s->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_brainstorming')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Session soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $s = $this->findOrFail($id);
        abort_if($s->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_brainstorming')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Session validée.' : 'Session rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_brainstorming')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_brainstorming_idees')->where('session_id', $id)->delete();
        DB::connection($this->conn)->table('outil_brainstorming')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.brainstorming.index')->with('success', 'Session supprimée.');
    }
}
