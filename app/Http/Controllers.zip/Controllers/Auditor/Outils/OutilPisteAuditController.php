<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil XI — Piste d'Audit
 *
 * Structure réelle (feuille XI-Piste d'Audit) :
 *  - En-tête   : mission, date, auditeur, opération testée, identifiant unique, processus
 *  - Étapes chronologiques (t-n → t) : document/pièce, identifiant, date, acteur,
 *                                       lien étape précédente, présent (oui/non)
 *  - Résultats de l'analyse : 6 critères prédéfinis (satisfaisant / insatisfaisant + observation)
 *  - Conclusion et implications
 *
 * Tables :
 *   outil_piste_audit            → en-tête + conclusion
 *   outil_piste_audit_etapes     → étapes chronologiques
 *   outil_piste_audit_resultats  → critères d'analyse (6 lignes fixes ou dynamiques)
 */
class OutilPisteAuditController extends Controller
{
    private string $conn = 'tenant';

    /** Critères d'analyse fixes IFACI */
    const CRITERES = [
        'documents_existent'       => 'Les documents existent pour chaque étape',
        'identifiants_coherents'   => 'Les identifiants permettent de reconstituer la transaction',
        'piste_complete'           => 'La piste d\'audit est complète (aucun maillon manquant)',
        'piste_coherente'          => 'La piste d\'audit est cohérente (pas d\'incohérence entre étapes)',
        'controles_documentes'     => 'Les contrôles aux points clés sont documentés',
        'conformite_reglementaire' => 'La traçabilité est conforme aux exigences réglementaires',
    ];

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_piste_audit')->where('id', $id)->first();
        abort_if(!$record, 404, 'Piste d\'audit introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_piste_audit as opa')
            ->leftJoin('missions as m', 'm.id', '=', 'opa.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'opa.created_by')
            ->select('opa.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('opa.created_at');

        if ($missionId) $query->where('opa.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/PisteAudit/Index', [
            'pistes'   => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $piste = $this->findOrFail($id);

        $etapes = DB::connection($this->conn)
            ->table('outil_piste_audit_etapes')
            ->where('piste_id', $id)
            ->orderBy('position')
            ->get();

        $resultats = DB::connection($this->conn)
            ->table('outil_piste_audit_resultats')
            ->where('piste_id', $id)
            ->get()
            ->keyBy('critere');

        // Injecter les libellés des critères
        $criteresData = collect(self::CRITERES)->map(function ($libelle, $code) use ($resultats) {
            $r = $resultats->get($code);
            return [
                'code'        => $code,
                'libelle'     => $libelle,
                'resultat'    => $r->resultat ?? null,      // satisfaisant | insatisfaisant | null
                'observation' => $r->observation ?? null,
            ];
        })->values();

        return Inertia::render('Auditor/Outils/PisteAudit/Edit', [
            'piste'    => $piste,
            'etapes'   => $etapes,
            'criteres' => $criteresData,
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'         => 'required|integer',
            'operation_testee'   => 'required|string|max:255',
            'identifiant_unique' => 'nullable|string|max:100',
            'processus'          => 'nullable|string|max:255',
            'auditeur'           => 'nullable|string|max:255',
            'date_piste'         => 'nullable|date',
            'conclusion'         => 'nullable|string',
            // Étapes chronologiques
            'etapes'                              => 'nullable|array',
            'etapes.*.position'                   => 'required|string|max:20',   // t-6, t-5 … t
            'etapes.*.document_piece'             => 'nullable|string|max:255',
            'etapes.*.identifiant'                => 'nullable|string|max:100',
            'etapes.*.date_etape'                 => 'nullable|date',
            'etapes.*.acteur'                     => 'nullable|string|max:255',
            'etapes.*.lien_etape_precedente'      => 'nullable|string|max:100',
            'etapes.*.present'                    => 'nullable|in:oui,non',
            // Critères d'analyse
            'resultats'                           => 'nullable|array',
            'resultats.*.critere'                 => 'required|string',
            'resultats.*.resultat'                => 'nullable|in:satisfaisant,insatisfaisant',
            'resultats.*.observation'             => 'nullable|string',
        ]);

        $id = DB::connection($this->conn)->table('outil_piste_audit')->insertGetId([
            'mission_id'         => $v['mission_id'],
            'operation_testee'   => $v['operation_testee'],
            'identifiant_unique' => $v['identifiant_unique'] ?? null,
            'processus'          => $v['processus'] ?? null,
            'auditeur'           => $v['auditeur'] ?? null,
            'date_piste'         => $v['date_piste'] ?? null,
            'conclusion'         => $v['conclusion'] ?? null,
            'statut'             => 'draft',
            'created_by'         => Auth::id(),
            'created_at'         => now(),
            'updated_at'         => now(),
        ]);

        foreach (($v['etapes'] ?? []) as $e) {
            DB::connection($this->conn)->table('outil_piste_audit_etapes')->insert([
                'piste_id'               => $id,
                'position'               => $e['position'],
                'document_piece'         => $e['document_piece'] ?? null,
                'identifiant'            => $e['identifiant'] ?? null,
                'date_etape'             => $e['date_etape'] ?? null,
                'acteur'                 => $e['acteur'] ?? null,
                'lien_etape_precedente'  => $e['lien_etape_precedente'] ?? null,
                'present'                => $e['present'] ?? null,
                'created_at'             => now(),
                'updated_at'             => now(),
            ]);
        }

        foreach (($v['resultats'] ?? []) as $r) {
            DB::connection($this->conn)->table('outil_piste_audit_resultats')->insert([
                'piste_id'    => $id,
                'critere'     => $r['critere'],
                'resultat'    => $r['resultat'] ?? null,
                'observation' => $r['observation'] ?? null,
                'created_at'  => now(),
                'updated_at'  => now(),
            ]);
        }

        return redirect()->route('auditor.outils.piste-audit.edit', $id)
            ->with('success', 'Piste d\'audit créée.');
    }

    public function update(Request $request, int $id)
    {
        $piste = $this->findOrFail($id);
        abort_if($piste->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'operation_testee'               => 'required|string|max:255',
            'identifiant_unique'             => 'nullable|string|max:100',
            'processus'                      => 'nullable|string|max:255',
            'auditeur'                       => 'nullable|string|max:255',
            'date_piste'                     => 'nullable|date',
            'conclusion'                     => 'nullable|string',
            'etapes'                         => 'nullable|array',
            'etapes.*.position'              => 'required|string|max:20',
            'etapes.*.document_piece'        => 'nullable|string|max:255',
            'etapes.*.identifiant'           => 'nullable|string|max:100',
            'etapes.*.date_etape'            => 'nullable|date',
            'etapes.*.acteur'                => 'nullable|string|max:255',
            'etapes.*.lien_etape_precedente' => 'nullable|string|max:100',
            'etapes.*.present'               => 'nullable|in:oui,non',
            'resultats'                      => 'nullable|array',
            'resultats.*.critere'            => 'required|string',
            'resultats.*.resultat'           => 'nullable|in:satisfaisant,insatisfaisant',
            'resultats.*.observation'        => 'nullable|string',
        ]);

        DB::connection($this->conn)->table('outil_piste_audit')->where('id', $id)->update([
            'operation_testee'   => $v['operation_testee'],
            'identifiant_unique' => $v['identifiant_unique'] ?? null,
            'processus'          => $v['processus'] ?? null,
            'auditeur'           => $v['auditeur'] ?? null,
            'date_piste'         => $v['date_piste'] ?? null,
            'conclusion'         => $v['conclusion'] ?? null,
            'updated_at'         => now(),
        ]);

        DB::connection($this->conn)->table('outil_piste_audit_etapes')->where('piste_id', $id)->delete();
        foreach (($v['etapes'] ?? []) as $e) {
            DB::connection($this->conn)->table('outil_piste_audit_etapes')->insert([
                'piste_id'              => $id,
                'position'              => $e['position'],
                'document_piece'        => $e['document_piece'] ?? null,
                'identifiant'           => $e['identifiant'] ?? null,
                'date_etape'            => $e['date_etape'] ?? null,
                'acteur'                => $e['acteur'] ?? null,
                'lien_etape_precedente' => $e['lien_etape_precedente'] ?? null,
                'present'               => $e['present'] ?? null,
                'created_at'            => now(),
                'updated_at'            => now(),
            ]);
        }

        DB::connection($this->conn)->table('outil_piste_audit_resultats')->where('piste_id', $id)->delete();
        foreach (($v['resultats'] ?? []) as $r) {
            DB::connection($this->conn)->table('outil_piste_audit_resultats')->insert([
                'piste_id'    => $id,
                'critere'     => $r['critere'],
                'resultat'    => $r['resultat'] ?? null,
                'observation' => $r['observation'] ?? null,
                'created_at'  => now(),
                'updated_at'  => now(),
            ]);
        }

        return back()->with('success', 'Piste d\'audit mise à jour.');
    }

    public function soumettre(int $id)
    {
        $p = $this->findOrFail($id);
        abort_if($p->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_piste_audit')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Piste soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $p = $this->findOrFail($id);
        abort_if($p->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_piste_audit')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Piste validée.' : 'Piste rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_piste_audit')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_piste_audit_etapes')->where('piste_id', $id)->delete();
        DB::connection($this->conn)->table('outil_piste_audit_resultats')->where('piste_id', $id)->delete();
        DB::connection($this->conn)->table('outil_piste_audit')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.piste-audit.index')->with('success', 'Piste d\'audit supprimée.');
    }
}
