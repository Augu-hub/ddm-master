<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Inertia\Inertia;

/**
 * ════════════════════════════════════════════════════════════════
 * OUTIL VII — RÉFÉRENTIEL D'AUDIT
 * ════════════════════════════════════════════════════════════════
 *
 * Feuille IFACI : "VII-Référentiel d'Audit"
 * Colonnes      : Objectif du Processus | Risque Associé |
 *                 Contrôle Clé Existant | Type de Contrôle |
 *                 Composante COSO | Conception | À Tester |
 *                 Objectif d'Audit
 *
 * Table BD      : outil_referentiel_audit
 *
 * Données sources (pré-remplissage automatique) :
 *   mission_phase_ref_ci  → criteres JSON (lignes RCI)
 *   risks                 → label, control_procedure, owner
 *   processes             → name, code
 *   activities            → name
 *   risk_types            → label
 *   audit_matrix          → qualification, color
 *
 * Workflow : draft → in_review → validated / rejet → draft
 * Roles    : AJ/AS → soumettre | CM/DM → valider
 * ════════════════════════════════════════════════════════════════
 */
class OutilReferentielAuditController extends Controller
{
    protected string $table = 'outil_referentiel_audit';

    private function t() { return DB::connection('tenant'); }

    // ══════════════════════════════════════════════════════════════
    // INDEX
    // ══════════════════════════════════════════════════════════════
    public function index(Request $request)
    {
        $missionId    = (int) $request->query('mission_id',    0);
        $assignmentId = (int) $request->query('assignment_id', 0);

        return Inertia::render(
            'Auditor/Outils/OutilReferentielAudit',
            $this->buildPayload($missionId, $assignmentId, null)
        );
    }

    // ══════════════════════════════════════════════════════════════
    // EDIT
    // ══════════════════════════════════════════════════════════════
    public function edit(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        return Inertia::render(
            'Auditor/Outils/OutilReferentielAudit',
            $this->buildPayload(
                (int) $fiche->mission_id,
                (int) ($fiche->assignment_id ?? 0),
                $fiche
            )
        );
    }

    // ══════════════════════════════════════════════════════════════
    // buildPayload
    // ══════════════════════════════════════════════════════════════
    private function buildPayload(int $missionId, int $assignmentId, mixed $fiche): array
    {
        $missionRow    = $missionId
            ? $this->t()->table('mission_programmation')->where('id', $missionId)->first()
            : null;
        $realMissionId = $missionRow?->mission_id ?? $missionId;

        $auditor     = $this->getAuditor();
        $auditorRole = $this->getAuditorRole($missionId, $auditor?->id);
        $auditeurNom = $auditor
            ? trim(($auditor->last_name ?? '') . ' ' . ($auditor->first_name ?? ''))
            : (auth()->user()?->name ?? '');

        // Processus du tenant (pour le sélecteur)
        $processus = $this->chargerProcessus();

        // Lignes RCI pré-chargées depuis mission_phase_ref_ci
        $rciLignes = $this->chargerLignesRCI($missionId, $assignmentId);

        // Données de la fiche existante
        $formData = null;
        if ($fiche) {
            $formData = [
                'id'                      => $fiche->id,
                'code'                    => $fiche->code,
                'validation_status'       => $fiche->validation_status,
                'validation_note'         => $fiche->validation_note,
                'processus_id'            => $fiche->processus_id,
                'date'                    => $fiche->date,
                'cadre_ref'               => $fiche->cadre_ref ?? 'COSO',
                'lignes'                  => $this->decodeArr($fiche->lignes),
                'validation_diffuse_le'   => $fiche->validation_diffuse_le   ?? '',
                'validation_reunion_le'   => $fiche->validation_reunion_le   ?? '',
                'validation_date'         => $fiche->validation_date         ?? '',
                'validation_valide_par'   => $fiche->validation_valide_par   ?? '',
                'validation_commentaires' => $fiche->validation_commentaires ?? '',
            ];
        }

        $ficheId = $fiche?->id ?? null;

        return [
            'form'          => $formData,
            'mission'       => $missionRow ? (array) $missionRow : null,
            'auditorRole'   => $auditorRole,
            'auditeurNom'   => $auditeurNom,
            'missionId'     => $missionId,
            'assignmentId'  => $assignmentId ?: null,
            'missionContext'=> [
                'mission_id'      => $missionId,
                'assignment_id'   => $assignmentId,
                'mission_libelle' => $missionRow?->libelle      ?? '',
                'code_mission'    => $missionRow?->code_mission ?? '',
            ],
            'processus'     => $processus,
            'rciLignes'     => $rciLignes,
            'backUrl'       => $this->backUrl($missionId),
            'urlStore'      => route('auditor.outils.referentiel-audit.store'),
            'urlUpdate'     => $ficheId ? route('auditor.outils.referentiel-audit.update',    $ficheId) : null,
            'urlSoumettre'  => $ficheId ? route('auditor.outils.referentiel-audit.soumettre', $ficheId) : null,
            'urlValider'    => $ficheId ? route('auditor.outils.referentiel-audit.valider',   $ficheId) : null,
        ];
    }

    // ══════════════════════════════════════════════════════════════
    // chargerProcessus
    // Liste plates macros + processus pour le sélecteur Vue
    // ══════════════════════════════════════════════════════════════
    private function chargerProcessus(): array
    {
        $rows = $this->t()
            ->table('processes as p')
            ->join('macro_processes as mp', 'mp.id', '=', 'p.macro_process_id')
            ->select(
                'p.id', 'p.code', 'p.name', 'p.macro_process_id',
                'mp.id   as macro_id',
                'mp.name as macro_name',
                'mp.code as macro_code',
                'mp.kind as macro_kind'
            )
            ->orderBy('mp.kind')
            ->orderBy('p.code')
            ->get()
            ->toArray();

        // Construire macros uniques
        $macroMap = [];
        foreach ($rows as $p) {
            $p = (object) $p;
            if (!isset($macroMap[$p->macro_id])) {
                $macroMap[$p->macro_id] = [
                    'id'         => $p->macro_id,
                    'code'       => $p->macro_code,
                    'name'       => $p->macro_name,
                    'macro_kind' => $p->macro_kind,
                    'parent_id'  => null,
                    'level'      => 0,
                    'is_macro'   => true,
                ];
            }
        }

        $procs = collect($rows)->map(fn($p) => [
            'id'         => $p->id,
            'code'       => $p->code,
            'name'       => $p->name,
            'parent_id'  => $p->macro_process_id,
            'parent_name'=> $p->macro_name,
            'macro_kind' => $p->macro_kind,
            'level'      => 1,
            'is_macro'   => false,
        ])->toArray();

        return array_merge(array_values($macroMap), $procs);
    }

    // ══════════════════════════════════════════════════════════════
    // chargerLignesRCI
    //
    // Lit mission_phase_ref_ci.criteres (JSON) et mappe les colonnes
    // vers la structure exacte de la feuille VII IFACI :
    //   objectif_processus  ← objectif_operationnel / objectif_strategique
    //   risque_associe      ← risque_libelle
    //   controle_cle        ← description_controle
    //   type_controle       ← type_controle
    //   composante_coso     ← composante_coso (si disponible) ou 'Act.Ctrl'
    //   conception          ← '' (à remplir par l'auditeur)
    //   a_tester            ← 'Oui' par défaut
    //   objectif_audit      ← objectif_operationnel
    //   _from_rci           ← true
    //   _risque_code        ← risque_code
    //   _criticite          ← criticite_residuelle
    //   _responsable        ← responsable_controle
    //   _process_code       ← process_code
    // ══════════════════════════════════════════════════════════════
    private function chargerLignesRCI(int $missionId, int $assignmentId): array
    {
        try {
            // Chercher d'abord par assignment_id, puis par mission_id
            $rciForm = $this->t()
                ->table('mission_phase_ref_ci')
                ->when($assignmentId, fn($q) => $q->where('assignment_id', $assignmentId))
                ->when(!$assignmentId && $missionId, fn($q) => $q->where('mission_id', $missionId))
                ->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")
                ->orderByDesc('updated_at')
                ->first();

            if (!$rciForm && $missionId) {
                $rciForm = $this->t()
                    ->table('mission_phase_ref_ci')
                    ->where('mission_id', $missionId)
                    ->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")
                    ->orderByDesc('updated_at')
                    ->first();
            }

            if (!$rciForm) {
                Log::info("[VII] Aucun RCI trouvé pour mission={$missionId} assignment={$assignmentId}");
                return [];
            }

            $lignes = $this->decodeArr($rciForm->criteres ?? null);

            if (empty($lignes)) {
                Log::info("[VII] RCI trouvé id={$rciForm->id} mais criteres vides");
                return [];
            }

            $mapped = array_map(function (array $l): array {
                // Déterminer la composante COSO depuis le type de contrôle
                $type  = $l['type_controle'] ?? '';
                $coso  = $l['composante_coso'] ?? '';
                if (empty($coso)) {
                    $coso = match (true) {
                        str_contains(strtolower($type), 'prév')  => 'Act.Ctrl',
                        str_contains(strtolower($type), 'détect')=> 'Act.Ctrl',
                        str_contains(strtolower($type), 'correct')=> 'Act.Ctrl',
                        default                                   => 'Act.Ctrl',
                    };
                }

                return [
                    'objectif_processus' => $l['objectif_operationnel'] ?? $l['objectif_strategique'] ?? '',
                    'risque_associe'     => $l['risque_libelle']         ?? '',
                    'controle_cle'       => $l['description_controle']   ?? '',
                    'type_controle'      => $l['type_controle']          ?? '',
                    'composante_coso'    => $coso,
                    'conception'         => '',          // à évaluer par l'auditeur
                    'a_tester'           => 'Oui',
                    'objectif_audit'     => $l['objectif_operationnel']  ?? '',
                    '_from_rci'          => true,
                    '_risque_code'       => $l['risque_code']            ?? '',
                    '_criticite'         => (float) ($l['criticite_residuelle'] ?? 0),
                    '_responsable'       => $l['responsable_controle']   ?? '',
                    '_process_code'      => $l['process_code']           ?? '',
                ];
            }, $lignes);

            Log::info(sprintf('[VII] %d lignes RCI chargées (mission=%d assignment=%d)', count($mapped), $missionId, $assignmentId));

            return $mapped;

        } catch (\Exception $e) {
            Log::error('[VII] chargerLignesRCI: ' . $e->getMessage());
            return [];
        }
    }

    // ══════════════════════════════════════════════════════════════
    // STORE
    // ══════════════════════════════════════════════════════════════
    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'               => 'required|integer',
            'assignment_id'            => 'nullable|integer',
            'processus_id'             => 'nullable|integer',
            'date'                     => 'nullable|date',
            'cadre_ref'                => 'nullable|string|max:50',
            'lignes'                   => 'nullable|string',
            'validation_diffuse_le'    => 'nullable|date',
            'validation_reunion_le'    => 'nullable|date',
            'validation_date'          => 'nullable|date',
            'validation_valide_par'    => 'nullable|string|max:255',
            'validation_commentaires'  => 'nullable|string',
        ]);

        $mid   = $v['mission_id'];
        $count = $this->t()->table($this->table)->where('mission_id', $mid)->count();
        $code  = 'VII-' . str_pad($mid, 4, '0', STR_PAD_LEFT) . '-' . str_pad($count + 1, 3, '0', STR_PAD_LEFT);

        $id = $this->t()->table($this->table)->insertGetId([
            'code'                    => $code,
            'mission_id'              => $mid,
            'assignment_id'           => $v['assignment_id']           ?? null,
            'processus_id'            => $v['processus_id']            ?? null,
            'date'                    => $v['date']                    ?? null,
            'cadre_ref'               => $v['cadre_ref']               ?? 'COSO',
            'lignes'                  => $v['lignes']                  ?? '[]',
            'validation_diffuse_le'   => $v['validation_diffuse_le']   ?? null,
            'validation_reunion_le'   => $v['validation_reunion_le']   ?? null,
            'validation_date'         => $v['validation_date']         ?? null,
            'validation_valide_par'   => $v['validation_valide_par']   ?? null,
            'validation_commentaires' => $v['validation_commentaires'] ?? null,
            'validation_status'       => 'draft',
            'validation_note'         => null,
            'created_by'              => auth()->id(),
            'updated_by'              => auth()->id(),
            'created_at'              => now(),
            'updated_at'              => now(),
        ]);

        return response()->json([
            'success' => true,
            'form'    => ['id' => $id, 'code' => $code, 'validation_status' => 'draft'],
            'urlUpdate'    => route('auditor.outils.referentiel-audit.update',    $id),
            'urlSoumettre' => route('auditor.outils.referentiel-audit.soumettre', $id),
            'urlValider'   => route('auditor.outils.referentiel-audit.valider',   $id),
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    // UPDATE
    // ══════════════════════════════════════════════════════════════
    public function update(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        if ($fiche->validation_status === 'validated') {
            return response()->json(['success' => false, 'message' => 'Fiche validée — modification impossible.'], 422);
        }

        $v = $request->validate([
            'processus_id'             => 'nullable|integer',
            'date'                     => 'nullable|date',
            'cadre_ref'                => 'nullable|string|max:50',
            'lignes'                   => 'nullable|string',
            'validation_diffuse_le'    => 'nullable|date',
            'validation_reunion_le'    => 'nullable|date',
            'validation_date'          => 'nullable|date',
            'validation_valide_par'    => 'nullable|string|max:255',
            'validation_commentaires'  => 'nullable|string',
        ]);

        $this->t()->table($this->table)->where('id', $id)->update([
            'processus_id'            => $v['processus_id']            ?? $fiche->processus_id,
            'date'                    => $v['date']                    ?? $fiche->date,
            'cadre_ref'               => $v['cadre_ref']               ?? $fiche->cadre_ref,
            'lignes'                  => $v['lignes']                  ?? $fiche->lignes,
            'validation_diffuse_le'   => $v['validation_diffuse_le']   ?? $fiche->validation_diffuse_le,
            'validation_reunion_le'   => $v['validation_reunion_le']   ?? $fiche->validation_reunion_le,
            'validation_date'         => $v['validation_date']         ?? $fiche->validation_date,
            'validation_valide_par'   => $v['validation_valide_par']   ?? $fiche->validation_valide_par,
            'validation_commentaires' => $v['validation_commentaires'] ?? $fiche->validation_commentaires,
            'updated_by'              => auth()->id(),
            'updated_at'              => now(),
        ]);

        return response()->json([
            'success' => true,
            'form'    => [
                'id'                => $id,
                'code'              => $fiche->code,
                'validation_status' => $fiche->validation_status,
            ],
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    // SOUMETTRE  draft → in_review
    // ══════════════════════════════════════════════════════════════
    public function soumettre(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        if ($fiche->validation_status !== 'draft') {
            return response()->json(['success' => false, 'error' => 'Statut invalide.'], 422);
        }

        $this->t()->table($this->table)->where('id', $id)->update([
            'validation_status' => 'in_review',
            'updated_at'        => now(),
        ]);

        return response()->json(['success' => true, 'status' => 'in_review']);
    }

    // ══════════════════════════════════════════════════════════════
    // VALIDER  in_review → validated | reject → draft
    // ══════════════════════════════════════════════════════════════
    public function valider(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        if ($fiche->validation_status !== 'in_review') {
            return response()->json(['success' => false, 'error' => 'Non soumise.'], 422);
        }

        $action = $request->input('action');
        $note   = $request->input('note', '');

        if ($action === 'validate') {
            $this->t()->table($this->table)->where('id', $id)->update([
                'validation_status' => 'validated',
                'validation_note'   => null,
                'updated_at'        => now(),
            ]);
            return response()->json(['success' => true, 'status' => 'validated']);
        }

        if ($action === 'reject') {
            if (!$note) {
                return response()->json(['success' => false, 'error' => 'Motif obligatoire.'], 422);
            }
            $this->t()->table($this->table)->where('id', $id)->update([
                'validation_status' => 'draft',
                'validation_note'   => $note,
                'updated_at'        => now(),
            ]);
            return response()->json(['success' => true, 'status' => 'draft']);
        }

        return response()->json(['success' => false, 'error' => 'Action inconnue.'], 422);
    }

    // ══════════════════════════════════════════════════════════════
    // DESTROY
    // ══════════════════════════════════════════════════════════════

    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_referentiel_audit')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        if ($fiche->validation_status === 'validated') {
            return response()->json(['success' => false, 'message' => 'Fiche validée — suppression impossible.'], 422);
        }

        $this->t()->table($this->table)->where('id', $id)->delete();

        return response()->json(['success' => true]);
    }

    // ══════════════════════════════════════════════════════════════
    // SUGGESTIONS IA — POST /{id}/suggestions
    //
    // Génère des suggestions COSO 1 + pré-remplissage colonnes VII
    // à partir du contexte RCI (ligne sélectionnée ou toutes les lignes)
    // ══════════════════════════════════════════════════════════════
    public function suggestions(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        $ligneIndex = (int) $request->input('ligne_index', -1);  // -1 = toutes les lignes
        $lignes     = $this->decodeArr($fiche->lignes ?? null);

        // Sélectionner la ligne cible
        $ligneCible = ($ligneIndex >= 0 && isset($lignes[$ligneIndex]))
            ? $lignes[$ligneIndex]
            : ($lignes[0] ?? null);

        if (!$ligneCible) {
            return response()->json([
                'success'  => true,
                'message'  => 'Aucune ligne disponible pour générer des suggestions.',
                'lignes'   => [],
            ]);
        }

        // ── Enrichissement depuis la BD ───────────────────────────
        $contexte = $this->enrichirContexte($ligneCible, (int) $fiche->mission_id, (int) ($fiche->assignment_id ?? 0));

        // ── Suggestions COSO 1 ────────────────────────────────────
        $suggestionsCoso = $this->genererSuggestionsCoso($contexte);

        // ── Suggestions de remplissage des colonnes VII ───────────
        $suggestionsColonnes = $this->genererSuggestionsColonnes($contexte, $ligneIndex, $lignes);

        return response()->json([
            'success'              => true,
            'contexte'             => $contexte,
            'suggestions_coso'     => $suggestionsCoso,
            'suggestions_colonnes' => $suggestionsColonnes,
            'ligne_index'          => $ligneIndex,
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    // enrichirContexte — complète les données d'une ligne RCI
    // ══════════════════════════════════════════════════════════════
    private function enrichirContexte(array $ligne, int $missionId, int $assignmentId): array
    {
        $ctx = [
            'objectif_processus'  => $ligne['objectif_processus']  ?? '',
            'risque_libelle'      => $ligne['risque_associe']       ?? '',
            'risque_code'         => $ligne['_risque_code']         ?? '',
            'controle_cle'        => $ligne['controle_cle']         ?? '',
            'type_controle'       => $ligne['type_controle']        ?? '',
            'composante_coso'     => $ligne['composante_coso']      ?? '',
            'conception_actuelle' => $ligne['conception']           ?? '',
            'objectif_audit'      => $ligne['objectif_audit']       ?? '',
            'criticite'           => (float) ($ligne['_criticite']  ?? 0),
            'responsable'         => $ligne['_responsable']         ?? '',
            'process_code'        => $ligne['_process_code']        ?? '',
        ];

        // Enrichir depuis le RCI si les champs sont vides
        if (empty($ctx['objectif_processus']) || empty($ctx['risque_libelle'])) {
            try {
                $rciForm = $this->t()
                    ->table('mission_phase_ref_ci')
                    ->where(function ($q) use ($missionId, $assignmentId) {
                        if ($assignmentId) $q->where('assignment_id', $assignmentId);
                        else               $q->where('mission_id', $missionId);
                    })
                    ->orderByRaw("FIELD(validation_status,'validated','in_review','draft')")
                    ->orderByDesc('updated_at')
                    ->first();

                if ($rciForm) {
                    $rciLignes = $this->decodeArr($rciForm->criteres ?? null);
                    $match = collect($rciLignes)->first(fn($l) =>
                        ($l['risque_code'] ?? '') === $ctx['risque_code']
                    );
                    if ($match) {
                        $ctx['objectif_processus'] = $ctx['objectif_processus'] ?: ($match['objectif_operationnel'] ?? '');
                        $ctx['controle_cle']        = $ctx['controle_cle']       ?: ($match['description_controle']  ?? '');
                        $ctx['responsable']         = $ctx['responsable']         ?: ($match['responsable_controle']  ?? '');
                    }
                }
            } catch (\Exception $e) {
                Log::warning('[VII-IA] enrichirContexte: ' . $e->getMessage());
            }
        }

        return $ctx;
    }

    // ══════════════════════════════════════════════════════════════
    // genererSuggestionsCoso — Questions QCI COSO 1 avec réponses
    // ══════════════════════════════════════════════════════════════
    private function genererSuggestionsCoso(array $ctx): array
    {
        $composante = $ctx['composante_coso'] ?? 'Act.Ctrl';
        $type       = strtolower($ctx['type_controle']  ?? '');
        $ctrl       = strtolower($ctx['controle_cle']   ?? '');
        $crit       = (float) ($ctx['criticite']        ?? 0);
        $resp       = $ctx['responsable']               ?? '';

        // Questions QCI issues de la feuille IX-QCI IFACI
        $questionsParComposante = [
            'Env.Ctrl' => [
                ['num' => '1.1', 'question' => "La direction a-t-elle exprimé clairement ses exigences en matière d'intégrité et d'éthique ?"],
                ['num' => '1.2', 'question' => "Le code de conduite / d'éthique a-t-il été formalisé et diffusé ?"],
                ['num' => '1.3', 'question' => "Les compétences du personnel sont-elles à la mesure de leurs responsabilités ?"],
                ['num' => '1.4', 'question' => "Le style de management est-il adapté (planification, organisation, supervision) ?"],
                ['num' => '1.5', 'question' => "La structure organisationnelle est-elle clairement définie ?"],
            ],
            'Eval.Risq' => [
                ['num' => '2.1', 'question' => "Les objectifs du processus sont-ils définis et formalisés ?"],
                ['num' => '2.2', 'question' => "Les risques internes et externes ont-ils été identifiés et évalués ?"],
                ['num' => '2.3', 'question' => "Un mécanisme de mise à jour de la cartographie des risques existe-t-il ?"],
                ['num' => '2.4', 'question' => "Les politiques sont-elles mises à jour suite à l'évolution des risques ?"],
            ],
            'Act.Ctrl' => [
                ['num' => '3.1', 'question' => "Existe-t-il des procédures écrites qui définissent les modalités opératoires ?"],
                ['num' => '3.2', 'question' => "Les procédures sont-elles connues, à jour et appliquées ?"],
                ['num' => '3.3', 'question' => "L'attribution des autorisations est-elle satisfaisante ?"],
                ['num' => '3.4', 'question' => "Les tâches incompatibles sont-elles séparées (séparation des fonctions) ?"],
                ['num' => '3.5', 'question' => "Les opérations font-elles l'objet d'une supervision adéquate ?"],
                ['num' => '3.6', 'question' => "Est-il impossible de réaliser des opérations non autorisées ?"],
                ['num' => '3.7', 'question' => "Les vérifications d'existence, d'exactitude et de délai sont-elles effectuées ?"],
                ['num' => '3.8', 'question' => "Les opérations réalisées sont-elles formalisées (traçabilité) ?"],
                ['num' => '3.9', 'question' => "Les pièces justificatives sont-elles conservées et protégées ?"],
            ],
            'Info.Com' => [
                ['num' => '4.1', 'question' => "Les circuits de circulation des informations sont-ils clairement identifiés ?"],
                ['num' => '4.2', 'question' => "Le personnel dispose-t-il des informations nécessaires à son activité ?"],
                ['num' => '4.3', 'question' => "Les informations produites sont-elles transmises aux parties prenantes ?"],
                ['num' => '4.4', 'question' => "Les systèmes d'information produisent-ils des données fiables et pertinentes ?"],
            ],
            'Pilotage' => [
                ['num' => '5.1', 'question' => "Existe-t-il des procédures de suivi et d'évaluation du contrôle interne ?"],
                ['num' => '5.2', 'question' => "Les faiblesses identifiées font-elles l'objet d'une formalisation et d'un suivi ?"],
                ['num' => '5.3', 'question' => "Les corrections apportées au contrôle interne sont-elles suivies ?"],
                ['num' => '5.4', 'question' => "Des indicateurs de performance sont-ils définis et suivis régulièrement ?"],
            ],
        ];

        // Mapper le code composante vers la clé des questions
        $cleComposante = match ($composante) {
            'Env.Ctrl'  => 'Env.Ctrl',
            'Eval.Risq' => 'Eval.Risq',
            'Info.Com'  => 'Info.Com',
            'Pilotage'  => 'Pilotage',
            default     => 'Act.Ctrl',
        };

        $questions = $questionsParComposante[$cleComposante] ?? $questionsParComposante['Act.Ctrl'];

        // Enrichir chaque question avec une réponse suggérée
        $questionsEnrichies = array_map(function (array $q) use ($ctrl, $resp, $crit): array {
            $qMin = strtolower($q['question']);
            $statut = '';
            $commentaire = '';
            $priorite = 'normale';

            if (str_contains($qMin, 'procédure') || str_contains($qMin, 'formalité')) {
                $statut = !empty($ctrl) ? 'oui' : 'non';
                $commentaire = !empty($ctrl)
                    ? "Procédure identifiée : vérifier l'effectivité lors des travaux de terrain."
                    : "Aucune procédure décrite — point à approfondir.";
                if ($statut === 'non') $priorite = $crit >= 7 ? 'haute' : 'normale';
            } elseif (str_contains($qMin, 'responsable') || str_contains($qMin, 'autorisation')) {
                $statut = !empty($resp) ? 'oui' : 'non';
                $commentaire = !empty($resp)
                    ? "Responsable identifié : {$resp}"
                    : "Responsable non identifié — à documenter.";
                if ($statut === 'non') $priorite = 'haute';
            } elseif (str_contains($qMin, 'risque') || str_contains($qMin, 'identif')) {
                $statut = 'oui';
                $commentaire = "Risque documenté dans la cartographie (code : " . ($q['num'] ?? '') . ").";
            } elseif (str_contains($qMin, 'objectif') || str_contains($qMin, 'défini')) {
                $statut = 'oui';
                $commentaire = "Objectif défini dans le référentiel.";
            } else {
                $statut = '';
                $commentaire = "À vérifier lors des travaux de terrain.";
            }

            return array_merge($q, [
                'reponse_suggeree' => $statut,
                'commentaire_ia'   => $commentaire,
                'priorite'         => $priorite,
            ]);
        }, $questions);

        return [
            'composante'       => $composante,
            'questions'        => $questionsEnrichies,
            'nb_non'           => count(array_filter($questionsEnrichies, fn($q) => $q['reponse_suggeree'] === 'non')),
            'nb_a_verifier'    => count(array_filter($questionsEnrichies, fn($q) => empty($q['reponse_suggeree']))),
        ];
    }

    // ══════════════════════════════════════════════════════════════
    // genererSuggestionsColonnes
    // Suggestions pour remplir/améliorer les colonnes VII manquantes
    // ══════════════════════════════════════════════════════════════
    private function genererSuggestionsColonnes(array $ctx, int $ligneIndex, array $lignes): array
    {
        $suggestions = [];

        // Conception : suggérer selon criticité + présence de contrôle
        $conception = '';
        $raisonConception = '';

        if (empty($ctx['controle_cle'])) {
            $conception = 'Absente';
            $raisonConception = "Aucun contrôle décrit dans le RCI pour ce risque.";
        } elseif ($ctx['criticite'] >= 7) {
            $conception = 'Inadaptée';
            $raisonConception = "Criticité élevée ({$ctx['criticite']}) — le contrôle existant semble insuffisant.";
        } elseif ($ctx['criticite'] >= 4) {
            $conception = 'Inadaptée';
            $raisonConception = "Criticité modérée ({$ctx['criticite']}) — à évaluer sur le terrain.";
        } else {
            $conception = 'Adaptée';
            $raisonConception = "Criticité faible et contrôle documenté — présumé adapté sous réserve de vérification.";
        }

        $suggestions['conception'] = [
            'valeur_suggeree' => $conception,
            'raison'          => $raisonConception,
            'priorite'        => $ctx['criticite'] >= 7 ? 'haute' : 'normale',
        ];

        // Objectif d'audit : reformuler depuis l'objectif processus
        if (empty($ctx['objectif_audit']) && !empty($ctx['objectif_processus'])) {
            $suggestions['objectif_audit'] = [
                'valeur_suggeree' => "Vérifier que : " . $ctx['objectif_processus'],
                'raison'          => "Objectif d'audit reformulé depuis l'objectif du processus.",
                'priorite'        => 'normale',
            ];
        }

        // Composante COSO : suggérer selon type de contrôle
        if (empty($ctx['composante_coso'])) {
            $type = strtolower($ctx['type_controle'] ?? '');
            $cosoSuggeree = match (true) {
                str_contains($type, 'prév')   => 'Act.Ctrl',
                str_contains($type, 'détect') => 'Act.Ctrl',
                str_contains($type, 'pilot')  => 'Pilotage',
                str_contains($type, 'info')   => 'Info.Com',
                default                        => 'Act.Ctrl',
            };
            $suggestions['composante_coso'] = [
                'valeur_suggeree' => $cosoSuggeree,
                'raison'          => "Déduite du type de contrôle : {$ctx['type_controle']}.",
                'priorite'        => 'normale',
            ];
        }

        // À tester : forcer Oui si criticité élevée
        if ($ctx['criticite'] >= 7) {
            $suggestions['a_tester'] = [
                'valeur_suggeree' => 'Oui',
                'raison'          => "Criticité forte ({$ctx['criticite']}) — test obligatoire.",
                'priorite'        => 'haute',
            ];
        }

        return $suggestions;
    }

    // ══════════════════════════════════════════════════════════════
    // APPLY SUGGESTIONS — POST /{id}/apply-suggestions
    // Applique les suggestions IA sur les lignes du référentiel
    // ══════════════════════════════════════════════════════════════
    public function applySuggestions(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);

        if ($fiche->validation_status === 'validated') {
            return response()->json(['success' => false, 'message' => 'Fiche validée.'], 422);
        }

        $ligneIndex   = (int)    $request->input('ligne_index',   -1);
        $colonnes     = (array)  $request->input('colonnes',      []);
        $appliquerTout= (bool)   $request->input('appliquer_tout', false);

        $lignes = $this->decodeArr($fiche->lignes ?? null);

        if (empty($lignes)) {
            return response()->json(['success' => false, 'message' => 'Aucune ligne.'], 422);
        }

        $indices = $appliquerTout
            ? range(0, count($lignes) - 1)
            : [$ligneIndex];

        foreach ($indices as $idx) {
            if (!isset($lignes[$idx])) continue;
            foreach ($colonnes as $colonne => $valeur) {
                if (in_array($colonne, ['conception', 'composante_coso', 'a_tester', 'objectif_audit', 'type_controle'])) {
                    // Ne pas écraser si déjà rempli (sauf si force)
                    if (empty($lignes[$idx][$colonne]) || $request->boolean('force_overwrite')) {
                        $lignes[$idx][$colonne] = $valeur;
                    }
                }
            }
        }

        $this->t()->table($this->table)->where('id', $id)->update([
            'lignes'     => json_encode($lignes, JSON_UNESCAPED_UNICODE),
            'updated_by' => auth()->id(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'lignes'  => $lignes,
            'message' => count($indices) > 1
                ? count($indices) . ' lignes mises à jour.'
                : 'Ligne mise à jour.',
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════════
    private function getAuditor(): ?object
    {
        try {
            $user = auth()->user();
            if (!$user) return null;
            $col = DB::connection('tenant')->getSchemaBuilder()->hasColumn('auditors', 'user_id')
                ? 'user_id' : 'id';
            return $this->t()->table('auditors')->where($col, $user->id)->first();
        } catch (\Exception $e) {
            return null;
        }
    }

    private function getAuditorRole(int $missionId, ?int $auditorId): string
    {
        if (!$auditorId || !$missionId) return 'AJ';
        try {
            $row = $this->t()
                ->table('mission_phase_assignment_auditeurs as mpaa')
                ->join('mission_phase_assignments as mpa', 'mpa.id', '=', 'mpaa.assignment_id')
                ->where('mpa.mission_programmation_id', $missionId)
                ->where('mpaa.auditeur_id', $auditorId)
                ->select('mpaa.role_code')
                ->orderByRaw("FIELD(mpaa.role_code,'DM','CM','AS','AJ')")
                ->first();
            return $row?->role_code ?? 'AJ';
        } catch (\Exception $e) {
            return 'AJ';
        }
    }

    private function decodeArr(mixed $v): array
    {
        if (is_array($v)) return $v;
        if (!$v) return [];
        $d = json_decode($v, true);
        return is_array($d) ? $d : [];
    }

    private function backUrl(?int $missionId): string
    {
        if (!$missionId) return '/';
        try {
            return route('auditor.ac.fiche-test.index', ['mission_id' => $missionId]);
        } catch (\Exception $e) {
            return url("/m/audit.core/auditor/missions/{$missionId}/phases");
        }
    }
}