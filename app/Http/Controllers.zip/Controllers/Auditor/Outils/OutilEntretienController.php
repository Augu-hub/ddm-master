<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class OutilEntretienController extends Controller
{
    private string $conn = 'tenant';

    // ── Helpers ─────────────────────────────────────────────────────

    private function mission(int $missionId): object|null
    {
        return DB::connection($this->conn)
            ->table('missions')
            ->where('id', $missionId)
            ->first();
    }

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)
            ->table('outil_entretiens')
            ->where('id', $id)
            ->first();

        abort_if(!$record, 404, 'Grille d\'entretien introuvable.');
        return $record;
    }

    // ── Index ────────────────────────────────────────────────────────

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_entretiens as oe')
            ->leftJoin('missions as m', 'm.id', '=', 'oe.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oe.created_by')
            ->select(
                'oe.*',
                'm.reference as mission_ref',
                'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur")
            )
            ->orderByDesc('oe.created_at');

        if ($missionId) {
            $query->where('oe.mission_id', $missionId);
        }

        $entretiens = $query->paginate(15)->withQueryString();

        $missions = DB::connection($this->conn)
            ->table('missions')
            ->select('id', 'reference', 'libelle')
            ->orderBy('reference')
            ->get();

        return Inertia::render('Auditor/Outils/Entretien/Index', [
            'entretiens' => $entretiens,
            'missions'   => $missions,
            'filters'    => ['mission_id' => $missionId],
        ]);
    }

    // ── Edit ─────────────────────────────────────────────────────────

    public function edit(int $id)
    {
        $entretien = $this->findOrFail($id);

        $questions = DB::connection($this->conn)
            ->table('outil_entretien_questions')
            ->where('entretien_id', $id)
            ->orderBy('ordre')
            ->get();

        $missions = DB::connection($this->conn)
            ->table('missions')
            ->select('id', 'reference', 'libelle')
            ->orderBy('reference')
            ->get();

        return Inertia::render('Auditor/Outils/Entretien/Edit', [
            'entretien' => $entretien,
            'questions' => $questions,
            'missions'  => $missions,
        ]);
    }

    // ── Store ────────────────────────────────────────────────────────

    public function store(Request $request)
    {
        $validated = $request->validate([
            'mission_id'       => 'required|integer',
            'intitule'         => 'required|string|max:255',
            'objectif'         => 'nullable|string',
            'interlocuteur'    => 'nullable|string|max:255',
            'fonction'         => 'nullable|string|max:255',
            'date_entretien'   => 'nullable|date',
            'lieu'             => 'nullable|string|max:255',
            'questions'        => 'nullable|array',
            'questions.*.libelle'  => 'required|string',
            'questions.*.reponse'  => 'nullable|string',
            'questions.*.ordre'    => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_entretiens')->insertGetId([
            'mission_id'     => $validated['mission_id'],
            'intitule'       => $validated['intitule'],
            'objectif'       => $validated['objectif'] ?? null,
            'interlocuteur'  => $validated['interlocuteur'] ?? null,
            'fonction'       => $validated['fonction'] ?? null,
            'date_entretien' => $validated['date_entretien'] ?? null,
            'lieu'           => $validated['lieu'] ?? null,
            'statut'         => 'draft',
            'created_by'     => Auth::id(),
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        if (!empty($validated['questions'])) {
            foreach ($validated['questions'] as $idx => $q) {
                DB::connection($this->conn)->table('outil_entretien_questions')->insert([
                    'entretien_id' => $id,
                    'libelle'      => $q['libelle'],
                    'reponse'      => $q['reponse'] ?? null,
                    'ordre'        => $q['ordre'] ?? ($idx + 1),
                    'created_at'   => now(),
                    'updated_at'   => now(),
                ]);
            }
        }

        return redirect()->route('auditor.ac.outil-entretien.edit', $id)
            ->with('success', 'Grille d\'entretien créée.');
    }

    // ── Update ───────────────────────────────────────────────────────

    public function update(Request $request, int $id)
    {
        $entretien = $this->findOrFail($id);
        abort_if($entretien->statut === 'validated', 403, 'Document validé, modification impossible.');

        $validated = $request->validate([
            'intitule'         => 'required|string|max:255',
            'objectif'         => 'nullable|string',
            'interlocuteur'    => 'nullable|string|max:255',
            'fonction'         => 'nullable|string|max:255',
            'date_entretien'   => 'nullable|date',
            'lieu'             => 'nullable|string|max:255',
            'questions'        => 'nullable|array',
            'questions.*.id'       => 'nullable|integer',
            'questions.*.libelle'  => 'required|string',
            'questions.*.reponse'  => 'nullable|string',
            'questions.*.ordre'    => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_entretiens')->where('id', $id)->update([
            'intitule'       => $validated['intitule'],
            'objectif'       => $validated['objectif'] ?? null,
            'interlocuteur'  => $validated['interlocuteur'] ?? null,
            'fonction'       => $validated['fonction'] ?? null,
            'date_entretien' => $validated['date_entretien'] ?? null,
            'lieu'           => $validated['lieu'] ?? null,
            'updated_at'     => now(),
        ]);

        // Sync questions : delete old, re-insert
        DB::connection($this->conn)->table('outil_entretien_questions')->where('entretien_id', $id)->delete();
        if (!empty($validated['questions'])) {
            foreach ($validated['questions'] as $idx => $q) {
                DB::connection($this->conn)->table('outil_entretien_questions')->insert([
                    'entretien_id' => $id,
                    'libelle'      => $q['libelle'],
                    'reponse'      => $q['reponse'] ?? null,
                    'ordre'        => $q['ordre'] ?? ($idx + 1),
                    'created_at'   => now(),
                    'updated_at'   => now(),
                ]);
            }
        }

        return back()->with('success', 'Grille d\'entretien mise à jour.');
    }

    // ── Soumettre ────────────────────────────────────────────────────

    public function soumettre(int $id)
    {
        $entretien = $this->findOrFail($id);
        abort_if($entretien->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');

        DB::connection($this->conn)->table('outil_entretiens')->where('id', $id)->update([
            'statut'     => 'in_review',
            'updated_at' => now(),
        ]);

        return back()->with('success', 'Grille soumise pour validation.');
    }

    // ── Valider ──────────────────────────────────────────────────────

    public function valider(Request $request, int $id)
    {
        $entretien = $this->findOrFail($id);
        abort_if($entretien->statut !== 'in_review', 422, 'Document non soumis.');

        $validated = $request->validate([
            'decision'  => 'required|in:validated,rejected',
            'commentaire' => 'nullable|string',
        ]);

        DB::connection($this->conn)->table('outil_entretiens')->where('id', $id)->update([
            'statut'               => $validated['decision'],
            'commentaire_validation' => $validated['commentaire'] ?? null,
            'validated_by'         => Auth::id(),
            'validated_at'         => now(),
            'updated_at'           => now(),
        ]);

        $msg = $validated['decision'] === 'validated' ? 'Grille validée.' : 'Grille rejetée.';
        return back()->with('success', $msg);
    }

    // ── Destroy ──────────────────────────────────────────────────────


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_entretiens')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_entretien_questions')->where('entretien_id', $id)->delete();
        DB::connection($this->conn)->table('outil_entretiens')->where('id', $id)->delete();

        return redirect()->route('auditor.ac.outil-entretien.index')
            ->with('success', 'Grille d\'entretien supprimée.');
    }
}
