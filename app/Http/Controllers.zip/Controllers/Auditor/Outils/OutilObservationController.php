<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil XIV — Fiche d'Observation Directe
 *
 * Structure réelle (feuille XIV) :
 *  - En-tête          : mission, date, heure (début-fin), auditeur, localisation,
 *                        interlocuteurs présents
 *  - Préparation      : objectif d'audit visé, tâche/local à observer,
 *                        éléments à vérifier, pièces attendues
 *  - Constats         : N°, élément observé, conforme au référentiel (oui/non/partiel),
 *                        écart constaté, risque associé, preuve (photo/doc/note)
 *  - Points forts observés (texte libre)
 *  - Points faibles / dysfonctionnements observés (texte libre)
 *  - Conclusion et suites à donner
 *
 * Tables :
 *   outil_observation          → en-tête + préparation + synthèse
 *   outil_observation_constats → lignes de constats terrain
 */
class OutilObservationController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_observation')->where('id', $id)->first();
        abort_if(!$record, 404, 'Fiche d\'observation introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_observation as oo')
            ->leftJoin('missions as m', 'm.id', '=', 'oo.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oo.created_by')
            ->select('oo.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oo.created_at');

        if ($missionId) $query->where('oo.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/Observation/Index', [
            'observations' => $query->paginate(15)->withQueryString(),
            'missions'     => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'      => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $observation = $this->findOrFail($id);
        $constats    = DB::connection($this->conn)->table('outil_observation_constats')
            ->where('observation_id', $id)->orderBy('ordre')->get();

        return Inertia::render('Auditor/Outils/Observation/Edit', [
            'observation' => $observation,
            'constats'    => $constats,
            'missions'    => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'              => 'required|integer',
            'date_observation'        => 'nullable|date',
            'heure_debut'             => 'nullable|string|max:10',
            'heure_fin'               => 'nullable|string|max:10',
            'auditeur'                => 'nullable|string|max:255',
            'localisation'            => 'nullable|string|max:255',
            'interlocuteurs_presents' => 'nullable|string',
            // Préparation
            'objectif_audit'          => 'nullable|string',
            'tache_local_observer'    => 'nullable|string',
            'elements_verifier'       => 'nullable|string',
            'pieces_attendues'        => 'nullable|string',
            // Synthèse
            'points_forts'            => 'nullable|string',
            'points_faibles'          => 'nullable|string',
            'conclusion'              => 'nullable|string',
            // Constats
            'constats'                               => 'nullable|array',
            'constats.*.element_observe'             => 'required|string',
            'constats.*.conforme_referentiel'        => 'nullable|in:oui,non,partiel',
            'constats.*.ecart_constate'              => 'nullable|string',
            'constats.*.risque_associe'              => 'nullable|string',
            'constats.*.preuve'                      => 'nullable|string|max:255',
            'constats.*.ordre'                       => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_observation')->insertGetId([
            'mission_id'              => $v['mission_id'],
            'date_observation'        => $v['date_observation'] ?? null,
            'heure_debut'             => $v['heure_debut'] ?? null,
            'heure_fin'               => $v['heure_fin'] ?? null,
            'auditeur'                => $v['auditeur'] ?? null,
            'localisation'            => $v['localisation'] ?? null,
            'interlocuteurs_presents' => $v['interlocuteurs_presents'] ?? null,
            'objectif_audit'          => $v['objectif_audit'] ?? null,
            'tache_local_observer'    => $v['tache_local_observer'] ?? null,
            'elements_verifier'       => $v['elements_verifier'] ?? null,
            'pieces_attendues'        => $v['pieces_attendues'] ?? null,
            'points_forts'            => $v['points_forts'] ?? null,
            'points_faibles'          => $v['points_faibles'] ?? null,
            'conclusion'              => $v['conclusion'] ?? null,
            'statut'                  => 'draft',
            'created_by'              => Auth::id(),
            'created_at'              => now(),
            'updated_at'              => now(),
        ]);

        foreach (($v['constats'] ?? []) as $idx => $c) {
            DB::connection($this->conn)->table('outil_observation_constats')->insert([
                'observation_id'       => $id,
                'element_observe'      => $c['element_observe'],
                'conforme_referentiel' => $c['conforme_referentiel'] ?? null,
                'ecart_constate'       => $c['ecart_constate'] ?? null,
                'risque_associe'       => $c['risque_associe'] ?? null,
                'preuve'               => $c['preuve'] ?? null,
                'ordre'                => $c['ordre'] ?? ($idx + 1),
                'created_at'           => now(),
                'updated_at'           => now(),
            ]);
        }

        return redirect()->route('auditor.outils.observation.edit', $id)
            ->with('success', 'Fiche d\'observation créée.');
    }

    public function update(Request $request, int $id)
    {
        $obs = $this->findOrFail($id);
        abort_if($obs->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'date_observation'               => 'nullable|date',
            'heure_debut'                    => 'nullable|string|max:10',
            'heure_fin'                      => 'nullable|string|max:10',
            'auditeur'                       => 'nullable|string|max:255',
            'localisation'                   => 'nullable|string|max:255',
            'interlocuteurs_presents'        => 'nullable|string',
            'objectif_audit'                 => 'nullable|string',
            'tache_local_observer'           => 'nullable|string',
            'elements_verifier'              => 'nullable|string',
            'pieces_attendues'               => 'nullable|string',
            'points_forts'                   => 'nullable|string',
            'points_faibles'                 => 'nullable|string',
            'conclusion'                     => 'nullable|string',
            'constats'                       => 'nullable|array',
            'constats.*.element_observe'     => 'required|string',
            'constats.*.conforme_referentiel'=> 'nullable|in:oui,non,partiel',
            'constats.*.ecart_constate'      => 'nullable|string',
            'constats.*.risque_associe'      => 'nullable|string',
            'constats.*.preuve'              => 'nullable|string|max:255',
            'constats.*.ordre'               => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_observation')->where('id', $id)->update([
            'date_observation'        => $v['date_observation'] ?? null,
            'heure_debut'             => $v['heure_debut'] ?? null,
            'heure_fin'               => $v['heure_fin'] ?? null,
            'auditeur'                => $v['auditeur'] ?? null,
            'localisation'            => $v['localisation'] ?? null,
            'interlocuteurs_presents' => $v['interlocuteurs_presents'] ?? null,
            'objectif_audit'          => $v['objectif_audit'] ?? null,
            'tache_local_observer'    => $v['tache_local_observer'] ?? null,
            'elements_verifier'       => $v['elements_verifier'] ?? null,
            'pieces_attendues'        => $v['pieces_attendues'] ?? null,
            'points_forts'            => $v['points_forts'] ?? null,
            'points_faibles'          => $v['points_faibles'] ?? null,
            'conclusion'              => $v['conclusion'] ?? null,
            'updated_at'              => now(),
        ]);

        DB::connection($this->conn)->table('outil_observation_constats')->where('observation_id', $id)->delete();
        foreach (($v['constats'] ?? []) as $idx => $c) {
            DB::connection($this->conn)->table('outil_observation_constats')->insert([
                'observation_id'       => $id,
                'element_observe'      => $c['element_observe'],
                'conforme_referentiel' => $c['conforme_referentiel'] ?? null,
                'ecart_constate'       => $c['ecart_constate'] ?? null,
                'risque_associe'       => $c['risque_associe'] ?? null,
                'preuve'               => $c['preuve'] ?? null,
                'ordre'                => $c['ordre'] ?? ($idx + 1),
                'created_at'           => now(),
                'updated_at'           => now(),
            ]);
        }

        return back()->with('success', 'Fiche d\'observation mise à jour.');
    }

    public function soumettre(int $id)
    {
        $o = $this->findOrFail($id);
        abort_if($o->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_observation')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Fiche soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $o = $this->findOrFail($id);
        abort_if($o->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_observation')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Fiche validée.' : 'Fiche rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_observation')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_observation_constats')->where('observation_id', $id)->delete();
        DB::connection($this->conn)->table('outil_observation')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.observation.index')->with('success', 'Fiche d\'observation supprimée.');
    }
}
