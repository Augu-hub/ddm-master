<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil IX — Questionnaire de Contrôle Interne (QCI)
 * Évalue l'existence et l'efficacité des contrôles internes par thème/section.
 */
class OutilQCIController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_qci')->where('id', $id)->first();
        abort_if(!$record, 404, 'QCI introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_qci as oq')
            ->leftJoin('missions as m', 'm.id', '=', 'oq.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oq.created_by')
            ->select('oq.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oq.created_at');

        if ($missionId) $query->where('oq.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/QCI/Index', [
            'questionnaires' => $query->paginate(15)->withQueryString(),
            'missions'       => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'        => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $qci = $this->findOrFail($id);

        $sections = DB::connection($this->conn)->table('outil_qci_sections')
            ->where('qci_id', $id)->orderBy('ordre')->get();

        $questions = DB::connection($this->conn)->table('outil_qci_questions')
            ->whereIn('section_id', $sections->pluck('id'))
            ->orderBy('section_id')->orderBy('ordre')->get();

        return Inertia::render('Auditor/Outils/QCI/Edit', [
            'qci'       => $qci,
            'sections'  => $sections,
            'questions' => $questions,
            'missions'  => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'   => 'required|integer',
            'intitule'     => 'required|string|max:255',
            'perimetre'    => 'nullable|string',
            'date_qci'     => 'nullable|date',
            'sections'     => 'nullable|array',
            'sections.*.libelle' => 'required|string',
            'sections.*.ordre'   => 'nullable|integer',
            'sections.*.questions' => 'nullable|array',
            'sections.*.questions.*.libelle'  => 'required|string',
            'sections.*.questions.*.reponse'  => 'nullable|in:oui,non,partiel,na',
            'sections.*.questions.*.commentaire' => 'nullable|string',
            'sections.*.questions.*.ordre'    => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_qci')->insertGetId([
            'mission_id' => $v['mission_id'],
            'intitule'   => $v['intitule'],
            'perimetre'  => $v['perimetre'] ?? null,
            'date_qci'   => $v['date_qci'] ?? null,
            'statut'     => 'draft',
            'created_by' => Auth::id(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        foreach (($v['sections'] ?? []) as $sIdx => $s) {
            $sectionId = DB::connection($this->conn)->table('outil_qci_sections')->insertGetId([
                'qci_id'     => $id,
                'libelle'    => $s['libelle'],
                'ordre'      => $s['ordre'] ?? ($sIdx + 1),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            foreach (($s['questions'] ?? []) as $qIdx => $q) {
                DB::connection($this->conn)->table('outil_qci_questions')->insert([
                    'section_id'  => $sectionId,
                    'libelle'     => $q['libelle'],
                    'reponse'     => $q['reponse'] ?? null,
                    'commentaire' => $q['commentaire'] ?? null,
                    'ordre'       => $q['ordre'] ?? ($qIdx + 1),
                    'created_at'  => now(),
                    'updated_at'  => now(),
                ]);
            }
        }

        return redirect()->route('auditor.outils.qci.edit', $id)
            ->with('success', 'QCI créé.');
    }

    public function update(Request $request, int $id)
    {
        $qci = $this->findOrFail($id);
        abort_if($qci->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'  => 'required|string|max:255',
            'perimetre' => 'nullable|string',
            'date_qci'  => 'nullable|date',
            'sections'  => 'nullable|array',
            'sections.*.libelle' => 'required|string',
            'sections.*.ordre'   => 'nullable|integer',
            'sections.*.questions' => 'nullable|array',
            'sections.*.questions.*.libelle'     => 'required|string',
            'sections.*.questions.*.reponse'     => 'nullable|in:oui,non,partiel,na',
            'sections.*.questions.*.commentaire' => 'nullable|string',
            'sections.*.questions.*.ordre'       => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_qci')->where('id', $id)->update([
            'intitule'   => $v['intitule'],
            'perimetre'  => $v['perimetre'] ?? null,
            'date_qci'   => $v['date_qci'] ?? null,
            'updated_at' => now(),
        ]);

        // Supprimer anciennes sections + questions (cascade)
        $oldSections = DB::connection($this->conn)->table('outil_qci_sections')->where('qci_id', $id)->pluck('id');
        DB::connection($this->conn)->table('outil_qci_questions')->whereIn('section_id', $oldSections)->delete();
        DB::connection($this->conn)->table('outil_qci_sections')->where('qci_id', $id)->delete();

        foreach (($v['sections'] ?? []) as $sIdx => $s) {
            $sectionId = DB::connection($this->conn)->table('outil_qci_sections')->insertGetId([
                'qci_id'     => $id,
                'libelle'    => $s['libelle'],
                'ordre'      => $s['ordre'] ?? ($sIdx + 1),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            foreach (($s['questions'] ?? []) as $qIdx => $q) {
                DB::connection($this->conn)->table('outil_qci_questions')->insert([
                    'section_id'  => $sectionId,
                    'libelle'     => $q['libelle'],
                    'reponse'     => $q['reponse'] ?? null,
                    'commentaire' => $q['commentaire'] ?? null,
                    'ordre'       => $q['ordre'] ?? ($qIdx + 1),
                    'created_at'  => now(),
                    'updated_at'  => now(),
                ]);
            }
        }

        return back()->with('success', 'QCI mis à jour.');
    }

    public function soumettre(int $id)
    {
        $q = $this->findOrFail($id);
        abort_if($q->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_qci')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'QCI soumis pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $q = $this->findOrFail($id);
        abort_if($q->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_qci')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'QCI validé.' : 'QCI rejeté.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_qci')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        $sections = DB::connection($this->conn)->table('outil_qci_sections')->where('qci_id', $id)->pluck('id');
        DB::connection($this->conn)->table('outil_qci_questions')->whereIn('section_id', $sections)->delete();
        DB::connection($this->conn)->table('outil_qci_sections')->where('qci_id', $id)->delete();
        DB::connection($this->conn)->table('outil_qci')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.qci.index')->with('success', 'QCI supprimé.');
    }
}
