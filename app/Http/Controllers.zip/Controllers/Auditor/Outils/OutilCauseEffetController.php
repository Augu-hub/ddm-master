<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil VIII — Diagramme Cause / Effet (Ishikawa – 5M)
 * Catégories : Main-d'œuvre, Matières, Méthodes, Milieu, Matériels (+ Management).
 * Route spéciale : POST /import  → importer les causes depuis les risques RCI/mission.
 */
class OutilCauseEffetController extends Controller
{
    private string $conn = 'tenant';

    /** 5M(+1) standards IFACI */
    const CATEGORIES = ['main_oeuvre', 'matieres', 'methodes', 'milieu', 'materiels', 'management'];

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_cause_effet')->where('id', $id)->first();
        abort_if(!$record, 404, 'Diagramme cause-effet introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_cause_effet as oce')
            ->leftJoin('missions as m', 'm.id', '=', 'oce.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oce.created_by')
            ->select('oce.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oce.created_at');

        if ($missionId) $query->where('oce.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/CauseEffet/Index', [
            'diagrammes' => $query->paginate(15)->withQueryString(),
            'missions'   => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'    => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $diagramme = $this->findOrFail($id);
        $causes = DB::connection($this->conn)->table('outil_cause_effet_causes')
            ->where('diagramme_id', $id)
            ->orderBy('categorie')->orderBy('ordre')
            ->get();

        return Inertia::render('Auditor/Outils/CauseEffet/Edit', [
            'diagramme'  => $diagramme,
            'causes'     => $causes,
            'categories' => self::CATEGORIES,
            'missions'   => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'    => 'required|integer',
            'intitule'      => 'required|string|max:255',
            'effet_central' => 'required|string|max:255',  // Le problème / effet observé
            'description'   => 'nullable|string',
            'date_analyse'  => 'nullable|date',
            'causes'        => 'nullable|array',
            'causes.*.categorie'  => 'required|in:main_oeuvre,matieres,methodes,milieu,materiels,management',
            'causes.*.libelle'    => 'required|string',
            'causes.*.sous_cause' => 'nullable|string',
            'causes.*.importance' => 'nullable|in:majeure,mineure,potentielle',
            'causes.*.ordre'      => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_cause_effet')->insertGetId([
            'mission_id'    => $v['mission_id'],
            'intitule'      => $v['intitule'],
            'effet_central' => $v['effet_central'],
            'description'   => $v['description'] ?? null,
            'date_analyse'  => $v['date_analyse'] ?? null,
            'statut'        => 'draft',
            'created_by'    => Auth::id(),
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);

        foreach (($v['causes'] ?? []) as $idx => $c) {
            DB::connection($this->conn)->table('outil_cause_effet_causes')->insert([
                'diagramme_id' => $id,
                'categorie'    => $c['categorie'],
                'libelle'      => $c['libelle'],
                'sous_cause'   => $c['sous_cause'] ?? null,
                'importance'   => $c['importance'] ?? 'mineure',
                'ordre'        => $c['ordre'] ?? ($idx + 1),
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);
        }

        return redirect()->route('auditor.outils.cause-effet.edit', $id)
            ->with('success', 'Diagramme cause-effet créé.');
    }

    public function update(Request $request, int $id)
    {
        $d = $this->findOrFail($id);
        abort_if($d->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'      => 'required|string|max:255',
            'effet_central' => 'required|string|max:255',
            'description'   => 'nullable|string',
            'date_analyse'  => 'nullable|date',
            'causes'        => 'nullable|array',
            'causes.*.categorie'  => 'required|in:main_oeuvre,matieres,methodes,milieu,materiels,management',
            'causes.*.libelle'    => 'required|string',
            'causes.*.sous_cause' => 'nullable|string',
            'causes.*.importance' => 'nullable|in:majeure,mineure,potentielle',
            'causes.*.ordre'      => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_cause_effet')->where('id', $id)->update([
            'intitule'      => $v['intitule'],
            'effet_central' => $v['effet_central'],
            'description'   => $v['description'] ?? null,
            'date_analyse'  => $v['date_analyse'] ?? null,
            'updated_at'    => now(),
        ]);

        DB::connection($this->conn)->table('outil_cause_effet_causes')->where('diagramme_id', $id)->delete();
        foreach (($v['causes'] ?? []) as $idx => $c) {
            DB::connection($this->conn)->table('outil_cause_effet_causes')->insert([
                'diagramme_id' => $id,
                'categorie'    => $c['categorie'],
                'libelle'      => $c['libelle'],
                'sous_cause'   => $c['sous_cause'] ?? null,
                'importance'   => $c['importance'] ?? 'mineure',
                'ordre'        => $c['ordre'] ?? ($idx + 1),
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);
        }

        return back()->with('success', 'Diagramme cause-effet mis à jour.');
    }

    public function soumettre(int $id)
    {
        $d = $this->findOrFail($id);
        abort_if($d->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_cause_effet')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Diagramme soumis pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $d = $this->findOrFail($id);
        abort_if($d->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_cause_effet')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Diagramme validé.' : 'Diagramme rejeté.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_cause_effet')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_cause_effet_causes')->where('diagramme_id', $id)->delete();
        DB::connection($this->conn)->table('outil_cause_effet')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.cause-effet.index')->with('success', 'Diagramme supprimé.');
    }

    // ── Route spéciale : import depuis RCI / risques mission ────────

    /**
     * POST /import
     * Importe les risques de la mission (table rci_risques ou ar_risques)
     * et les convertit en causes pour un diagramme existant ou un nouveau.
     *
     * Body attendu :
     *  {
     *    "mission_id"    : 12,
     *    "diagramme_id"  : null | 5,   // null = créer un nouveau
     *    "effet_central" : "...",
     *    "source"        : "rci" | "ar",
     *    "risque_ids"    : [1, 2, 3]   // null = tous
     *  }
     */
    public function import(Request $request)
    {
        $v = $request->validate([
            'mission_id'    => 'required|integer',
            'diagramme_id'  => 'nullable|integer',
            'effet_central' => 'required|string|max:255',
            'source'        => 'required|in:rci,ar',
            'risque_ids'    => 'nullable|array',
            'risque_ids.*'  => 'integer',
        ]);

        // Récupération des risques selon la source
        $table = $v['source'] === 'rci' ? 'rci_risques' : 'ar_risques';

        $query = DB::connection($this->conn)->table($table)
            ->where('mission_id', $v['mission_id'])
            ->select('id', 'libelle', 'categorie');

        if (!empty($v['risque_ids'])) {
            $query->whereIn('id', $v['risque_ids']);
        }

        $risques = $query->get();

        if ($risques->isEmpty()) {
            return back()->withErrors(['risques' => 'Aucun risque trouvé pour cette mission.']);
        }

        // Créer ou récupérer le diagramme cible
        if (!empty($v['diagramme_id'])) {
            $diagrammeId = $v['diagramme_id'];
            $this->findOrFail($diagrammeId); // vérifie existence
        } else {
            $diagrammeId = DB::connection($this->conn)->table('outil_cause_effet')->insertGetId([
                'mission_id'    => $v['mission_id'],
                'intitule'      => 'Importé depuis ' . strtoupper($v['source']),
                'effet_central' => $v['effet_central'],
                'description'   => 'Causes importées automatiquement depuis ' . strtoupper($v['source']),
                'statut'        => 'draft',
                'created_by'    => Auth::id(),
                'created_at'    => now(),
                'updated_at'    => now(),
            ]);
        }

        // Mapping catégorie risque → 5M
        $mapCategorie = [
            'humain'       => 'main_oeuvre',
            'operationnel' => 'methodes',
            'financier'    => 'matieres',
            'strategique'  => 'management',
            'conformite'   => 'methodes',
            'si'           => 'materiels',
            'default'      => 'methodes',
        ];

        foreach ($risques as $idx => $r) {
            $cat = $mapCategorie[$r->categorie ?? 'default'] ?? 'methodes';
            DB::connection($this->conn)->table('outil_cause_effet_causes')->insert([
                'diagramme_id' => $diagrammeId,
                'categorie'    => $cat,
                'libelle'      => $r->libelle,
                'importance'   => 'potentielle',
                'ordre'        => $idx + 1,
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);
        }

        return redirect()->route('auditor.outils.cause-effet.edit', $diagrammeId)
            ->with('success', count($risques) . ' risque(s) importé(s) comme causes.');
    }
}
