<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil XIII — Procédure d'Audit Analytique
 *
 * Structure réelle (feuille XIII) :
 *  - En-tête         : mission, date, auditeur, source des données
 *  - Tableau indicateurs :
 *      indicateur, description, valeur N-1, valeur N, budget/prévu,
 *      écart N vs N-1 (calculé), écart % N vs N-1 (calculé),
 *      écart N vs budget (calculé), écart % N vs budget (calculé)
 *  - Analyse des écarts significatifs :
 *      indicateur, écart constaté, seuil de signification, significatif (oui/non),
 *      explication obtenue, procédure complémentaire à mettre en œuvre
 *  - Conclusion
 *
 * Tables :
 *   outil_audit_analytique           → en-tête + conclusion
 *   outil_audit_analytique_lignes    → indicateurs/rubriques
 *   outil_audit_analytique_ecarts    → analyse écarts significatifs
 */
class OutilAuditAnalytiqueController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_audit_analytique')->where('id', $id)->first();
        abort_if(!$record, 404, 'Procédure d\'audit analytique introuvable.');
        return $record;
    }

    /** Calcule les écarts automatiquement */
    private function calcEcarts(array $l): array
    {
        $vN   = isset($l['valeur_n'])      ? (float) $l['valeur_n']   : null;
        $vN1  = isset($l['valeur_n1'])     ? (float) $l['valeur_n1']  : null;
        $budg = isset($l['valeur_budget']) ? (float) $l['valeur_budget'] : null;

        $ecart_n_n1     = ($vN !== null && $vN1 !== null) ? ($vN - $vN1) : null;
        $ecart_pct_n_n1 = ($ecart_n_n1 !== null && $vN1 != 0) ? round(($ecart_n_n1 / $vN1) * 100, 2) : null;
        $ecart_n_budg   = ($vN !== null && $budg !== null) ? ($vN - $budg) : null;
        $ecart_pct_budg = ($ecart_n_budg !== null && $budg != 0) ? round(($ecart_n_budg / $budg) * 100, 2) : null;

        return compact('ecart_n_n1', 'ecart_pct_n_n1', 'ecart_n_budg', 'ecart_pct_budg');
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_audit_analytique as oaa')
            ->leftJoin('missions as m', 'm.id', '=', 'oaa.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oaa.created_by')
            ->select('oaa.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oaa.created_at');

        if ($missionId) $query->where('oaa.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/AuditAnalytique/Index', [
            'procedures' => $query->paginate(15)->withQueryString(),
            'missions'   => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'    => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $procedure = $this->findOrFail($id);

        $lignes = DB::connection($this->conn)->table('outil_audit_analytique_lignes')
            ->where('procedure_id', $id)->orderBy('ordre')->get();

        $ecarts = DB::connection($this->conn)->table('outil_audit_analytique_ecarts')
            ->where('procedure_id', $id)->orderBy('ordre')->get();

        return Inertia::render('Auditor/Outils/AuditAnalytique/Edit', [
            'procedure' => $procedure,
            'lignes'    => $lignes,
            'ecarts'    => $ecarts,
            'missions'  => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'     => 'required|integer',
            'auditeur'       => 'nullable|string|max:255',
            'source_donnees' => 'nullable|string|max:255',
            'date_procedure' => 'nullable|date',
            'conclusion'     => 'nullable|string',
            // Indicateurs
            'lignes'                       => 'nullable|array',
            'lignes.*.indicateur'          => 'required|string|max:255',
            'lignes.*.description'         => 'nullable|string',
            'lignes.*.valeur_n1'           => 'nullable|numeric',
            'lignes.*.valeur_n'            => 'nullable|numeric',
            'lignes.*.valeur_budget'       => 'nullable|numeric',
            'lignes.*.ordre'               => 'nullable|integer',
            // Écarts significatifs
            'ecarts'                              => 'nullable|array',
            'ecarts.*.indicateur'                 => 'required|string|max:255',
            'ecarts.*.ecart_constate'             => 'nullable|string',
            'ecarts.*.seuil_signification'        => 'nullable|numeric',
            'ecarts.*.significatif'               => 'nullable|in:oui,non',
            'ecarts.*.explication'                => 'nullable|string',
            'ecarts.*.procedure_complementaire'   => 'nullable|string',
            'ecarts.*.ordre'                      => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_audit_analytique')->insertGetId([
            'mission_id'     => $v['mission_id'],
            'auditeur'       => $v['auditeur'] ?? null,
            'source_donnees' => $v['source_donnees'] ?? null,
            'date_procedure' => $v['date_procedure'] ?? null,
            'conclusion'     => $v['conclusion'] ?? null,
            'statut'         => 'draft',
            'created_by'     => Auth::id(),
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        foreach (($v['lignes'] ?? []) as $idx => $l) {
            $calc = $this->calcEcarts($l);
            DB::connection($this->conn)->table('outil_audit_analytique_lignes')->insert([
                'procedure_id'    => $id,
                'indicateur'      => $l['indicateur'],
                'description'     => $l['description'] ?? null,
                'valeur_n1'       => $l['valeur_n1'] ?? null,
                'valeur_n'        => $l['valeur_n'] ?? null,
                'valeur_budget'   => $l['valeur_budget'] ?? null,
                'ecart_n_n1'      => $calc['ecart_n_n1'],
                'ecart_pct_n_n1'  => $calc['ecart_pct_n_n1'],
                'ecart_n_budg'    => $calc['ecart_n_budg'],
                'ecart_pct_budg'  => $calc['ecart_pct_budg'],
                'ordre'           => $l['ordre'] ?? ($idx + 1),
                'created_at'      => now(),
                'updated_at'      => now(),
            ]);
        }

        foreach (($v['ecarts'] ?? []) as $idx => $e) {
            DB::connection($this->conn)->table('outil_audit_analytique_ecarts')->insert([
                'procedure_id'            => $id,
                'indicateur'              => $e['indicateur'],
                'ecart_constate'          => $e['ecart_constate'] ?? null,
                'seuil_signification'     => $e['seuil_signification'] ?? null,
                'significatif'            => $e['significatif'] ?? null,
                'explication'             => $e['explication'] ?? null,
                'procedure_complementaire'=> $e['procedure_complementaire'] ?? null,
                'ordre'                   => $e['ordre'] ?? ($idx + 1),
                'created_at'              => now(),
                'updated_at'              => now(),
            ]);
        }

        return redirect()->route('auditor.outils.audit-analytique.edit', $id)
            ->with('success', 'Procédure d\'audit analytique créée.');
    }

    public function update(Request $request, int $id)
    {
        $proc = $this->findOrFail($id);
        abort_if($proc->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'auditeur'                            => 'nullable|string|max:255',
            'source_donnees'                      => 'nullable|string|max:255',
            'date_procedure'                      => 'nullable|date',
            'conclusion'                          => 'nullable|string',
            'lignes'                              => 'nullable|array',
            'lignes.*.indicateur'                 => 'required|string|max:255',
            'lignes.*.description'                => 'nullable|string',
            'lignes.*.valeur_n1'                  => 'nullable|numeric',
            'lignes.*.valeur_n'                   => 'nullable|numeric',
            'lignes.*.valeur_budget'              => 'nullable|numeric',
            'lignes.*.ordre'                      => 'nullable|integer',
            'ecarts'                              => 'nullable|array',
            'ecarts.*.indicateur'                 => 'required|string|max:255',
            'ecarts.*.ecart_constate'             => 'nullable|string',
            'ecarts.*.seuil_signification'        => 'nullable|numeric',
            'ecarts.*.significatif'               => 'nullable|in:oui,non',
            'ecarts.*.explication'                => 'nullable|string',
            'ecarts.*.procedure_complementaire'   => 'nullable|string',
            'ecarts.*.ordre'                      => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_audit_analytique')->where('id', $id)->update([
            'auditeur'       => $v['auditeur'] ?? null,
            'source_donnees' => $v['source_donnees'] ?? null,
            'date_procedure' => $v['date_procedure'] ?? null,
            'conclusion'     => $v['conclusion'] ?? null,
            'updated_at'     => now(),
        ]);

        DB::connection($this->conn)->table('outil_audit_analytique_lignes')->where('procedure_id', $id)->delete();
        foreach (($v['lignes'] ?? []) as $idx => $l) {
            $calc = $this->calcEcarts($l);
            DB::connection($this->conn)->table('outil_audit_analytique_lignes')->insert([
                'procedure_id'   => $id,
                'indicateur'     => $l['indicateur'],
                'description'    => $l['description'] ?? null,
                'valeur_n1'      => $l['valeur_n1'] ?? null,
                'valeur_n'       => $l['valeur_n'] ?? null,
                'valeur_budget'  => $l['valeur_budget'] ?? null,
                'ecart_n_n1'     => $calc['ecart_n_n1'],
                'ecart_pct_n_n1' => $calc['ecart_pct_n_n1'],
                'ecart_n_budg'   => $calc['ecart_n_budg'],
                'ecart_pct_budg' => $calc['ecart_pct_budg'],
                'ordre'          => $l['ordre'] ?? ($idx + 1),
                'created_at'     => now(),
                'updated_at'     => now(),
            ]);
        }

        DB::connection($this->conn)->table('outil_audit_analytique_ecarts')->where('procedure_id', $id)->delete();
        foreach (($v['ecarts'] ?? []) as $idx => $e) {
            DB::connection($this->conn)->table('outil_audit_analytique_ecarts')->insert([
                'procedure_id'             => $id,
                'indicateur'               => $e['indicateur'],
                'ecart_constate'           => $e['ecart_constate'] ?? null,
                'seuil_signification'      => $e['seuil_signification'] ?? null,
                'significatif'             => $e['significatif'] ?? null,
                'explication'              => $e['explication'] ?? null,
                'procedure_complementaire' => $e['procedure_complementaire'] ?? null,
                'ordre'                    => $e['ordre'] ?? ($idx + 1),
                'created_at'               => now(),
                'updated_at'               => now(),
            ]);
        }

        return back()->with('success', 'Procédure d\'audit analytique mise à jour.');
    }

    public function soumettre(int $id)
    {
        $p = $this->findOrFail($id);
        abort_if($p->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_audit_analytique')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Procédure soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $p = $this->findOrFail($id);
        abort_if($p->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_audit_analytique')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Procédure validée.' : 'Procédure rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_audit_analytique')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_audit_analytique_lignes')->where('procedure_id', $id)->delete();
        DB::connection($this->conn)->table('outil_audit_analytique_ecarts')->where('procedure_id', $id)->delete();
        DB::connection($this->conn)->table('outil_audit_analytique')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.audit-analytique.index')->with('success', 'Procédure supprimée.');
    }
}
