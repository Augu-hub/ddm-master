<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil XII — Circularisation (Confirmation externe)
 *
 * Structure réelle (feuille XII) :
 *  - En-tête     : mission, date_envoi, date_limite, adresse_reception
 *  - Suivi demandes : tiers, élément à confirmer, montant/période, date envoi,
 *                     date réponse, montant confirmé, élément confirmé, écart (=F-C),
 *                     statut (OK / Écart / Sans réponse)
 *  - Synthèse    : totaux calculés (envoyées, reçues, sans réponse, écarts, taux)
 *
 * Tables :
 *   outil_circularisation          → en-tête
 *   outil_circularisation_demandes → lignes de suivi
 */
class OutilCircularisationController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_circularisation')->where('id', $id)->first();
        abort_if(!$record, 404, 'Fiche de circularisation introuvable.');
        return $record;
    }

    /** Calcule la synthèse à la volée depuis les demandes */
    private function synthese(int $ficheId): array
    {
        $demandes = DB::connection($this->conn)
            ->table('outil_circularisation_demandes')
            ->where('fiche_id', $ficheId)
            ->get();

        $total        = $demandes->count();
        $recues       = $demandes->whereIn('statut_reponse', ['ok', 'ecart'])->count();
        $sans_reponse = $demandes->where('statut_reponse', 'sans_reponse')->count();
        $ecarts       = $demandes->where('statut_reponse', 'ecart')->count();
        $taux         = $total > 0 ? round(($recues / $total) * 100, 1) : 0;

        return compact('total', 'recues', 'sans_reponse', 'ecarts', 'taux');
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_circularisation as oc')
            ->leftJoin('missions as m', 'm.id', '=', 'oc.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oc.created_by')
            ->select('oc.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oc.created_at');

        if ($missionId) $query->where('oc.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/Circularisation/Index', [
            'fiches'   => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $fiche    = $this->findOrFail($id);
        $demandes = DB::connection($this->conn)->table('outil_circularisation_demandes')
            ->where('fiche_id', $id)->orderBy('id')->get();

        return Inertia::render('Auditor/Outils/Circularisation/Edit', [
            'fiche'    => $fiche,
            'demandes' => $demandes,
            'synthese' => $this->synthese($id),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'          => 'required|integer',
            'date_envoi'          => 'nullable|date',
            'date_limite'         => 'nullable|date',
            'adresse_reception'   => 'nullable|string|max:255',
            'demandes'            => 'nullable|array',
            'demandes.*.nom_tiers'          => 'required|string|max:255',
            'demandes.*.element_confirmer'  => 'nullable|string|max:255',
            'demandes.*.montant_periode'    => 'nullable|string|max:100',
            'demandes.*.date_envoi_demande' => 'nullable|date',
            'demandes.*.date_reponse'       => 'nullable|date',
            'demandes.*.montant_confirme'   => 'nullable|numeric',
            'demandes.*.element_confirme'   => 'nullable|string|max:255',
            'demandes.*.montant_envoye'     => 'nullable|numeric',
            'demandes.*.statut_reponse'     => 'nullable|in:ok,ecart,sans_reponse',
        ]);

        $id = DB::connection($this->conn)->table('outil_circularisation')->insertGetId([
            'mission_id'        => $v['mission_id'],
            'date_envoi'        => $v['date_envoi'] ?? null,
            'date_limite'       => $v['date_limite'] ?? null,
            'adresse_reception' => $v['adresse_reception'] ?? null,
            'statut'            => 'draft',
            'created_by'        => Auth::id(),
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        foreach (($v['demandes'] ?? []) as $d) {
            $ecart = (isset($d['montant_envoye']) && isset($d['montant_confirme']))
                ? ($d['montant_envoye'] - $d['montant_confirme'])
                : null;

            DB::connection($this->conn)->table('outil_circularisation_demandes')->insert([
                'fiche_id'             => $id,
                'nom_tiers'            => $d['nom_tiers'],
                'element_confirmer'    => $d['element_confirmer'] ?? null,
                'montant_periode'      => $d['montant_periode'] ?? null,
                'date_envoi_demande'   => $d['date_envoi_demande'] ?? null,
                'date_reponse'         => $d['date_reponse'] ?? null,
                'montant_envoye'       => $d['montant_envoye'] ?? null,
                'montant_confirme'     => $d['montant_confirme'] ?? null,
                'element_confirme'     => $d['element_confirme'] ?? null,
                'ecart'                => $ecart,
                'statut_reponse'       => $d['statut_reponse'] ?? 'sans_reponse',
                'created_at'           => now(),
                'updated_at'           => now(),
            ]);
        }

        return redirect()->route('auditor.outils.circularisation.edit', $id)
            ->with('success', 'Fiche de circularisation créée.');
    }

    public function update(Request $request, int $id)
    {
        $fiche = $this->findOrFail($id);
        abort_if($fiche->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'date_envoi'                     => 'nullable|date',
            'date_limite'                    => 'nullable|date',
            'adresse_reception'              => 'nullable|string|max:255',
            'demandes'                       => 'nullable|array',
            'demandes.*.nom_tiers'           => 'required|string|max:255',
            'demandes.*.element_confirmer'   => 'nullable|string|max:255',
            'demandes.*.montant_periode'     => 'nullable|string|max:100',
            'demandes.*.date_envoi_demande'  => 'nullable|date',
            'demandes.*.date_reponse'        => 'nullable|date',
            'demandes.*.montant_envoye'      => 'nullable|numeric',
            'demandes.*.montant_confirme'    => 'nullable|numeric',
            'demandes.*.element_confirme'    => 'nullable|string|max:255',
            'demandes.*.statut_reponse'      => 'nullable|in:ok,ecart,sans_reponse',
        ]);

        DB::connection($this->conn)->table('outil_circularisation')->where('id', $id)->update([
            'date_envoi'        => $v['date_envoi'] ?? null,
            'date_limite'       => $v['date_limite'] ?? null,
            'adresse_reception' => $v['adresse_reception'] ?? null,
            'updated_at'        => now(),
        ]);

        DB::connection($this->conn)->table('outil_circularisation_demandes')->where('fiche_id', $id)->delete();
        foreach (($v['demandes'] ?? []) as $d) {
            $ecart = (isset($d['montant_envoye']) && isset($d['montant_confirme']))
                ? ($d['montant_envoye'] - $d['montant_confirme'])
                : null;

            DB::connection($this->conn)->table('outil_circularisation_demandes')->insert([
                'fiche_id'           => $id,
                'nom_tiers'          => $d['nom_tiers'],
                'element_confirmer'  => $d['element_confirmer'] ?? null,
                'montant_periode'    => $d['montant_periode'] ?? null,
                'date_envoi_demande' => $d['date_envoi_demande'] ?? null,
                'date_reponse'       => $d['date_reponse'] ?? null,
                'montant_envoye'     => $d['montant_envoye'] ?? null,
                'montant_confirme'   => $d['montant_confirme'] ?? null,
                'element_confirme'   => $d['element_confirme'] ?? null,
                'ecart'              => $ecart,
                'statut_reponse'     => $d['statut_reponse'] ?? 'sans_reponse',
                'created_at'         => now(),
                'updated_at'         => now(),
            ]);
        }

        return back()->with('success', 'Fiche de circularisation mise à jour.');
    }

    public function soumettre(int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_circularisation')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Fiche soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_circularisation')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Fiche validée.' : 'Fiche rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_circularisation')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_circularisation_demandes')->where('fiche_id', $id)->delete();
        DB::connection($this->conn)->table('outil_circularisation')->where('id', $id)->delete();
        return redirect()->route('auditor.outils.circularisation.index')->with('success', 'Fiche supprimée.');
    }
}
