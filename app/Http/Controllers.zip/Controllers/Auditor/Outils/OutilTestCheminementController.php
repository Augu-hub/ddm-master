<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil V — Test de Cheminement (Walk-through)
 * Suit une transaction de bout en bout à travers les contrôles.
 */
class OutilTestCheminementController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_test_cheminement')->where('id', $id)->first();
        abort_if(!$record, 404, 'Test de cheminement introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_test_cheminement as otc')
            ->leftJoin('missions as m', 'm.id', '=', 'otc.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'otc.created_by')
            ->select('otc.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('otc.created_at');

        if ($missionId) $query->where('otc.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/TestCheminement/Index', [
            'tests'    => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $test = $this->findOrFail($id);
        $etapes = DB::connection($this->conn)->table('outil_test_cheminement_etapes')
            ->where('test_id', $id)->orderBy('ordre')->get();

        return Inertia::render('Auditor/Outils/TestCheminement/Edit', [
            'test'     => $test,
            'etapes'   => $etapes,
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'         => 'required|integer',
            'intitule'           => 'required|string|max:255',
            'processus_audite'   => 'nullable|string|max:255',
            'reference_transaction' => 'nullable|string|max:100',
            'date_test'          => 'nullable|date',
            'auditeur'           => 'nullable|string|max:255',
            'etapes'             => 'nullable|array',
            'etapes.*.libelle'   => 'required|string',
            'etapes.*.acteur'    => 'nullable|string',
            'etapes.*.document'  => 'nullable|string',
            'etapes.*.controle'  => 'nullable|string',
            'etapes.*.resultat'  => 'nullable|in:conforme,non_conforme,partiel,na',
            'etapes.*.observation' => 'nullable|string',
            'etapes.*.ordre'     => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_test_cheminement')->insertGetId([
            'mission_id'            => $v['mission_id'],
            'intitule'              => $v['intitule'],
            'processus_audite'      => $v['processus_audite'] ?? null,
            'reference_transaction' => $v['reference_transaction'] ?? null,
            'date_test'             => $v['date_test'] ?? null,
            'auditeur'              => $v['auditeur'] ?? null,
            'statut'                => 'draft',
            'created_by'            => Auth::id(),
            'created_at'            => now(),
            'updated_at'            => now(),
        ]);

        foreach (($v['etapes'] ?? []) as $idx => $e) {
            DB::connection($this->conn)->table('outil_test_cheminement_etapes')->insert([
                'test_id'      => $id,
                'libelle'      => $e['libelle'],
                'acteur'       => $e['acteur'] ?? null,
                'document'     => $e['document'] ?? null,
                'controle'     => $e['controle'] ?? null,
                'resultat'     => $e['resultat'] ?? null,
                'observation'  => $e['observation'] ?? null,
                'ordre'        => $e['ordre'] ?? ($idx + 1),
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);
        }

        return redirect()->route('auditor.ac.outil-test-cheminement.edit', $id)
            ->with('success', 'Test de cheminement créé.');
    }

    public function update(Request $request, int $id)
    {
        $test = $this->findOrFail($id);
        abort_if($test->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'              => 'required|string|max:255',
            'processus_audite'      => 'nullable|string|max:255',
            'reference_transaction' => 'nullable|string|max:100',
            'date_test'             => 'nullable|date',
            'auditeur'              => 'nullable|string|max:255',
            'etapes'                => 'nullable|array',
            'etapes.*.libelle'      => 'required|string',
            'etapes.*.acteur'       => 'nullable|string',
            'etapes.*.document'     => 'nullable|string',
            'etapes.*.controle'     => 'nullable|string',
            'etapes.*.resultat'     => 'nullable|in:conforme,non_conforme,partiel,na',
            'etapes.*.observation'  => 'nullable|string',
            'etapes.*.ordre'        => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_test_cheminement')->where('id', $id)->update([
            'intitule'              => $v['intitule'],
            'processus_audite'      => $v['processus_audite'] ?? null,
            'reference_transaction' => $v['reference_transaction'] ?? null,
            'date_test'             => $v['date_test'] ?? null,
            'auditeur'              => $v['auditeur'] ?? null,
            'updated_at'            => now(),
        ]);

        DB::connection($this->conn)->table('outil_test_cheminement_etapes')->where('test_id', $id)->delete();
        foreach (($v['etapes'] ?? []) as $idx => $e) {
            DB::connection($this->conn)->table('outil_test_cheminement_etapes')->insert([
                'test_id'     => $id,
                'libelle'     => $e['libelle'],
                'acteur'      => $e['acteur'] ?? null,
                'document'    => $e['document'] ?? null,
                'controle'    => $e['controle'] ?? null,
                'resultat'    => $e['resultat'] ?? null,
                'observation' => $e['observation'] ?? null,
                'ordre'       => $e['ordre'] ?? ($idx + 1),
                'created_at'  => now(),
                'updated_at'  => now(),
            ]);
        }

        return back()->with('success', 'Test de cheminement mis à jour.');
    }

    public function soumettre(int $id)
    {
        $t = $this->findOrFail($id);
        abort_if($t->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_test_cheminement')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Test soumis pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $t = $this->findOrFail($id);
        abort_if($t->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_test_cheminement')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Test validé.' : 'Test rejeté.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_test_cheminement')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_test_cheminement_etapes')->where('test_id', $id)->delete();
        DB::connection($this->conn)->table('outil_test_cheminement')->where('id', $id)->delete();
        return redirect()->route('auditor.ac.outil-test-cheminement.index')->with('success', 'Test supprimé.');
    }
}
