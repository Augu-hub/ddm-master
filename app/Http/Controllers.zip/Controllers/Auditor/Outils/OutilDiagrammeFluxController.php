<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil III — Diagramme de Flux
 * Stocke le diagramme sous forme de XML bpmn-js ou JSON de nœuds/liens.
 */
class OutilDiagrammeFluxController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_diagramme_flux')->where('id', $id)->first();
        abort_if(!$record, 404, 'Diagramme de flux introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_diagramme_flux as odf')
            ->leftJoin('missions as m', 'm.id', '=', 'odf.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'odf.created_by')
            ->select('odf.id','odf.intitule','odf.processus','odf.statut','odf.created_at',
                'm.reference as mission_ref','m.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('odf.created_at');

        if ($missionId) $query->where('odf.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/DiagrammeFlux/Index', [
            'diagrammes' => $query->paginate(15)->withQueryString(),
            'missions'   => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'    => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $diagramme = $this->findOrFail($id);
        return Inertia::render('Auditor/Outils/DiagrammeFlux/Edit', [
            'diagramme' => $diagramme,
            'missions'  => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'    => 'required|integer',
            'intitule'      => 'required|string|max:255',
            'processus'     => 'nullable|string|max:255',
            'description'   => 'nullable|string',
            'bpmn_xml'      => 'nullable|string',   // contenu bpmn-js
            'json_data'     => 'nullable|json',     // alternative JSON nodes/edges
            'date_creation' => 'nullable|date',
        ]);

        $id = DB::connection($this->conn)->table('outil_diagramme_flux')->insertGetId([
            'mission_id'    => $v['mission_id'],
            'intitule'      => $v['intitule'],
            'processus'     => $v['processus'] ?? null,
            'description'   => $v['description'] ?? null,
            'bpmn_xml'      => $v['bpmn_xml'] ?? null,
            'json_data'     => $v['json_data'] ?? null,
            'date_creation' => $v['date_creation'] ?? now()->toDateString(),
            'statut'        => 'draft',
            'created_by'    => Auth::id(),
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);

        return redirect()->route('auditor.ac.outil-diagramme-flux.edit', $id)
            ->with('success', 'Diagramme de flux créé.');
    }

    public function update(Request $request, int $id)
    {
        $d = $this->findOrFail($id);
        abort_if($d->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'      => 'required|string|max:255',
            'processus'     => 'nullable|string|max:255',
            'description'   => 'nullable|string',
            'bpmn_xml'      => 'nullable|string',
            'json_data'     => 'nullable|json',
            'date_creation' => 'nullable|date',
        ]);

        DB::connection($this->conn)->table('outil_diagramme_flux')->where('id', $id)->update([
            'intitule'      => $v['intitule'],
            'processus'     => $v['processus'] ?? null,
            'description'   => $v['description'] ?? null,
            'bpmn_xml'      => $v['bpmn_xml'] ?? null,
            'json_data'     => $v['json_data'] ?? null,
            'date_creation' => $v['date_creation'] ?? null,
            'updated_at'    => now(),
        ]);

        return back()->with('success', 'Diagramme de flux mis à jour.');
    }

    public function soumettre(int $id)
    {
        $d = $this->findOrFail($id);
        abort_if($d->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_diagramme_flux')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Diagramme soumis pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $d = $this->findOrFail($id);
        abort_if($d->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_diagramme_flux')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Diagramme validé.' : 'Diagramme rejeté.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_diagramme_flux')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_diagramme_flux')->where('id', $id)->delete();
        return redirect()->route('auditor.ac.outil-diagramme-flux.index')->with('success', 'Diagramme supprimé.');
    }
}
