<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

/**
 * Outil IV — Approche Processus
 * Cartographie les processus : entrées, sorties, acteurs, indicateurs, risques.
 */
class OutilApprocheProcessusController extends Controller
{
    private string $conn = 'tenant';

    private function findOrFail(int $id): object
    {
        $record = DB::connection($this->conn)->table('outil_approche_processus')->where('id', $id)->first();
        abort_if(!$record, 404, 'Fiche approche processus introuvable.');
        return $record;
    }

    public function index(Request $request)
    {
        $missionId = $request->query('mission_id');

        $query = DB::connection($this->conn)
            ->table('outil_approche_processus as oap')
            ->leftJoin('missions as m', 'm.id', '=', 'oap.mission_id')
            ->leftJoin('users as u', 'u.id', '=', 'oap.created_by')
            ->select('oap.*', 'm.reference as mission_ref', 'm.libelle as mission_libelle',
                DB::raw("CONCAT(u.prenom, ' ', u.nom) as auteur"))
            ->orderByDesc('oap.created_at');

        if ($missionId) $query->where('oap.mission_id', $missionId);

        return Inertia::render('Auditor/Outils/ApprocheProcessus/Index', [
            'fiches'   => $query->paginate(15)->withQueryString(),
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
            'filters'  => ['mission_id' => $missionId],
        ]);
    }

    public function edit(int $id)
    {
        $fiche = $this->findOrFail($id);
        $lignes = DB::connection($this->conn)->table('outil_approche_processus_lignes')
            ->where('fiche_id', $id)->orderBy('ordre')->get();

        return Inertia::render('Auditor/Outils/ApprocheProcessus/Edit', [
            'fiche'    => $fiche,
            'lignes'   => $lignes,
            'missions' => DB::connection($this->conn)->table('missions')->select('id','reference','libelle')->orderBy('reference')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $v = $request->validate([
            'mission_id'     => 'required|integer',
            'intitule'       => 'required|string|max:255',
            'nom_processus'  => 'nullable|string|max:255',
            'pilote'         => 'nullable|string|max:255',
            'objectif'       => 'nullable|string',
            'date_analyse'   => 'nullable|date',
            'lignes'         => 'nullable|array',
            'lignes.*.type'  => 'required|in:entree,sortie,acteur,indicateur,risque,controle',
            'lignes.*.libelle' => 'required|string',
            'lignes.*.valeur'  => 'nullable|string',
            'lignes.*.ordre'   => 'nullable|integer',
        ]);

        $id = DB::connection($this->conn)->table('outil_approche_processus')->insertGetId([
            'mission_id'    => $v['mission_id'],
            'intitule'      => $v['intitule'],
            'nom_processus' => $v['nom_processus'] ?? null,
            'pilote'        => $v['pilote'] ?? null,
            'objectif'      => $v['objectif'] ?? null,
            'date_analyse'  => $v['date_analyse'] ?? null,
            'statut'        => 'draft',
            'created_by'    => Auth::id(),
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);

        foreach (($v['lignes'] ?? []) as $idx => $l) {
            DB::connection($this->conn)->table('outil_approche_processus_lignes')->insert([
                'fiche_id'   => $id,
                'type'       => $l['type'],
                'libelle'    => $l['libelle'],
                'valeur'     => $l['valeur'] ?? null,
                'ordre'      => $l['ordre'] ?? ($idx + 1),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return redirect()->route('auditor.ac.outil-approche-processus.edit', $id)
            ->with('success', 'Fiche approche processus créée.');
    }

    public function update(Request $request, int $id)
    {
        $fiche = $this->findOrFail($id);
        abort_if($fiche->statut === 'validated', 403, 'Document validé, modification impossible.');

        $v = $request->validate([
            'intitule'       => 'required|string|max:255',
            'nom_processus'  => 'nullable|string|max:255',
            'pilote'         => 'nullable|string|max:255',
            'objectif'       => 'nullable|string',
            'date_analyse'   => 'nullable|date',
            'lignes'         => 'nullable|array',
            'lignes.*.type'    => 'required|in:entree,sortie,acteur,indicateur,risque,controle',
            'lignes.*.libelle' => 'required|string',
            'lignes.*.valeur'  => 'nullable|string',
            'lignes.*.ordre'   => 'nullable|integer',
        ]);

        DB::connection($this->conn)->table('outil_approche_processus')->where('id', $id)->update([
            'intitule'      => $v['intitule'],
            'nom_processus' => $v['nom_processus'] ?? null,
            'pilote'        => $v['pilote'] ?? null,
            'objectif'      => $v['objectif'] ?? null,
            'date_analyse'  => $v['date_analyse'] ?? null,
            'updated_at'    => now(),
        ]);

        DB::connection($this->conn)->table('outil_approche_processus_lignes')->where('fiche_id', $id)->delete();
        foreach (($v['lignes'] ?? []) as $idx => $l) {
            DB::connection($this->conn)->table('outil_approche_processus_lignes')->insert([
                'fiche_id'   => $id,
                'type'       => $l['type'],
                'libelle'    => $l['libelle'],
                'valeur'     => $l['valeur'] ?? null,
                'ordre'      => $l['ordre'] ?? ($idx + 1),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return back()->with('success', 'Fiche approche processus mise à jour.');
    }

    public function soumettre(int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'draft', 422, 'Seul un brouillon peut être soumis.');
        DB::connection($this->conn)->table('outil_approche_processus')->where('id', $id)
            ->update(['statut' => 'in_review', 'updated_at' => now()]);
        return back()->with('success', 'Fiche soumise pour validation.');
    }

    public function valider(Request $request, int $id)
    {
        $f = $this->findOrFail($id);
        abort_if($f->statut !== 'in_review', 422, 'Document non soumis.');
        $v = $request->validate(['decision' => 'required|in:validated,rejected', 'commentaire' => 'nullable|string']);
        DB::connection($this->conn)->table('outil_approche_processus')->where('id', $id)->update([
            'statut'                 => $v['decision'],
            'commentaire_validation' => $v['commentaire'] ?? null,
            'validated_by'           => Auth::id(),
            'validated_at'           => now(),
            'updated_at'             => now(),
        ]);
        return back()->with('success', $v['decision'] === 'validated' ? 'Fiche validée.' : 'Fiche rejetée.');
    }


    // ═══════════════════════════════════════════════════════════
    // IA — Analyse via Claude API
    // ═══════════════════════════════════════════════════════════
    public function ia(int $id): \Illuminate\Http\JsonResponse
    {
        $record = $this->findOrFail($id);
        $payload = (array) $record;
        $prompt  = "Analyse ce document d'audit interne IFACI (outil).\n\n"
                 . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
                 . "\n\nFournis une analyse JSON UNIQUEMENT (sans markdown) avec: synthese (string), points_forts (array), points_faibles (array), risques (array), recommandations (array), score (number 0-10).";

        try {
            $r = \Illuminate\Support\Facades\Http::withHeaders([
                'x-api-key'         => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ])->timeout(30)->post('https://api.anthropic.com/v1/messages', [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system'     => 'Tu es expert audit interne IFACI. Retourne UNIQUEMENT un JSON valide (pas de markdown) avec ces clés: synthese, points_forts, points_faibles, risques, recommandations, score.',
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ])->json();

            $text = collect($r['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $text = trim(preg_replace('/^```json\s*|\s*```$/m', '', $text));
            $data = json_decode($text, true) ?? [];

            DB::connection($this->conn)->table('outil_approche_processus')->where('id', $id)->update([
                'ia_result'  => json_encode($data, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'ia_result' => $data]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function destroyint $id)
    {
        $this->findOrFail($id);
        DB::connection($this->conn)->table('outil_approche_processus_lignes')->where('fiche_id', $id)->delete();
        DB::connection($this->conn)->table('outil_approche_processus')->where('id', $id)->delete();
        return redirect()->route('auditor.ac.outil-approche-processus.index')->with('success', 'Fiche supprimée.');
    }
}
