<?php

namespace App\Http\Controllers\Auditor\Outils;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * FicheTestContextTrait
 *
 * Ajoute à chaque controller outil la capacité de recevoir le contexte
 * FicheTest (fiche_test_id, mission_id, assignment_id, test_ref, obj_num,
 * proc_idx, back) passé en query string depuis FicheTest.vue.
 *
 * Usage dans chaque controller outil :
 *
 *   use FicheTestContextTrait;
 *
 * Puis dans index() / edit() :
 *
 *   $ftCtx = $this->ficheTestContext($request);
 *   // ... render Inertia avec $ftCtx['...']
 *
 * Dans store() / update() après l'enregistrement en BD :
 *
 *   $this->saveFicheTestLinkIfPresent($request, $outilId);
 *   if ($request->has('back')) {
 *       return redirect($request->input('back'));
 *   }
 */
trait FicheTestContextTrait
{

    // ─────────────────────────────────────────────────────────────────
    // Lit les paramètres de contexte depuis la requête (GET ou POST)
    // ─────────────────────────────────────────────────────────────────
    protected function ficheTestContext(Request $request): array
    {
        $ficheTestId  = $request->input('fiche_test_id') ? (int) $request->input('fiche_test_id') : null;
        $missionId    = $request->input('mission_id')    ? (int) $request->input('mission_id')    : null;
        $assignmentId = $request->input('assignment_id') ? (int) $request->input('assignment_id') : null;
        $testRef      = $request->input('test_ref',  '');
        $objNum       = $request->input('obj_num',   '');
        $procIdx      = (int) $request->input('proc_idx', 0);
        $back         = $request->input('back', null);

        // Construire le query string à propager dans les URLs du controller
        $qs = http_build_query(array_filter([
            'fiche_test_id'  => $ficheTestId,
            'mission_id'     => $missionId,
            'assignment_id'  => $assignmentId,
            'test_ref'       => $testRef,
            'obj_num'        => $objNum,
            'proc_idx'       => $procIdx,
            'back'           => $back,
        ]));

        return [
            'fiche_test_id'  => $ficheTestId,
            'mission_id'     => $missionId,
            'assignment_id'  => $assignmentId,
            'test_ref'       => $testRef,
            'obj_num'        => $objNum,
            'proc_idx'       => $procIdx,
            'back_url'       => $back,
            'query_string'   => $qs ? '?' . $qs : '',
            'has_context'    => $ficheTestId !== null,
            'missionContext' => [
                'mission_id'     => $missionId,
                'assignment_id'  => $assignmentId,
                'test_ref'       => $testRef,
                'obj_num'        => $objNum,
                'proc_idx'       => $procIdx,
                'fiche_test_id'  => $ficheTestId,
                'code_mission'   => '',
            ],
        ];
    }

    // ─────────────────────────────────────────────────────────────────
    // Cherche un outil existant dans fiche_test_outils
    // pour le test + proc_idx donné.
    // Retourne l'id de l'outil ou null.
    // ─────────────────────────────────────────────────────────────────
    protected function findExistingOutilId(
        int    $ficheTestId,
        string $outilCode,
        string $testRef,
        int    $procIdx
    ): ?int {
        $q = DB::connection($this->conn)->table('fiche_test_outils')
            ->where('fiche_test_id', $ficheTestId)
            ->where('outil_code', $outilCode)
            ->where('test_ref', $testRef)
            ->where('is_current', 1);

        try {
            $cols = DB::connection($this->conn)->getSchemaBuilder()->getColumnListing('fiche_test_outils');
            if (in_array('proc_idx', $cols)) {
                $q->where('proc_idx', $procIdx);
            }
        } catch (\Exception) {}

        return $q->value('outil_id');
    }

    // ─────────────────────────────────────────────────────────────────
    // Enregistre ou met à jour le lien fiche_test_outils
    // après un store() ou update().
    // ─────────────────────────────────────────────────────────────────
    protected function saveFicheTestLinkIfPresent(Request $request, int $outilId, string $outilCode, string $outilTable): void
    {
        $ctx = $this->ficheTestContext($request);
        if (!$ctx['has_context']) return;

        $ficheTestId  = $ctx['fiche_test_id'];
        $missionId    = $ctx['mission_id'];
        $assignmentId = $ctx['assignment_id'];
        $testRef      = $ctx['test_ref'];
        $objNum       = $ctx['obj_num'];
        $procIdx      = $ctx['proc_idx'];

        try {
            $cols = DB::connection($this->conn)->getSchemaBuilder()->getColumnListing('fiche_test_outils');
            $hasProcIdx = in_array('proc_idx', $cols);

            // Vérifier si le lien existe déjà
            $q = DB::connection($this->conn)->table('fiche_test_outils')
                ->where('fiche_test_id', $ficheTestId)
                ->where('outil_code', $outilCode)
                ->where('test_ref', $testRef)
                ->where('is_current', 1);

            if ($hasProcIdx) $q->where('proc_idx', $procIdx);

            $existing = $q->first();

            if ($existing) {
                // Mettre à jour l'outil_id si différent (ex: nouveau store)
                DB::connection($this->conn)->table('fiche_test_outils')
                    ->where('id', $existing->id)
                    ->update(['outil_id' => $outilId, 'updated_at' => now()]);
            } else {
                $data = [
                    'fiche_test_id'  => $ficheTestId,
                    'mission_id'     => $missionId,
                    'assignment_id'  => $assignmentId,
                    'procedure_code' => $request->input('procedure_code', 'FT'),
                    'test_ref'       => $testRef,
                    'obj_num'        => $objNum,
                    'outil_code'     => $outilCode,
                    'outil_table'    => $outilTable,
                    'outil_id'       => $outilId,
                    'version'        => 1,
                    'is_current'     => 1,
                    'created_by'     => auth()->id(),
                    'created_at'     => now(),
                    'updated_at'     => now(),
                ];
                if ($hasProcIdx) $data['proc_idx'] = $procIdx;
                DB::connection($this->conn)->table('fiche_test_outils')->insert($data);
            }
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::warning('[FicheTestContextTrait] saveFicheTestLink: ' . $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // Retour vers FicheTest après save.
    // Si 'back' présent → redirect vers back.
    // Sinon → redirect vers la page edit de l'outil.
    // ─────────────────────────────────────────────────────────────────
    protected function redirectAfterSave(Request $request, int $outilId, string $editRoute, string $msg = 'Enregistré.'): mixed
    {
        $back = $request->input('back');
        if ($back) {
            return redirect($back)->with('success', $msg);
        }
        return redirect()->route($editRoute, array_filter([
            $outilId,
        ]))->with('success', $msg);
    }
}