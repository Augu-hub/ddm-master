<?php

namespace App\Http\Controllers\Auditor\Outils;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Inertia\Inertia;

class OutilHierarchisationRisquesController extends Controller
{
    protected string $table = 'outil_hierarchisation_risques';

    private function t() { return DB::connection('tenant'); }

    private static function cssToHex(string $css): string
    {
        return match(trim(strtolower($css))) {
            'success'   => '#28a745',
            'danger'    => '#dc3545',
            'warning'   => '#ffc107',
            'info'      => '#17a2b8',
            'primary'   => '#0d6efd',
            'secondary' => '#6c757d',
            'dark'      => '#343a40',
            'light'     => '#f8f9fa',
            default     => str_starts_with($css, '#') ? $css : '#6c757d',
        };
    }

    public function index(Request $request)
    {
        $missionId    = (int) $request->query('mission_id', 0);
        $assignmentId = (int) $request->query('assignment_id', 0);
        $testRef      = $request->query('test_ref', '');
        $objNum       = $request->query('obj_num', '');
        $procIdx      = (int) $request->query('proc_idx', 0);
        
        Log::info('[OutilVI] index - mission_id: ' . $missionId . ', assignment_id: ' . $assignmentId);
        
        return Inertia::render('Auditor/Outils/OutilHierarchisationRisques',
            $this->buildPayload($missionId, $assignmentId, null, $testRef, $objNum, $procIdx));
    }

    public function edit(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);
        
        $testRef = $request->query('test_ref', $fiche->test_ref ?? '');
        $objNum  = $request->query('obj_num', $fiche->obj_num ?? '');
        $procIdx = (int) $request->query('proc_idx', $fiche->proc_idx ?? 0);
        
        Log::info('[OutilVI] edit - fiche_id: ' . $id . ', mission_id: ' . $fiche->mission_id);
        
        return Inertia::render('Auditor/Outils/OutilHierarchisationRisques',
            $this->buildPayload((int) $fiche->mission_id, (int) ($fiche->assignment_id ?? 0), $fiche, $testRef, $objNum, $procIdx));
    }

    private function buildPayload(int $missionId, int $assignmentId, mixed $fiche, string $testRef = '', string $objNum = '', int $procIdx = 0): array
    {
        Log::info('[OutilVI] buildPayload - missionId: ' . $missionId);
        
        // Résolution mission_programmation → realMissionId
        $missionRow = null;
        $realMissionId = $missionId;
        
        if ($missionId) {
            $missionRow = $this->t()->table('mission_programmation')->where('id', $missionId)->first();
            if ($missionRow && $missionRow->mission_id) {
                $realMissionId = $missionRow->mission_id;
            }
        }
        
        Log::info('[OutilVI] realMissionId: ' . $realMissionId);

        $auditor = $this->getAuditor();
        $auditorRole = $this->getAuditorRole($missionId, $auditor?->id);
        $auditeurNom = $auditor
            ? trim(($auditor->last_name ?? '') . ' ' . ($auditor->first_name ?? ''))
            : (auth()->user()?->name ?? '');

        // Charger les données VI
        $viData = $this->chargerDonneesVI($realMissionId, $missionId);

        // Décoder les risques existants dans la fiche
        $existingRisks = [];
        if ($fiche && $fiche->risques) {
            $existingRisks = $this->decodeArr($fiche->risques);
            Log::info('[OutilVI] risques existants dans fiche: ' . count($existingRisks));
        }
        
        // Fusionner les risques
        $mergedRisks = $this->fusionnerRisques($viData['risques'], $existingRisks);
        Log::info('[OutilVI] risques fusionnés: ' . count($mergedRisks));

        $formData = null;
        if ($fiche) {
            $formData = [
                'id'                => $fiche->id,
                'code'              => $fiche->code,
                'validation_status' => $fiche->validation_status,
                'validation_note'   => $fiche->validation_note,
                'intitule'          => $fiche->intitule ?? '',
                'perimetre'         => $fiche->perimetre ?? '',
                'date_analyse'      => $fiche->date_analyse ?? $fiche->date ?? date('Y-m-d'),
                'risques'           => $mergedRisks,
                'ia_result'         => $fiche->ia_result ? json_decode($fiche->ia_result, true) : null,
            ];
        } else {
            $formData = [
                'id'                => null,
                'code'              => null,
                'validation_status' => 'draft',
                'validation_note'   => null,
                'intitule'          => '',
                'perimetre'         => '',
                'date_analyse'      => date('Y-m-d'),
                'risques'           => $mergedRisks,
                'ia_result'         => null,
            ];
        }

        $ficheId = $fiche?->id ?? null;

        return [
            'record'        => $formData,
            'risques'       => $mergedRisks,
            'processus'     => $viData['processus'],
            'risquesMission'=> $viData['risques'],
            'frequencies'   => $viData['frequencies'],
            'impacts'       => $viData['impacts'],
            'matrix'        => $viData['matrix'],
            'riskTypes'     => $viData['riskTypes'],
            'auditorRole'   => $auditorRole,
            'auditeurNom'   => $auditeurNom,
            'backUrl'       => $this->backUrl($missionId, $testRef, $objNum, $procIdx),
            'urlStore'      => route('auditor.ac.outil-hierarchisation-risques.store'),
            'urlUpdate'     => $ficheId ? route('auditor.ac.outil-hierarchisation-risques.update', $ficheId) : null,
            'urlSoumettre'  => $ficheId ? route('auditor.ac.outil-hierarchisation-risques.soumettre', $ficheId) : null,
            'urlValider'    => $ficheId ? route('auditor.ac.outil-hierarchisation-risques.valider', $ficheId) : null,
            'urlIa'         => $ficheId ? route('auditor.ac.outil-hierarchisation-risques.ia', $ficheId) : null,
            'missionContext'=> [
                'mission_id'      => $missionId,
                'assignment_id'   => $assignmentId,
                'mission_libelle' => $missionRow?->libelle ?? '',
                'code_mission'    => $missionRow?->code_mission ?? '',
                'test_ref'        => $testRef,
                'obj_num'         => $objNum,
                'proc_idx'        => $procIdx,
            ],
        ];
    }

    private function fusionnerRisques(array $risquesMission, array $risquesExistants): array
    {
        Log::info('[OutilVI] fusionnerRisques - mission: ' . count($risquesMission) . ', existants: ' . count($risquesExistants));
        
        $existingIndex = [];
        foreach ($risquesExistants as $existing) {
            $riskId = $existing['risk_id'] ?? null;
            if ($riskId) {
                $existingIndex[$riskId] = $existing;
            }
        }
        
        $result = [];
        
        // Ajouter les risques de la mission
        foreach ($risquesMission as $risk) {
            $riskId = $risk['id'] ?? null;
            if ($riskId && isset($existingIndex[$riskId])) {
                // Version modifiée existe
                $merged = $existingIndex[$riskId];
                // Mettre à jour les champs de base
                $merged['label'] = $risk['label'] ?? $merged['libelle'] ?? '';
                $merged['code'] = $risk['code'] ?? '';
                $merged['description'] = $risk['description'] ?? '';
                $result[] = $merged;
            } else {
                // Nouveau risque de la mission
                $result[] = [
                    'risk_id' => $riskId,
                    'libelle' => $risk['label'] ?? '',
                    'code' => $risk['code'] ?? '',
                    'description' => $risk['description'] ?? '',
                    'categorie' => $risk['risk_type_label'] ?? '',
                    'causes' => '',
                    'consequences' => '',
                    'probabilite' => $risk['frequency_level'] ?? 1,
                    'impact' => $risk['impact_level'] ?? 1,
                    'criticite' => ($risk['frequency_level'] ?? 1) * ($risk['impact_level'] ?? 1),
                    'traitement' => '',
                    'responsable' => $risk['owner'] ?? '',
                    'echeance' => '',
                    'from_mission' => 1,
                    'risk_type_label' => $risk['risk_type_label'] ?? '—',
                    'risk_type_color' => $risk['risk_type_color'] ?? '#6c757d',
                    'control_procedure' => $risk['control_procedure'] ?? '',
                ];
            }
        }
        
        // Ajouter les risques créés manuellement (sans risk_id)
        foreach ($risquesExistants as $existing) {
            if (!isset($existing['risk_id']) || !$existing['risk_id']) {
                $result[] = $existing;
            }
        }
        
        return $result;
    }

    private function chargerDonneesVI(int $realMissionId, int $programmationId): array
    {
        Log::info('[OutilVI] chargerDonneesVI - realMissionId: ' . $realMissionId . ', programmationId: ' . $programmationId);
        
        // ── 1. Récupérer les risques liés à la mission ─────────────────
        $riskIds = [];
        
        // Méthode 1: via mission_risk (mission_id = realMissionId)
        if ($realMissionId) {
            $riskIds = $this->t()
                ->table('mission_risk')
                ->where('mission_id', $realMissionId)
                ->pluck('risk_id')
                ->toArray();
            Log::info('[OutilVI] riskIds via mission_risk (mission_id=' . $realMissionId . '): ' . json_encode($riskIds));
        }
        
        // Méthode 2: si aucun risque trouvé, chercher via mission_programmation
        if (empty($riskIds) && $programmationId) {
            // Chercher les risques directement liés à cette programmation
            $riskIds = $this->t()
                ->table('mission_risk as mr')
                ->join('mission_programmation as mp', 'mp.mission_id', '=', 'mr.mission_id')
                ->where('mp.id', $programmationId)
                ->pluck('mr.risk_id')
                ->toArray();
            Log::info('[OutilVI] riskIds via mission_programmation (id=' . $programmationId . '): ' . json_encode($riskIds));
        }
        
        // Méthode 3: récupérer TOUS les risques actifs pour test
        if (empty($riskIds)) {
            $riskIds = $this->t()
                ->table('risks')
                ->whereNull('deleted_at')
                ->where('is_active', 1)
                ->pluck('id')
                ->toArray();
            Log::info('[OutilVI] Aucun risque lié - chargement de tous les risques actifs: ' . count($riskIds));
        }

        // ── 2. Référentiels ───────────────────────────────────────────
        $frequencies = $this->t()
            ->table('risk_frequency_levels')
            ->whereNull('deleted_at')
            ->orderBy('level')
            ->get(['id', 'code', 'label', 'level', 'color', 'description'])
            ->map(fn($f) => array_merge((array)$f, ['color' => self::cssToHex($f->color ?? 'secondary')]))
            ->toArray();

        $impacts = $this->t()
            ->table('risk_impact_levels')
            ->whereNull('deleted_at')
            ->orderBy('level')
            ->get(['id', 'code', 'label', 'level', 'color', 'description'])
            ->map(fn($i) => array_merge((array)$i, ['color' => self::cssToHex($i->color ?? 'secondary')]))
            ->toArray();

        $matrix = $this->t()
            ->table('audit_matrix')
            ->whereNull('deleted_at')
            ->orderBy('impact_level')
            ->orderBy('frequency_level')
            ->get(['id', 'impact_level', 'frequency_level', 'criticality_score', 'label', 'qualification', 'color'])
            ->map(fn($m) => (array)$m)
            ->toArray();

        $riskTypes = $this->t()
            ->table('risk_types')
            ->where('is_active', 1)
            ->whereNull('deleted_at')
            ->orderBy('sort_order')
            ->get(['id', 'code', 'label', 'color'])
            ->map(fn($t) => (array)$t)
            ->toArray();

        // ── 3. Récupérer les détails des risques ──────────────────────
        $risques = [];
        if (!empty($riskIds)) {
            $risques = $this->t()
                ->table('risks as r')
                ->leftJoin('risk_frequency_levels as rfl', 'rfl.id', '=', 'r.frequency_level_id')
                ->leftJoin('risk_impact_levels as ril', 'ril.id', '=', 'r.impact_level_id')
                ->leftJoin('processes as p', 'p.id', '=', 'r.process_id')
                ->leftJoin('activities as a', 'a.id', '=', 'r.activity_id')
                ->leftJoin('risk_types as rt', 'rt.id', '=', 'r.risk_type_id')
                ->whereIn('r.id', $riskIds)
                ->whereNull('r.deleted_at')
                ->select(
                    'r.id',
                    'r.code',
                    'r.label',
                    'r.description',
                    'r.process_id',
                    'r.activity_id',
                    'r.risk_type_id',
                    'r.criticality',
                    'r.frequency_net',
                    'r.impact_net',
                    'r.frequency_level_id',
                    'r.impact_level_id',
                    'r.status',
                    'r.owner',
                    'r.control_procedure',
                    DB::raw('COALESCE(rfl.level, 1) as frequency_level'),
                    DB::raw('COALESCE(rfl.label, "Non défini") as frequency_label'),
                    DB::raw('rfl.color as frequency_color'),
                    DB::raw('COALESCE(ril.level, 1) as impact_level'),
                    DB::raw('COALESCE(ril.label, "Non défini") as impact_label'),
                    DB::raw('ril.color as impact_color'),
                    DB::raw('p.code as process_code'),
                    DB::raw('p.name as process_name'),
                    DB::raw('a.code as activity_code'),
                    DB::raw('a.name as activity_name'),
                    DB::raw('rt.label as risk_type_label'),
                    DB::raw('rt.color as risk_type_color')
                )
                ->orderByDesc('r.criticality')
                ->get()
                ->map(function($r) {
                    $fl = (int)($r->frequency_level ?? 1);
                    $il = (int)($r->impact_level ?? 1);
                    $crit = $fl * $il;
                    
                    return [
                        'id'                   => $r->id,
                        'code'                 => $r->code,
                        'label'                => $r->label,
                        'description'          => $r->description,
                        'risk_id'              => $r->id,
                        'process_id'           => $r->process_id,
                        'activity_id'          => $r->activity_id,
                        'risk_type_id'         => $r->risk_type_id,
                        'risk_type_label'      => $r->risk_type_label ?? '—',
                        'risk_type_color'      => self::cssToHex($r->risk_type_color ?? 'secondary'),
                        'criticality'          => $crit,
                        'frequency_level'      => $fl,
                        'frequency_label'      => $r->frequency_label ?? '—',
                        'frequency_color'      => self::cssToHex($r->frequency_color ?? 'secondary'),
                        'impact_level'         => $il,
                        'impact_label'         => $r->impact_label ?? '—',
                        'impact_color'         => self::cssToHex($r->impact_color ?? 'secondary'),
                        'status'               => $r->status,
                        'owner'                => $r->owner,
                        'control_procedure'    => $r->control_procedure,
                        'process_name'         => $r->process_name ?? '—',
                        'process_code'         => $r->process_code ?? '—',
                        'activity_name'        => $r->activity_name ?? '—',
                        'activity_code'        => $r->activity_code ?? '—',
                        'from_mission'         => 1,
                    ];
                })
                ->toArray();
        }

        Log::info('[OutilVI] risques chargés: ' . count($risques));

        // ── 4. Processus pour le sélecteur ───────────────────────────
        $allProcesses = $this->t()
            ->table('processes as p')
            ->join('macro_processes as mp', 'mp.id', '=', 'p.macro_process_id')
            ->select(
                'p.id', 'p.code', 'p.name', 'p.macro_process_id',
                'mp.id as macro_id', 'mp.name as macro_name',
                'mp.code as macro_code', 'mp.kind as macro_kind'
            )
            ->orderBy('mp.kind')
            ->orderBy('p.code')
            ->get()
            ->map(fn($p) => [
                'id'         => $p->id,
                'code'       => $p->code,
                'name'       => $p->name,
                'macro_id'   => $p->macro_id,
                'macro_name' => $p->macro_name,
                'macro_code' => $p->macro_code,
                'macro_kind' => $p->macro_kind,
            ])
            ->toArray();

        $processus = $allProcesses;

        return compact('risques', 'processus', 'frequencies', 'impacts', 'matrix', 'riskTypes');
    }

    private function getAuditor(): ?object
    {
        try {
            $user = auth()->user();
            if (!$user) return null;
            $col = DB::connection('tenant')->getSchemaBuilder()->hasColumn('auditors', 'user_id') ? 'user_id' : 'id';
            return $this->t()->table('auditors')->where($col, $user->id)->first();
        } catch (\Exception $e) {
            Log::error('[OutilVI] getAuditor error: ' . $e->getMessage());
            return null;
        }
    }

    private function getAuditorRole(int $missionId, ?int $auditorId): string
    {
        if (!$auditorId || !$missionId) return 'AJ';
        try {
            $row = $this->t()
                ->table('mission_phase_assignment_auditeurs as mpaa')
                ->join('mission_phase_assignments as mpa', 'mpa.id', '=', 'mpaa.assignment_id')
                ->where('mpa.mission_programmation_id', $missionId)
                ->where('mpaa.auditeur_id', $auditorId)
                ->select('mpaa.role_code')
                ->orderByRaw("FIELD(mpaa.role_code,'DM','CM','AS','AJ')")
                ->first();
            return $row?->role_code ?? 'AJ';
        } catch (\Exception $e) {
            return 'AJ';
        }
    }

    private function decodeArr(mixed $v): array
    {
        if (is_array($v)) return $v;
        if (!$v) return [];
        $d = json_decode($v, true);
        return is_array($d) ? $d : [];
    }

    private function backUrl(?int $missionId, string $testRef = '', string $objNum = '', int $procIdx = 0): string
    {
        if (!$missionId) return '/';
        try {
            $params = ['mission_id' => $missionId];
            if ($testRef) $params['test_ref'] = $testRef;
            if ($objNum) $params['obj_num'] = $objNum;
            if ($procIdx) $params['proc_idx'] = $procIdx;
            return route('auditor.ac.fiche-test.index', $params);
        } catch (\Exception $e) {
            return url("/m/audit.core/auditor/missions/{$missionId}/phases");
        }
    }

    // ══════════════════════════════════════════════════════════════
    // STORE / UPDATE / SOUMETTRE / VALIDER / DESTROY / IA
    // ══════════════════════════════════════════════════════════════

    public function store(Request $request)
    {
        Log::info('[OutilVI] store - request: ' . json_encode($request->all()));
        
        $v = $request->validate([
            'mission_id'    => 'required|integer',
            'assignment_id' => 'nullable|integer',
            'test_ref'      => 'nullable|string|max:80',
            'obj_num'       => 'nullable|string|max:20',
            'proc_idx'      => 'nullable|integer',
            'intitule'      => 'nullable|string|max:255',
            'perimetre'     => 'nullable|string|max:500',
            'date_analyse'  => 'nullable|date',
            'risques'       => 'nullable|array',
        ]);
        
        $mid = $v['mission_id'];
        $count = $this->t()->table($this->table)->where('mission_id', $mid)->count();
        $code = 'VI-' . str_pad($mid, 4, '0', STR_PAD_LEFT) . '-' . str_pad($count + 1, 3, '0', STR_PAD_LEFT);

        $id = $this->t()->table($this->table)->insertGetId([
            'code'          => $code,
            'mission_id'    => $mid,
            'assignment_id' => $v['assignment_id'] ?? null,
            'test_ref'      => $v['test_ref'] ?? null,
            'obj_num'       => $v['obj_num'] ?? null,
            'proc_idx'      => $v['proc_idx'] ?? 0,
            'intitule'      => $v['intitule'] ?? null,
            'perimetre'     => $v['perimetre'] ?? null,
            'date_analyse'  => $v['date_analyse'] ?? null,
            'risques'       => json_encode($v['risques'] ?? [], JSON_UNESCAPED_UNICODE),
            'validation_status' => 'draft',
            'validation_note' => null,
            'created_by'    => auth()->id(),
            'updated_by'    => auth()->id(),
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);

        Log::info('[OutilVI] store created id: ' . $id . ', code: ' . $code);

        return response()->json([
            'success' => true,
            'record'  => ['id' => $id, 'code' => $code, 'statut' => 'draft'],
            'urlUpdate'    => route('auditor.ac.outil-hierarchisation-risques.update', $id),
            'urlSoumettre' => route('auditor.ac.outil-hierarchisation-risques.soumettre', $id),
            'urlValider'   => route('auditor.ac.outil-hierarchisation-risques.valider', $id),
            'urlIa'        => route('auditor.ac.outil-hierarchisation-risques.ia', $id),
        ]);
    }

    public function update(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);
        
        if ($fiche->validation_status === 'validated') {
            return response()->json(['success' => false, 'message' => 'Fiche validée, modification impossible.'], 422);
        }

        $v = $request->validate([
            'intitule'     => 'nullable|string|max:255',
            'perimetre'    => 'nullable|string|max:500',
            'date_analyse' => 'nullable|date',
            'risques'      => 'nullable|array',
        ]);
        
        $this->t()->table($this->table)->where('id', $id)->update([
            'intitule'     => $v['intitule'] ?? $fiche->intitule,
            'perimetre'    => $v['perimetre'] ?? $fiche->perimetre,
            'date_analyse' => $v['date_analyse'] ?? $fiche->date_analyse,
            'risques'      => json_encode($v['risques'] ?? [], JSON_UNESCAPED_UNICODE),
            'updated_by'   => auth()->id(),
            'updated_at'   => now(),
        ]);
        
        return response()->json([
            'success' => true,
            'record' => ['id' => $id, 'code' => $fiche->code, 'statut' => $fiche->validation_status]
        ]);
    }

    public function soumettre(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);
        
        if ($fiche->validation_status !== 'draft') {
            return response()->json(['success' => false, 'error' => 'Statut invalide.'], 422);
        }
        
        $this->t()->table($this->table)->where('id', $id)->update([
            'validation_status' => 'in_review',
            'updated_at' => now()
        ]);
        
        return response()->json(['success' => true, 'status' => 'in_review']);
    }

    public function valider(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);
        
        if ($fiche->validation_status !== 'in_review') {
            return response()->json(['success' => false, 'error' => 'Non soumise.'], 422);
        }
        
        $action = $request->input('action');
        $note = $request->input('note', '');
        
        if ($action === 'validate') {
            $this->t()->table($this->table)->where('id', $id)->update([
                'validation_status' => 'validated',
                'validation_note' => null,
                'updated_at' => now()
            ]);
            return response()->json(['success' => true, 'status' => 'validated']);
        }
        
        if ($action === 'reject') {
            if (!$note) {
                return response()->json(['success' => false, 'error' => 'Motif obligatoire.'], 422);
            }
            $this->t()->table($this->table)->where('id', $id)->update([
                'validation_status' => 'draft',
                'validation_note' => $note,
                'updated_at' => now()
            ]);
            return response()->json(['success' => true, 'status' => 'draft']);
        }
        
        return response()->json(['success' => false, 'error' => 'Action inconnue.'], 422);
    }

    public function destroy(int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);
        
        if ($fiche->validation_status === 'validated') {
            return response()->json(['success' => false, 'message' => 'Fiche validée, suppression impossible.'], 422);
        }
        
        $this->t()->table($this->table)->where('id', $id)->delete();
        
        return response()->json(['success' => true]);
    }

    public function ia(Request $request, int $id)
    {
        $fiche = $this->t()->table($this->table)->where('id', $id)->first();
        abort_if(!$fiche, 404);
        
        $risques = $this->decodeArr($fiche->risques);
        
        $prompt = "Tu es un expert en audit interne. Analyse la hiérarchisation des risques suivante et retourne un JSON valide avec:\n";
        $prompt .= "- synthese (string): analyse globale des risques\n";
        $prompt .= "- risques_majeurs (array): liste des risques les plus critiques\n";
        $prompt .= "- recommandations (array): liste des actions recommandées\n";
        $prompt .= "- score (number): note globale /10\n\n";
        $prompt .= "Risques identifiés:\n";
        
        foreach ($risques as $r) {
            $crit = ($r['probabilite'] ?? 1) * ($r['impact'] ?? 1);
            $niveau = $crit >= 7 ? 'FORT' : ($crit >= 4 ? 'MODÉRÉ' : 'FAIBLE');
            $prompt .= "- {$r['libelle']} (Prob: {$r['probabilite']}, Impact: {$r['impact']}, Niveau: {$niveau})\n";
            if (!empty($r['causes'])) $prompt .= "  Causes: {$r['causes']}\n";
            if (!empty($r['consequences'])) $prompt .= "  Conséquences: {$r['consequences']}\n";
        }
        
        try {
            $response = Http::withHeaders([
                'x-api-key' => config('services.anthropic.key'),
                'anthropic-version' => '2023-06-01',
                'content-type' => 'application/json'
            ])->timeout(45)->post('https://api.anthropic.com/v1/messages', [
                'model' => 'claude-sonnet-4-20250514',
                'max_tokens' => 1500,
                'system' => 'Tu es expert en audit interne. Retourne UNIQUEMENT un JSON valide sans markdown.',
                'messages' => [['role' => 'user', 'content' => $prompt]]
            ]);
            
            $content = collect($response->json()['content'] ?? [])->firstWhere('type', 'text')['text'] ?? '{}';
            $content = trim(preg_replace('/^```json\s*|\s*```$/m', '', $content));
            $iaResult = json_decode($content, true) ?? [];
            
            $this->t()->table($this->table)->where('id', $id)->update([
                'ia_result' => json_encode($iaResult, JSON_UNESCAPED_UNICODE),
                'updated_at' => now()
            ]);
            
            return response()->json(['success' => true, 'ia_result' => $iaResult]);
            
        } catch (\Exception $e) {
            Log::error('[OutilVI] IA error: ' . $e->getMessage());
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
}