<?php

namespace App\Http\Controllers\Auditor\Outils;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

/**
 * Outil I — Grille d'Entretien
 */
class OutilEntretienController extends OutilBaseController
{
    protected string $outilCode   = 'I';
    protected string $outilTable  = 'outil_entretiens';
    protected string $outilLabel  = "Grille d'Entretien";
    protected string $outilColor  = '#1e40af';
    protected string $codePrefix  = 'ENTR';
    protected string $inertiaPage = 'dashboards/Auditor/Outils/OutilEntretien';

    protected function routeName(): string { return 'auditor.ac.outil-entretien'; }

    protected function validationRules(): array
    {
        return [
            'intitule'         => 'required|string|max:255',
            'objectif'         => 'nullable|string',
            'interlocuteur'    => 'nullable|string|max:255',
            'fonction'         => 'nullable|string|max:255',
            'date_entretien'   => 'nullable|date',
            'lieu'             => 'nullable|string|max:255',
            'synthese'         => 'nullable|string',
            'sig_auditeur'     => 'nullable|string|max:255',
            'sig_interlocuteur'=> 'nullable|string|max:255',
            'questions'        => 'nullable|array',
            'questions.*.type'   => 'nullable|string',
            'questions.*.libelle'=> 'required|string',
            'questions.*.reponse'=> 'nullable|string',
            'questions.*.note'   => 'nullable|string',
        ];
    }

    protected function buildRecord(array $v, array $ctx): array
    {
        return [
            'intitule'         => $v['intitule'],
            'objectif'         => $v['objectif'] ?? null,
            'interlocuteur'    => $v['interlocuteur'] ?? null,
            'fonction'         => $v['fonction'] ?? null,
            'date_entretien'   => $v['date_entretien'] ?? null,
            'lieu'             => $v['lieu'] ?? null,
            'synthese'         => $v['synthese'] ?? null,
            'sig_auditeur'     => $v['sig_auditeur'] ?? null,
            'sig_interlocuteur'=> $v['sig_interlocuteur'] ?? null,
        ];
    }

    protected function syncChildren(int $id, array $v): void
    {
        $this->db()->table('outil_entretien_questions')->where('entretien_id', $id)->delete();
        foreach ($v['questions'] ?? [] as $idx => $q) {
            if (empty($q['libelle'])) continue;
            $this->db()->table('outil_entretien_questions')->insert([
                'entretien_id' => $id,
                'type'         => $q['type'] ?? 'Ouverte',
                'libelle'      => $q['libelle'],
                'reponse'      => $q['reponse'] ?? null,
                'note'         => $q['note'] ?? null,
                'ordre'        => $idx + 1,
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);
        }
    }

    protected function loadChildren(int $id): array
    {
        return [
            'questions' => $id ? $this->db()->table('outil_entretien_questions')
                ->where('entretien_id', $id)->orderBy('ordre')->get()->toArray() : [],
        ];
    }

    protected function buildIaPrompt(array $record, array $children): string
    {
        $questions = collect($children['questions'] ?? [])
            ->map(fn($q) => "Q: " . (is_object($q) ? $q->libelle : $q['libelle']) . "\nR: " . (is_object($q) ? ($q->reponse ?? '—') : ($q['reponse'] ?? '—')))
            ->join("\n\n");

        return "Analyse cet entretien d'audit interne IFACI.\n"
            . "Intitulé: " . ($record['intitule'] ?? '') . "\n"
            . "Objectif: " . ($record['objectif'] ?? '') . "\n"
            . "Interlocuteur: " . ($record['interlocuteur'] ?? '') . "\n"
            . "Synthèse: " . ($record['synthese'] ?? '') . "\n\n"
            . "Questions/Réponses:\n{$questions}\n\n"
            . "Fournis une analyse JSON avec: synthese, points_forts, points_faibles, risques, recommandations, score.";
    }
}