<?php
// app/Modules/Param/Projects/routes/web.php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

use App\Http\Controllers\Param\ProjetController;
use App\Http\Controllers\Param\MacroProcessusController;
use App\Http\Controllers\Param\ProcessusController;
use App\Http\Controllers\Param\ActiviteController;
use App\Http\Controllers\Param\EntiteController;
use App\Http\Controllers\Param\FonctionController;
use App\Http\Controllers\Param\DistributionController;
use App\Http\Controllers\Param\ChartsController;
use App\Http\Controllers\Param\EntityFunctionsChartController;
use App\Http\Controllers\ErrorController;

/**
 * Ce fichier est monté avec un préfixe global: /m/param.projects
 * et (selon ton provider) un préfixe de nom optionnel (ex: 'm.').
 * On **déclare les noms finaux attendus par la BDD** (param.*)
 * et l'API résout l’URL (même si un 'm.' est préfixé).
 */

// Accueil du module (page entities)
Route::get('/', fn () => Inertia::render('dashboards/Param/Entities/index'))
     ->name('param.projects');

// Espace Param (pas de name() group pour éviter les doublons)
Route::prefix('param')->group(function () {

    // Projets
    Route::resource('projects', ProjetController::class)->names([
        'index'   => 'param.projects.index',
        'create'  => 'param.projects.create',
        'store'   => 'param.projects.store',
        'show'    => 'param.projects.show',
        'edit'    => 'param.projects.edit',
        'update'  => 'param.projects.update',
        'destroy' => 'param.projects.destroy',
    ]);

    // Entités
    Route::resource('entities', EntiteController::class)->names([
        'index'   => 'param.entities.index',
        'create'  => 'param.entities.create',
        'store'   => 'param.entities.store',
        'show'    => 'param.entities.show',
        'edit'    => 'param.entities.edit',
        'update'  => 'param.entities.update',
        'destroy' => 'param.entities.destroy',
    ]);

    // Macro-Processus / Processus / Activités / Fonctions
    Route::resource('mpa', MacroProcessusController::class)->names([
        'index'=>'param.mpa.index','create'=>'param.mpa.create','store'=>'param.mpa.store',
        'show'=>'param.mpa.show','edit'=>'param.mpa.edit','update'=>'param.mpa.update','destroy'=>'param.mpa.destroy',
    ]);

    Route::resource('processus', ProcessusController::class)->names([
        'index'=>'param.processus.index','create'=>'param.processus.create','store'=>'param.processus.store',
        'show'=>'param.processus.show','edit'=>'param.processus.edit','update'=>'param.processus.update','destroy'=>'param.processus.destroy',
    ]);

    Route::resource('activites', ActiviteController::class)->names([
        'index'=>'param.activites.index','create'=>'param.activites.create','store'=>'param.activites.store',
        'show'=>'param.activites.show','edit'=>'param.activites.edit','update'=>'param.activites.update','destroy'=>'param.activites.destroy',
    ]);

    Route::resource('fonctions', FonctionController::class)->names([
        'index'=>'param.fonctions.index','create'=>'param.fonctions.create','store'=>'param.fonctions.store',
        'show'=>'param.fonctions.show','edit'=>'param.fonctions.edit','update'=>'param.fonctions.update','destroy'=>'param.fonctions.destroy',
    ]);

    // Répartition
    Route::get('distribution', [DistributionController::class, 'index'])
         ->name('param.distribution.index');

    // Charts
    Route::get('charts/entity',           [ChartsController::class, 'entity'])->name('param.charts.entity');
    Route::get('charts/function',         [ChartsController::class, 'function'])->name('param.charts.function');
    Route::get('charts/entity-functions', [EntityFunctionsChartController::class, 'index'])->name('param.charts.entity-functions');
});

// (Optionnel) erreurs privées
Route::prefix('error')->name('error.')->group(function () {
    Route::get('400', [ErrorController::class, 'error400'])->name('400');
    Route::get('401', [ErrorController::class, 'error401'])->name('401');
    Route::get('403', [ErrorController::class, 'error403'])->name('403');
    Route::get('404', [ErrorController::class, 'error404'])->name('404');
    Route::get('404-alt', [ErrorController::class, 'error404Alt'])->name('404-alt');
    Route::get('408', [ErrorController::class, 'error408'])->name('408');
    Route::get('500', [ErrorController::class, 'error500'])->name('500');
    Route::get('501', [ErrorController::class, 'error501'])->name('501');
    Route::get('502', [ErrorController::class, 'error502'])->name('502');
    Route::get('503', [ErrorController::class, 'error503'])->name('503');
});
