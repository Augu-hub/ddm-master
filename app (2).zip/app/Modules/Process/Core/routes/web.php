<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'modules.process.core.home')->name('home');
// Route::get('/model', ...)->name('model.index');
