<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'modules.risk.core.home')->name('home');
// Route::get('/map', ...)->name('map.index');
