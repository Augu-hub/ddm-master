<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'modules.audit.core.home')->name('home');
// Route::get('/plan', ...)->name('plan.index');
