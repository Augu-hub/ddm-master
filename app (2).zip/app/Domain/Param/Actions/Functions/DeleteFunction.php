<?php

namespace App\Domain\Param\Actions\Functions;

class DeleteFunction
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
