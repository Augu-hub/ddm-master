<?php

namespace App\Domain\Param\Actions\MacroProcesses;

class CreateMacroProcess
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
