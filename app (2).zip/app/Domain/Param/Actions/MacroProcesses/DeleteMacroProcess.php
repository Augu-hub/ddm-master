<?php

namespace App\Domain\Param\Actions\MacroProcesses;

class DeleteMacroProcess
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
