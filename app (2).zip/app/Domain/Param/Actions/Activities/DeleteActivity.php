<?php

namespace App\Domain\Param\Actions\Activities;

class DeleteActivity
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
