<?php

namespace App\Domain\Param\Actions\Projects;

class DeleteProject
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
