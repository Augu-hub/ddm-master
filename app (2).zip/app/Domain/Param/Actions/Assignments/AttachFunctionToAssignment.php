<?php

namespace App\Domain\Param\Actions\Assignments;

class AttachFunctionToAssignment
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
