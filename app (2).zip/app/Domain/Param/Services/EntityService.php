<?php

namespace App\Domain\Param\Services;

class EntityService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
