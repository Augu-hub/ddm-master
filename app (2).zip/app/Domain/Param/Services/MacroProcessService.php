<?php

namespace App\Domain\Param\Services;

class MacroProcessService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
