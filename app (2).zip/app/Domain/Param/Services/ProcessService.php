<?php

namespace App\Domain\Param\Services;

class ProcessService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
