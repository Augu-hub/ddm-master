<?php

namespace App\Models\Models\Master;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    //
}
